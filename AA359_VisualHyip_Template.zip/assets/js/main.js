function countr_text_generator(textblock,first_symbol=false) {
    var number_of_symbols=8,
        content=$(textblock).text().replace(',', '');
        tlength=number_of_symbols-content.length,
        text=content;

    for (i = 0; i < tlength; i++) {
        text="0"+text;
    }

    if (first_symbol!=false) {
       text=first_symbol+text.substring(1, text.length);
    }

    $(textblock).text(text);

}
$(document).ready(function() {
    new ClipboardJS('.copybtn');
countr_text_generator("#counetrdays");
countr_text_generator("#counterdeposits","$");
countr_text_generator("#counterusers");

    $('#slick-plans').slick({
        infinite: true,
        slidesToShow: 3,
        slidesToScroll: 3,
        autoplay : true,
        arrows : false,
        autoplaySpeed: 2000,
        dots: true,
    });
});

