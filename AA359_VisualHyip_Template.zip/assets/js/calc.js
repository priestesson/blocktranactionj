function calcutalor_start() {
    var planid=$("#planselect").val(),plan = plans[planid];
    mincalculateforms(plan.min);
    $("#amountrange").attr("min", plan.min).attr("max", plan.max).attr("value", plan.min);
    calculate(plan, plan.min);
}
function select_plan(id) {
    $("#planselect").val(id);
    $(".plan-table-button").text("Select").removeClass("selected");
    $("#selectplanbutton"+id).html("<i class=\"fas fa-check\"></i>").addClass("selected");
    $("#planradio"+id).prop('checked',true);
    calcutalor_start()
}

var plans = {
    "1": {
        min: 25,
        max: 10000,
        type: "once",
        return_deposit: true,
        subplans: {
            0: {
                min: 25,
                max: 500,
                profit: 3,
            },
            1: {
                min: 501,
                max: 1000,
                profit: 5,
            },
            2: {
                min: 1001,
                max: 5000,
                profit: 7,
            },
            3: {
                min: 5001,
                max: 10000,
                profit:20,
            }
        }
    },
    "2": {
        min: 25,
        max: 20000,
        type: "once",
        return_deposit: true,
        subplans: {
            0: {
                min: 25,
                max: 500,
                profit: 12,
            },
            1: {
                min: 501,
                max: 5000,
                profit: 20,
            },
            2: {
                min: 5001,
                max: 10000,
                profit: 30,
            },
            3: {
                min: 10001,
                max: 20000,
                profit:80,
            }
        }
    },
    "3": {
        min: 25,
        max: 30000,
        type: "once",
        return_deposit: true,
        subplans: {
            0: {
                min: 25,
                max: 500,
                profit: 23,
            },
            1: {
                min: 501,
                max: 5000,
                profit: 36,
            },
            2: {
                min: 5001,
                max: 10000,
                profit: 55,
            },
            3: {
                min: 10001,
                max: 30000,
                profit:165,
            }
        }
    },

    "4": {
        min: 50,
        max: 50000,
        type: "once",
        return_deposit: true,
        subplans: {
            0: {
                min: 50,
                max: 500,
                profit: 35,
            },
            1: {
                min: 501,
                max: 5000,
                profit: 55,
            },
            2: {
                min: 5001,
                max: 10000,
                profit: 77,
            },
            3: {
                min: 10001,
                max: 50000,
                profit:300,
            }
        }
    },
    "5": {
        min: 50,
        max: 50000,
        type: "once",
        return_deposit: true,
        subplans: {
            0: {
                min: 50,
                max: 500,
                profit: 180,
            },
            1: {
                min: 1001,
                max: 5000,
                profit: 300,
            },
            2: {
                min: 5001,
                max: 10000,
                profit: 700,
            },
            3: {
                min: 10001,
                max: 50000,
                profit:6400,
            }
        }
    }
}
$(document).ready(function () {
    $("#amountrange").on("input", function () {
        var plan = plans[$("#planselect").val()];
        $("input[name='amount']").val($(this).val() + ".00");
        calculate(plan, $(this).val());
    });
    $("input[name='amount']").on("input",function () {
        var plan = plans[$("#planselect").val()];
        var amount = $(this).val();
        amount = amount.replace(",", ".");
        if ($.isNumeric(amount) && amount >=plan.min && amount <= plan.max) {
            $("#amountrange").val(amount);
            calculate(plan, amount)
        } else {
            $("#result-green-calc").text("$0.00")
        }
    });
    $("#planselect").change(function(){
        calcutalor_start();
        select_plan(this.value);
    });
    calcutalor_start();
});

function calculate(plan, amount) {
    amount = Number(amount).toFixed(2);
    if (amount < plan.min || amount > plan.max) {
        zerocalculateforms(plan.min);
        return;
    }
    //find subplan
    var subplan, i = 0;

    while (subplan === undefined) {
        if (i in plan.subplans) {
            if (amount >= plan.subplans[i].min && amount <= plan.subplans[i].max) {
                subplan = plan.subplans[i];
                break;
            }
        } else {
            return;
        }
        i++;
    }
    switch (plan.type) {
        case "once":
            var profit =  ((subplan.profit / 100) * amount).toFixed(2);
            $("#result-green-calc").text("$" + (Number(profit) + Number(amount)).toFixed(2));
            break;

    }

}

function mincalculateforms(min) {
    $("input[name='amount']").val(min + ".00");
    $("#amountrange").val(min);
}

function zerocalculateforms(min) {
    mincalculateforms(min);
    $("#result-green-calc").text("$0.00")
}


