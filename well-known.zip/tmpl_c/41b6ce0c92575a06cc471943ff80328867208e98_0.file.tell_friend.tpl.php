<?php /* Smarty version 3.1.27, created on 2018-02-20 23:17:16
         compiled from "/home/dsenemfi/nxtcoininvest.com/tmpl/tell_friend.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:9823946465a8cf2cc49da71_86575429%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '41b6ce0c92575a06cc471943ff80328867208e98' => 
    array (
      0 => '/home/dsenemfi/nxtcoininvest.com/tmpl/tell_friend.tpl',
      1 => 1442782298,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '9823946465a8cf2cc49da71_86575429',
  'variables' => 
  array (
    'say' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_5a8cf2cc528502_62869497',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5a8cf2cc528502_62869497')) {
function content_5a8cf2cc528502_62869497 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '9823946465a8cf2cc49da71_86575429';
echo $_smarty_tpl->getSubTemplate ("header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>



<h3>Tell friend:</h3><br><br>

<?php if ($_smarty_tpl->tpl_vars['say']->value == 'invite_sent') {?>
Your invite/invites has been successfully sent.<br><br>
<?php }?>

<form action="index.php" method=post >
<input type=hidden name=a value=tell_friend>
<input type=hidden name=action value=tell_friend>
<table cellspacing=0 cellpadding=2 border=0>
<tr>
 <td>Name 1:</td>
 <td><input type=text name=name1 class=inpts></td>
 <td>Email 1:</td>
 <td><input type=text name=email1 class=inpts></td>
</tr>
<tr>
 <td>Name 2:</td>
 <td><input type=text name=name2 class=inpts></td>
 <td>Email 2:</td>
 <td><input type=text name=email2 class=inpts></td>
</tr>
<tr>
 <td>Name 3:</td>
 <td><input type=text name=name3 class=inpts></td>
 <td>Email 3:</td>
 <td><input type=text name=email3 class=inpts></td>
</tr>
<tr>
 <td colspan=4 align=center><input type=submit value="Send" class=sbmt></td>
</tr>
</table>
</form>

<?php echo $_smarty_tpl->getSubTemplate ("footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>


<?php }
}
?>