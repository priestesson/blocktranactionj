<?php /* Smarty version 3.1.27, created on 2017-06-20 15:04:12
         compiled from "/home/cryptoorbit/public_html/tmpl/account_main.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:4973837955949396cb7d4b3_84483665%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '9f182a5a2371d86cc30fe8d8664fdae106d96ebf' => 
    array (
      0 => '/home/cryptoorbit/public_html/tmpl/account_main.tpl',
      1 => 1481513456,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '4973837955949396cb7d4b3_84483665',
  'variables' => 
  array (
    'currency_sign' => 0,
    'ab_formated' => 0,
    'ps' => 0,
    'last_deposit' => 0,
    'settings' => 0,
    'userinfo' => 0,
    'last_access' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_5949396cca02b5_74760984',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5949396cca02b5_74760984')) {
function content_5949396cca02b5_74760984 ($_smarty_tpl) {
if (!is_callable('smarty_modifier_myescape')) require_once '/home/cryptoorbit/public_html/inc/libs/smarty3/plugins/modifier.myescape.php';

$_smarty_tpl->properties['nocache_hash'] = '4973837955949396cb7d4b3_84483665';
echo $_smarty_tpl->getSubTemplate ("header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>

		

<h1>Your account</h1>
<div class="separator_2"><span></span></div>
<?php echo $_smarty_tpl->getSubTemplate ("mnav.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>


<div class="account_page">
			<div class="a_wrap clearfix">
		<div class="a_info">
			<div class="balance clearfix">
				<div class="title">Account Balance:</div>
				<div class="money"><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['currency_sign']->value);
echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['ab_formated']->value['total']);?>
</div>
				<div class="info">
					<ul>
					<?php if (isset($_smarty_tpl->tpl_vars['smarty']->value['section']['p'])) unset($_smarty_tpl->tpl_vars['smarty']->value['section']['p']);
$_smarty_tpl->tpl_vars['smarty']->value['section']['p']['name'] = 'p';
$_smarty_tpl->tpl_vars['smarty']->value['section']['p']['loop'] = is_array($_loop=$_smarty_tpl->tpl_vars['ps']->value) ? count($_loop) : max(0, (int) $_loop); unset($_loop);
$_smarty_tpl->tpl_vars['smarty']->value['section']['p']['show'] = true;
$_smarty_tpl->tpl_vars['smarty']->value['section']['p']['max'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['p']['loop'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['p']['step'] = 1;
$_smarty_tpl->tpl_vars['smarty']->value['section']['p']['start'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['p']['step'] > 0 ? 0 : $_smarty_tpl->tpl_vars['smarty']->value['section']['p']['loop']-1;
if ($_smarty_tpl->tpl_vars['smarty']->value['section']['p']['show']) {
    $_smarty_tpl->tpl_vars['smarty']->value['section']['p']['total'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['p']['loop'];
    if ($_smarty_tpl->tpl_vars['smarty']->value['section']['p']['total'] == 0)
        $_smarty_tpl->tpl_vars['smarty']->value['section']['p']['show'] = false;
} else
    $_smarty_tpl->tpl_vars['smarty']->value['section']['p']['total'] = 0;
if ($_smarty_tpl->tpl_vars['smarty']->value['section']['p']['show']):

            for ($_smarty_tpl->tpl_vars['smarty']->value['section']['p']['index'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['p']['start'], $_smarty_tpl->tpl_vars['smarty']->value['section']['p']['iteration'] = 1;
                 $_smarty_tpl->tpl_vars['smarty']->value['section']['p']['iteration'] <= $_smarty_tpl->tpl_vars['smarty']->value['section']['p']['total'];
                 $_smarty_tpl->tpl_vars['smarty']->value['section']['p']['index'] += $_smarty_tpl->tpl_vars['smarty']->value['section']['p']['step'], $_smarty_tpl->tpl_vars['smarty']->value['section']['p']['iteration']++):
$_smarty_tpl->tpl_vars['smarty']->value['section']['p']['rownum'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['p']['iteration'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['p']['index_prev'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['p']['index'] - $_smarty_tpl->tpl_vars['smarty']->value['section']['p']['step'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['p']['index_next'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['p']['index'] + $_smarty_tpl->tpl_vars['smarty']->value['section']['p']['step'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['p']['first']      = ($_smarty_tpl->tpl_vars['smarty']->value['section']['p']['iteration'] == 1);
$_smarty_tpl->tpl_vars['smarty']->value['section']['p']['last']       = ($_smarty_tpl->tpl_vars['smarty']->value['section']['p']['iteration'] == $_smarty_tpl->tpl_vars['smarty']->value['section']['p']['total']);
?>
					 <?php if ($_smarty_tpl->tpl_vars['ps']->value[$_smarty_tpl->getVariable('smarty')->value['section']['p']['index']]['balance'] > 0) {?><li><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['ps']->value[$_smarty_tpl->getVariable('smarty')->value['section']['p']['index']]['name']);?>
: <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['currency_sign']->value);
echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['ps']->value[$_smarty_tpl->getVariable('smarty')->value['section']['p']['index']]['balance']);?>
</li><?php }?>
					<?php endfor; endif; ?>
											</ul>
				</div>
			</div>
			<ul class="a_list">
				<li class="clearfix">Earned Total: <span><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['currency_sign']->value);
echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['ab_formated']->value['earning']);?>
</span></li>
				<li class="clearfix">Pending Withdrawal: <span><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['currency_sign']->value);
echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['ab_formated']->value['withdraw_pending']);?>
</span></li>
				<li class="clearfix">Active Deposit: <span><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['currency_sign']->value);
echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['ab_formated']->value['active_deposit']);?>
</span></li>
								<li class="clearfix">Last Deposit: <span><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['currency_sign']->value);
if ($_smarty_tpl->tpl_vars['last_deposit']->value) {
echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['last_deposit']->value);
} else { ?>N/A<?php }?></span></li>
								<li class="clearfix">Total Deposit: <span><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['currency_sign']->value);
echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['ab_formated']->value['deposit']);?>
</span></li>
								<li class="clearfix">Last Withdrawal: <span>No withdrawal yet</span></li>
								<li class="clearfix">Withdrew Total: <span><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['currency_sign']->value);
echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['ab_formated']->value['withdrawal']);?>
</span></li>
			</ul>
			<div class="server_time">
				<div class="title">Server time:</div>
				<div class="subtitle"><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['show_info_box_last_update_generated']);?>
</div>
			</div>
		</div>
		<div class="a_affiliate">
			<div class="a_status clearfix">
				<div class="title">Your Status:</div>
				<div class="status">Investor</div>
				<div class="info">
										<p>You are able to get standard Multi-Level referral commission 3%-2%-1%</p>
									</div>
			</div>
			<div class="a_aff_banners">
				<ul>
					<li class="b_1 clearfix">
						<span>Banner</span>
						<span>120x120</span>
						<span><a href="?a=referallinks">Show Banner<div class="img"><img src="images/banner_120.gif" width="120" height="120"/></div></a></span>
					</li>
					<li class="b_2 clearfix">
						<span>Banner</span>
						<span>125x125</span>
						<span><a href="?a=referallinks">Show Banner<div class="img"><img src="images/banner_125.gif" width="125" height="125"/></div></a></span>
					</li>
					<li class="b_3 clearfix">
						<span>Banner</span>
						<span>468x60</span>
						<span><a href="?a=referallinks">Show Banner<div class="img"><img src="images/banner_468.gif" width="468" height="60"/></div></a></span>
					</li>
					<li class="b_4 clearfix">
						<span>Banner</span>
						<span>728x90</span>
						<span><a href="?a=referallinks">Show Banner<div class="img"><img src="images/banner_728.gif" width="728" height="90"/></div></a></span>
					</li>
					<li class="b_5 clearfix">
						<span>Banner</span>
						<span>160x600</span>
						<span><a href="?a=referallinks">Show Banner<div class="img"><img src="images/banner_160.gif" width="160" height="600"/></div></a></span>
					</li>
				</ul>
			</div>
			<div class="a_aff_link">
				<div class="link_t">Your referral link:</div>
				<div class="link_o"><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_url']);?>
/?ref=<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['userinfo']->value['username']);?>
</div>
				<a href="?a=referallinks">Banners</a>
			</div>
		</div>
	</div>
</div>

<div class="hidden">
	<span id="a_last_access"><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['last_access']->value);?>
</span>
</div>

					<?php echo $_smarty_tpl->getSubTemplate ("footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);

}
}
?>