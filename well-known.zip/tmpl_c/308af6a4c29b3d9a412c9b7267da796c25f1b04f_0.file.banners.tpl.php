<?php /* Smarty version 3.1.27, created on 2017-06-19 04:18:07
         compiled from "/home/cryptoorbit/public_html/tmpl/custom/banners.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:724575265947507f0660e7_81328204%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '308af6a4c29b3d9a412c9b7267da796c25f1b04f' => 
    array (
      0 => '/home/cryptoorbit/public_html/tmpl/custom/banners.tpl',
      1 => 1481504028,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '724575265947507f0660e7_81328204',
  'variables' => 
  array (
    'settings' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_5947507f11b341_74193733',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5947507f11b341_74193733')) {
function content_5947507f11b341_74193733 ($_smarty_tpl) {
if (!is_callable('smarty_modifier_myescape')) require_once '/home/cryptoorbit/public_html/inc/libs/smarty3/plugins/modifier.myescape.php';

$_smarty_tpl->properties['nocache_hash'] = '724575265947507f0660e7_81328204';
echo $_smarty_tpl->getSubTemplate ("header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>


<h1>Affiliate Banners</h1>
<div class="separator_2"><span></span></div>

<div class="banners_page clearfix">
	<div class="banners_cont">
		<div class="banners_block">
			<h3>Our Landing Page</h3>
			<div class="landing_block">
				<div class="text_1">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</div>
				<div class="text_2">
					<span class="t_1">Your referral link for Landing Page:</span>
					<span class="t_2"><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_url']);?>
/?ref=YOUR_LOGIN&a=cust&page=landing_en</span>
				</div>
			</div>
		</div>
		<div class="banners_block">
			<h3>Banner 120x120</h3>
			<div class="img center"><img src="images/banner_120.gif" width="120" height="120"/></div>
			<textarea><a href="<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_url']);?>
/?ref=YOUR_LOGIN"><img src="<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_url']);?>
/images/banner_120.gif" width="120" height="120"/></a></textarea>
		</div>
		<div class="banners_block">
			<h3>Banner 125x125</h3>
			<div class="img center"><img src="images/banner_125.gif" width="125" height="125"/></div>
			<textarea><a href="<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_url']);?>
/?ref=YOUR_LOGIN"><img src="<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_url']);?>
/images/banner_125.gif" width="125" height="125"/></a></textarea>
		</div>
		<div class="banners_block">
			<h3>Banner 468x60</h3>
			<div class="img center"><img src="images/banner_468.gif" width="468" height="60"/></div>
			<textarea><a href="<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_url']);?>
/?ref=YOUR_LOGIN"><img src="<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_url']);?>
/images/banner_468.gif" width="468" height="60"/></a></textarea>
		</div>
		<div class="banners_block">
			<h3>Banner 728x90</h3>
			<div class="img center"><img src="images/728x90.gif" width="728" height="90"/></div>
			<textarea><a href="<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_url']);?>
/?ref=YOUR_LOGIN"><img src="<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_url']);?>
/images/728x90.gif" width="728" height="90"/></a></textarea>
		</div>
		<div class="banners_block">
			<h3>Banner 160x600</h3>
			<div class="img center"><img src="images/banner_160.gif" width="160" height="600"/></div>
			<textarea><a href="<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_url']);?>
/?ref=YOUR_LOGIN"><img src="<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_url']);?>
/images/banner_160.gif"/></a></textarea>
		</div>
	</div>
</div>
<?php echo $_smarty_tpl->getSubTemplate ("footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);

}
}
?>