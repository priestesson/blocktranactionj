<?php /* Smarty version 3.1.27, created on 2017-12-09 03:48:28
         compiled from "my:ips" */ ?>
<?php
/*%%SmartyHeaderCode:9760841755a2ba35cd3fc41_71432816%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '550826a1b2fb01b3029cc22ad1a932538efae27b' => 
    array (
      0 => 'my:ips',
      1 => 1512809308,
      2 => 'my',
    ),
  ),
  'nocache_hash' => '9760841755a2ba35cd3fc41_71432816',
  'variables' => 
  array (
    'ips' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_5a2ba35cd9ea44_18067216',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5a2ba35cd9ea44_18067216')) {
function content_5a2ba35cd9ea44_18067216 ($_smarty_tpl) {
if (!is_callable('smarty_modifier_myescape')) require_once '/home/dsenemfi/nxtcoininvest.com/inc/libs/smarty3/plugins/modifier.myescape.php';

$_smarty_tpl->properties['nocache_hash'] = '9760841755a2ba35cd3fc41_71432816';
?>
 <table cellspacing=1 cellpadding=2 border=0 width=100<?php echo '%>';?><tr> <td><b>Check IPs for double usage:</b></td> <td align=right><a href="?a=check_ips2">Experemental Mode</a></td> </tr></table> <br> <table cellspacing=1 cellpadding=2 border=0 width=100<?php echo '%>';?> <tr> <th bgcolor=FFEA00 >IP</th><th bgcolor=FFEA00>Quantity</th><th> </tr> <?php if ($_smarty_tpl->tpl_vars['ips']->value) {?> <?php if (isset($_smarty_tpl->tpl_vars['smarty']->value['section']['i'])) unset($_smarty_tpl->tpl_vars['smarty']->value['section']['i']);
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['name'] = 'i';
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['loop'] = is_array($_loop=$_smarty_tpl->tpl_vars['ips']->value) ? count($_loop) : max(0, (int) $_loop); unset($_loop);
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['show'] = true;
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['max'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['loop'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'] = 1;
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['start'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'] > 0 ? 0 : $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['loop']-1;
if ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['show']) {
    $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['total'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['loop'];
    if ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['total'] == 0)
        $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['show'] = false;
} else
    $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['total'] = 0;
if ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['show']):

            for ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['start'], $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration'] = 1;
                 $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration'] <= $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['total'];
                 $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index'] += $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'], $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration']++):
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['rownum'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index_prev'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index'] - $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index_next'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['index'] + $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['step'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['first']      = ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration'] == 1);
$_smarty_tpl->tpl_vars['smarty']->value['section']['i']['last']       = ($_smarty_tpl->tpl_vars['smarty']->value['section']['i']['iteration'] == $_smarty_tpl->tpl_vars['smarty']->value['section']['i']['total']);
?> <tr> <td><a href=?a=check_ips&ip=<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['ips']->value[$_smarty_tpl->getVariable('smarty')->value['section']['i']['index']]['ip']);?>
><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['ips']->value[$_smarty_tpl->getVariable('smarty')->value['section']['i']['index']]['ip']);?>
</a></td> <td align=right><a href=?a=check_ips&ip=<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['ips']->value[$_smarty_tpl->getVariable('smarty')->value['section']['i']['index']]['ip']);?>
><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['ips']->value[$_smarty_tpl->getVariable('smarty')->value['section']['i']['index']]['q']);?>
</a></td> </tr> <?php endfor; endif; ?> <?php } else { ?> <tr><td colspan=3 align=center>No double usage IP found</td></tr> <?php }?> </table><br> <?php }
}
?>