<?php /* Smarty version 3.1.27, created on 2018-02-22 08:25:56
         compiled from "/home/dsenemfi/nxtcoininvest.com/tmpl/custom/get_started.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:15670544115a8ec4e444c705_90826276%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'ada55ca2fa9a3fe79317cfc1353e4009dff16633' => 
    array (
      0 => '/home/dsenemfi/nxtcoininvest.com/tmpl/custom/get_started.tpl',
      1 => 1496463032,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '15670544115a8ec4e444c705_90826276',
  'variables' => 
  array (
    'settings' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_5a8ec4e44b28d9_78757682',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5a8ec4e44b28d9_78757682')) {
function content_5a8ec4e44b28d9_78757682 ($_smarty_tpl) {
if (!is_callable('smarty_modifier_myescape')) require_once '/home/dsenemfi/nxtcoininvest.com/inc/libs/smarty3/plugins/modifier.myescape.php';

$_smarty_tpl->properties['nocache_hash'] = '15670544115a8ec4e444c705_90826276';
echo $_smarty_tpl->getSubTemplate ("header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>


		

<h1>Get Started</h1>
<div class="separator_2"><span></span></div>

<div class="get_started_page">
	<div class="icons_cont">
		<ul class="clearfix">
			<li class="register">
				<div class="icon"></div>
			</li>
			<li class="deposit">
				<div class="icon"></div>
			</li>
			<li class="earning">
				<div class="icon"></div>
			</li>
			<li class="withdraw">
				<div class="icon"></div>
			</li>
		</ul>
	</div>
	<div class="gs_cont">
		<ul class="clearfix">
			<li class="register">
				<div class="gs_block">
					<h3>Open An Account</h3>
					<div class="separator_1"><span></span></div>
					<p>
						To become a member of <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
 - Your Profitable Operator you need first to open a free account. It's quite easy and doesn't take much time, but you will get an opportunity to become an investor and earn profit. For that you must complete the registration process. In order to register yourself as a member of <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
 - Your Profitable Operator, click on the "Create Account" button, fill in the registration form and press "Register". Your account is ready to use! You are obliged to provide only complete and accurate information about yourself (the "Registration Data") when registering as a Member.
					</p>
										<a href="?a=signup" class="custom_link small red">Create Account</a>
									</div>
			</li>
			<li class="deposit">
				<div class="gs_block">
					<h3>Deposit Funds</h3>
					<div class="separator_1"><span></span></div>
					<p>
						To make a deposit, log into your <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
 - Your Profitable Operator's account using your login and password. Choose "Make Deposit" section, select an investment plan most appropriate for you, decide what amount to invest and what term to choose. Select the required electronic payment system (so-called EPS). Pay amount of minimal or maximal deposit that is stated in it in accordance with chosen investment plan. Follow the instructions of EPS and approve the payment finally. Wait for adding funds on your balance. It can take from a few seconds up to few hours. 
					</p>
					<a href="?a=cust&page=our_deposit_methods" class="custom_link small red">Our Deposit Methods</a>
				</div>
			</li>
			<li class="earning">
				<div class="gs_block">
					<h3>Earning Of Profit</h3>
					<div class="separator_1"><span></span></div>
					<p>
						All accruals of profit are done automatically and in accordance with chosen investment plan. Depending on the amount of your deposit and the term of chosen investment period, you will receive guaranteed income after a certain period of time. Your earnings is depending from your investment plan and can be in Daily basis or at the end of investment term. If you choose Daily plans you will get your initial capital back at the end of investment term. For "After" and "VIP" plans which includes both your principal amount and profits, which means that your principal amount will not be returned separately. To calculate your income please use our Profit Calculator.
					</p>
				</div>
			</li>
			<li class="withdraw">
				<div class="gs_block">
					<h3>Withdraw Funds</h3>
					<div class="separator_1"><span></span></div>
					<p>
						When profit is accrued on your account balance, you can withdraw it via electronic payment system. Log into the account, then select the "Withdraw" section. Type an amount, which you want to withdraw, choose payment system and click "Withdraw" button. Now just wait for the money that was requested during the withdrawal at your electronic wallet. Your withdrawal request will be processed in the fastest timeframe possible, as per the online availability of our support staff (up to 30 hours). Please take note that you can withdraw funds only in the same currency as you invested, for example if you invest via PerfectMoney, you will be able to withdraw only via PerfectMoney.
					</p>
				</div>
			</li>
		</ul>
	</div>
</div>
<?php echo $_smarty_tpl->getSubTemplate ("footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);

}
}
?>