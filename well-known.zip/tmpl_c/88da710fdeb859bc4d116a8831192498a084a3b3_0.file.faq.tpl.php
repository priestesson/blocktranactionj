<?php /* Smarty version 3.1.27, created on 2018-02-15 12:07:38
         compiled from "/home/dsenemfi/nxtcoininvest.com/tmpl/faq.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:8035276695a85be5ad11183_00484787%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '88da710fdeb859bc4d116a8831192498a084a3b3' => 
    array (
      0 => '/home/dsenemfi/nxtcoininvest.com/tmpl/faq.tpl',
      1 => 1512851948,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '8035276695a85be5ad11183_00484787',
  'variables' => 
  array (
    'settings' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_5a85be5ae931f6_93583053',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5a85be5ae931f6_93583053')) {
function content_5a85be5ae931f6_93583053 ($_smarty_tpl) {
if (!is_callable('smarty_modifier_myescape')) require_once '/home/dsenemfi/nxtcoininvest.com/inc/libs/smarty3/plugins/modifier.myescape.php';

$_smarty_tpl->properties['nocache_hash'] = '8035276695a85be5ad11183_00484787';
echo $_smarty_tpl->getSubTemplate ("header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>


<h1>Frequently Asked Questions</h1>
<div class="separator_2"><span></span></div>

<div class="faq_page">
	<h2>General questions</h2>
		<div class="separator_1"><span></span></div>
	<div class="faq_block">
		
		<ul class="clearfix">
			<li class="question">
				What is <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
  – Your Profitable Operator?
			</li>
			<li class="answer">
The <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
  – Your Profitable Operator is modern investment program who owned by <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
  LTD based in the United Kingdom. Our Corporate Headquarters is located here: City House, New Station Street, Leeds, LS1 4JE, United Kingdom. <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
  LTD registration number is №10233985.
The <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
  – Your Profitable Operator offers high-return investing in the Crypto Currency - digital currency known as Bitcoin, stock market and Fintech start-ups. Our company is constantly evolving, it improves its marketing components and creates new investment proposals. All this makes the <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
  - Your Profitable Operator an industry leader and to be able to adapt to the constantly changing market conditions.

			</li>
		</ul>
		<div class="separator_3"><span></span></div>
		<ul class="clearfix">
			<li class="question">
				Who controls the Investment portfolio?
			</li>
			<li class="answer">
The investment portfolio is managed by a team of experienced financial specialists, of lawyers, professional trade analysts who have been working on the currency exchange market for more than 10 years on average. Our experience and contacts ensure access for us to a wide range of local and global resources and bring about benefit from the world's best and most effective technologies of trading on the Cryptocurrency market. 
			</li>
		</ul>
		
		
		
		<div class="separator_3"><span></span></div>
		<ul class="clearfix">
			<li class="question">
				Who can participate in <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
  – Your Profitable Operator? Do you accept investors from different countries?
			</li>
			<li class="answer">
				Any person or company can participate in <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
  – Your Profitable Operator. We have no restrictions on any country. The only condition is accepting our terms of service.
			</li>
		</ul>
	
	
		<div class="separator_3"><span></span></div>
		<ul class="clearfix">
			<li class="question">
				What do I need to do to become a member of <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
  – Your Profitable Operator?
			</li>
			<li class="answer">
				To become a member of <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
  – Your Profitable Operator you need first to open a free account. It's quite easy and doesn't take much time, but you will get an opportunity to become an investor and earn profit.
			</li>
		</ul>
		
	<div class="separator_3"><span></span></div>
		<ul class="clearfix">
			<li class="question">
				Can I register several accounts in your program?
			</li>
			<li class="answer">
				You can create 5 (five) separate accounts from your computer (IP address) where is an one account for you and four accounts for your family. If we find more accounts used through the same IP address, we are able to suspend your account temporarily.
			</li>
		</ul>
	
	
	
	<div class="separator_3"><span></span></div>
		<ul class="clearfix">
			<li class="question">
				How can I access the account?
			</li>
			<li class="answer">
				If you are a registered user of <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
  – Your Profitable Operator, please enter your username and password in the suitable fields and click "Login" button. You will be redirected to your account automatically.
			</li>
		</ul>
	
	
	<div class="separator_3"><span></span></div>
		<ul class="clearfix">
			<li class="question">
				How can I change my personal information in my account?
			</li>
			<li class="answer">
				Log into the account and click "Edit Account" to enter the personal information page where you will be able to modify your data. Save the changes when all necessary data are entered. However, you may not modify your e-mail and e-wallet because this function is disabled for security reasons. To make such changes you should contact us via support form and provide full information with your security answer. 
			</li>
		</ul>
	
	
	
	<div class="separator_3"><span></span></div>
		<ul class="clearfix">
			<li class="question">
				What if I can't access my account because I forgot my password?
			</li>
			<li class="answer">
				Click on forgot password link, enter your username or e-mail and follow instruction. You'll receive your account reset information by email.
			</li>
		</ul>
	
	
	
	<div class="separator_3"><span></span></div>
		<ul class="clearfix">
			<li class="question">
				I am unable to log into my account. What might lead to this problem?
			</li>
			<li class="answer">
				Sometimes, problems of this type are caused by your web browser’s errors. You simply require waiting for some minutes and then try to log in once more. First of all you should clean the cache of your web browser. If the problem continues, please contact our support.
			</li>
		</ul>
	
	<div class="separator_3"><span></span></div>
		<ul class="clearfix">
			<li class="question">
				How reliable is <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
  – Your Profitable Operator in terms of security and keeping personal data?
			</li>
			<li class="answer">
				We pay great attention to security and privacy. All information on our website is protected by SSL. <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
  – Your Profitable Operator doesn’t divulge any personal data of our customers to third parties. Your participation is strictly confidential. For details check the link: <a href="?a=cust&page=security">Security</a>
			</li>
		</ul>
	
	
	</div>
	
	
	
	
	
	<h2>Your investment questions</h2>
		<div class="separator_1"><span></span></div>
	<div class="faq_block">
		
		<ul class="clearfix">
			<li class="question">
				What do I need to start investing with <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
  – Your Profitable Operator ?
			</li>
			<li class="answer">
				First of all, you need to register a new account, select an investment plan and make a deposit at least $10 through the available payment systems. For details check the link: <a href="?a=cust&page=get_started">Get Started</a>
			</li>
		</ul>
		<div class="separator_3"><span></span></div>
		<ul class="clearfix">
			<li class="question">
				What payment methods can I use to fund my account?
			</li>
			<li class="answer">
				We operate with payment systems Perfect Money, Payeer, Bitcoin, AdvCash and NixMoney.
			</li>
		</ul>
		
		<div class="separator_3"><span></span></div>
		<ul class="clearfix">
			<li class="question">
				What is the minimum/maximum amount allowed to deposit?
			</li>
			<li class="answer">
				Currently we have an introductory low deposit minimum amount of $100 and going up to $100000 which is the maximum allowed for a single deposit and depends on your investment plan. You are able to check min. and max. amount for each plan in our main page and your account menu "Make Deposit"
			</li>
		</ul>
		
		<div class="separator_3"><span></span></div>
		<ul class="clearfix">
			<li class="question">
				Do you charge any fee for providing your investment services?
			</li>
			<li class="answer">
				No, we do not charge any fees. The profit that we make from our overall investments is enough for us. We do not need to charge any fees for any transaction, however, payment processors may charge you with receiving fees and we have no control over that.
			</li> 
		</ul>
		<div class="separator_3"><span></span></div>
		<ul class="clearfix">
			<li class="question">
				How long does it take for my deposit to be added to my account?
			</li>
			<li class="answer">
				Your account will be updated as soon as you send a payment. For Bitcoin deposits it can take up to few hours. 
			</li>
		</ul>
		<div class="separator_3"><span></span></div>
		<ul class="clearfix">
			<li class="question">
				Can I make numerous deposits simultaneously?
			</li>
			<li class="answer">
				Yes, it is possible for you to have an unlimited number of deposits, but each of them will be processed separately.
			</li>
		</ul>
		
		
		<div class="separator_3"><span></span></div>
		<ul class="clearfix">
			<li class="question">
				Can you reinvest deposit without my participation?
			</li>
			<li class="answer">
				Yes, for default this option works for some investment plans, for example "1.20% Daily for 180 Days" plan has such option so you shouldn't reinvest your principal yourself.
			</li>
		</ul>
		
		
		<div class="separator_3"><span></span></div>
		<ul class="clearfix">
			<li class="question">
				Can I deposit directly from my account balance?
			</li>
			<li class="answer"> 
				Yes! To make a deposit from your account balance, simply log into your account and click "Make Deposit" and select "Deposit" from "Account Balance" button.
			</li>
		</ul>
		
		<div class="separator_3"><span></span></div>
		<ul class="clearfix">
			<li class="question">
				How long does it usually take for a withdrawal request to be processed?
			</li>
			<li class="answer"> 
				Withdrawal requests may take a few hours up to 30 hours to be processed.
			</li>
		</ul>
		
		<div class="separator_3"><span></span></div>
		<ul class="clearfix">
			<li class="question">
				Can there be delays on a withdrawal request?
			</li>
			<li class="answer"> 
				The delay of a withdrawal sometimes can happen because of an unstable operation of payment systems or some maintenance work on the website. In such case the website administration has to wait for normalization of the situation and only then may pay out. It can take several hours up to 2-3 days; therefore we encourage you to be tolerant. In case of a long pause we will inform on all current conditions by means of our forms of communication.
			</li>
		</ul>
		
		
		<div class="separator_3"><span></span></div>
		<ul class="clearfix">
			<li class="question">
				What could be the reason for the delay more than 30 hours? 
			</li>
			<li class="answer"> 
				There are several reasons for failure to pay:<br>
• The e-currency account number, which is to be specified during registration, is missing or incorrect.<br>
• You have balance limit imposed on your e-currency account. Please contact e-currency provider to sort this problem out. <br>
				
			</li>
		</ul>
		
	
		<div class="separator_3"><span></span></div>
		<ul class="clearfix">
			<li class="question">
				What is the minimum and maximum amount that can be withdrawn?
			</li>
			<li class="answer"> 
				The minimum withdrawal amount is only $0.20 and the maximum amount is not limited.
			</li>
		</ul>
		
			<div class="separator_3"><span></span></div>
		<ul class="clearfix">
			<li class="question">
				How can I get my money via BankWire Transfer?
			</li>
			<li class="answer"> 
				The minimum amount for BankWire transfer is $3,000  <br>
  
   You should provide beneficiary's Details: <br>
 
  1)  Beneficiary's Name Enter the full name of the beneficiary client. <br>
  2)  Beneficiary's Address Enter the beneficiary's Address if known. <br>
  3)  Account Number Enter the beneficiary's Account Number if known. <br>
  4) Bank Name Enter the beneficiary's Bank name. <br>
  5) IBAN Enter the Bank's IBAN number. <br>
  6) Bank Identifier Code (BIC) or SWIFT: This is the unique identification code of a particular bank, it is also referred to as a Swift code.
			</li>
		</ul>
		
		
		
		
		
		
		<div class="separator_3"><span></span></div>
		<ul class="clearfix">
			<li class="question">
				Do you process withdrawal requests on weekends? &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			</li>
			<li class="answer"> 
				Yes, we process withdrawal requests 7 days a week.   
			</li>
		</ul>
		
		<div class="separator_3"><span></span></div>
		<ul class="clearfix">
			<li class="question">
				How can I check my account balance?
			</li>
			<li class="answer"> 
				You can access the account information 24 hours, seven days a week over the Internet.
			</li>
		</ul>
		
		
		
		<div class="separator_3"><span></span></div>
		<ul class="clearfix">
			<li class="question">
				What is the risk for my investment?
			</li>
			<li class="answer"> 
				There is always a risk of losing the invested funds. For instance, in case negative worldwide procedures occur that are not effectively managed by the management of the firm. Currency Trading, Crypto Currency Trading investing are among the riskiest forms of investments in the financial markets. But, our team is made up of experts who can foretell such instances and expertly keep away from them. So, the risk of losing investments is extremely low.
			</li>
		</ul>
		
	</div>
	
	<h2>Questions about referral program</h2>
		<div class="separator_1"><span></span></div>
	<div class="faq_block">
		
		<ul class="clearfix">
			<li class="question">
				Do you have an affiliate program?
			</li>
			<li class="answer">
				Yes, we do. Referral program is a unique opportunity to earn with <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
  - Your Profitable Operator, without making an investment. 
				The referral program uses multilevel referral commission which will pay 5% from each deposit of level 1 referrals, 2% from each deposit made by your level 2 referrals (people referred by your direct invitees) and 1% of each deposit made by your level 3 referrals (i. e. people referred by your level 2 invitees). 
			</li>
		</ul>
		<div class="separator_3"><span></span></div>
		<ul class="clearfix">
			<li class="question">
				How will I receive my referral commission?
			</li>
			<li class="answer">
				The commission for referral is immediately added to your account balance. The referral bonus can only be withdrawn in the e-currency which your referral used to make their deposit, for example, if your referral used Perfect Money to deposit, then you may only withdraw your referral bonus in Perfect Money.
			</li>
		</ul>
	
	
	<div class="separator_3"><span></span></div>
		<ul class="clearfix">
			<li class="question">
				Where can I get my referral links and your banners?
			</li>
			<li class="answer">
				You can find your referral link in your main account menu. The personal referral link has the following format: https://<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
 /?ref=Roberto, where "Roberto" is your username in <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
  - Your Profitable Operator. Please log in and go to "Referral Links", you can also find our banners in Our Banners section.
			</li>
		</ul>
	
	<div class="separator_3"><span></span></div>
		<ul class="clearfix">
			<li class="question">
				How do you know that a new investor was introduced by me?
			</li>
			<li class="answer">
				The referral system works during registration and is fully automatic. When an investor signs up via your referral link, the system will treat this investor as your referral.
			</li>
		</ul>
		
	</div>
	
	<b> 
	
	
	If you have not found the answer to your question please contact support, you will definitely get answer to your question. </b>
	
	
</div>

<?php echo $_smarty_tpl->getSubTemplate ("footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>
					<?php }
}
?>