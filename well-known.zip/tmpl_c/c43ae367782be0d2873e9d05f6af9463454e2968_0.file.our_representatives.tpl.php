<?php /* Smarty version 3.1.27, created on 2018-02-22 07:40:41
         compiled from "/home/dsenemfi/nxtcoininvest.com/tmpl/custom/our_representatives.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:5102519525a8eba493f6958_84789280%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'c43ae367782be0d2873e9d05f6af9463454e2968' => 
    array (
      0 => '/home/dsenemfi/nxtcoininvest.com/tmpl/custom/our_representatives.tpl',
      1 => 1511769940,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '5102519525a8eba493f6958_84789280',
  'variables' => 
  array (
    'settings' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_5a8eba49521122_70334267',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5a8eba49521122_70334267')) {
function content_5a8eba49521122_70334267 ($_smarty_tpl) {
if (!is_callable('smarty_modifier_myescape')) require_once '/home/dsenemfi/nxtcoininvest.com/inc/libs/smarty3/plugins/modifier.myescape.php';

$_smarty_tpl->properties['nocache_hash'] = '5102519525a8eba493f6958_84789280';
$_smarty_tpl->tpl_vars["allow"] = new Smarty_Variable("all", null, 0);?>
<?php $_smarty_tpl->tpl_vars["meta_title"] = new Smarty_Variable('', null, 0);?>
<?php echo $_smarty_tpl->getSubTemplate ("header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>

<h1>Our Representatives</h1>

<div class="separator_2">&nbsp;</div>

<div class="rep_page">
<p>To be a Regional Representative of <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
 is a privilege and an opportunity to become a partner in the ready trusted Company. In order to become our company&#39;s Regional Representative you have to show us to have the ability to attract referrals, to help and guide them in every issue and problem that they can have, to support and promote our project in your geographic region via organizing training seminars, holding regional advertising campaigns, consulting clients on the services of the company, etc. It is a high revenue share that is discussed individually with administrative department. We offer additional bonuses such as: referral commission, partner bonus, special bonuses for responsible cooperation clients for referral commission, etc.</p>

<p>If you want to become a Regional Representative of our program, please email your personal details:<br />
You should provide next information:<br />
Your Country:<br />
Your Name:<br />
Your Username in our Program:<br />
Your E-mail:<br />
Your Language Spoken:<br />
Your Skype:<br />
Your Facebook or any other Social Network:<br />
Your Telephone if it available:<br />
<br />
If you are interested in <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
 regional representative program and wish to become our regional representative in your Country, please write us to partnership@nxtcoininvest.com,<br />
We will contact you within few days to discuss the opportunity of further cooperation. A personal manager will be assigned to every regional representative working for us. We are waiting for your requests with personal and contact details to get status of official representative in your region.</p>
<br />
We will contact you within few days to discuss the opportunity of further cooperation. A personal manager will be assigned to every regional representative working for us. We are waiting for your requests with personal and contact details to get status of official representative in your region.
<h2>Approved Regional Representatives</h2>

<div class="separator_1">&nbsp;</div>

<table>
	<tbody>
		<tr>
			<td>Username</td>
			<td>Country</td>
			<td>Name</td>
			<td>Language</td>
			<td>Contacts</td>
		</tr>
		<tr>
			<td><a href="?ref=Cooop">Cooop</a></td>
			<td>
			<div class="country" style="background-image: url(img/flag/Austria.png);">Austria</div>
			</td>
			<td>Oliver Hatz</td>
			<td>German, English</td>
			<td>
			<ul>
				<li><a class="icon" href="https://www.facebook.com/" target="_blank">oliverhatz</a></li>
				<li><a class="icon" href="https://twitter.com/DJSoundlounge" target="_blank">DJSoundlounge</a></li>
				<!--<li class="gp"><a href="https://plus.google.com/" class="icon" target="_blank"><span>Google +</span></a></li>
					<li class="sk"><a href="skype:earntech?add" class="icon"><span>earntech</span></a></li>
					<li class="ph"><span class="icon"><span>+441617680042</span></span></li> -->
				<li>oliver.hatz@gmail.com</li>
			</ul>
			</td>
		</tr>
		<tr><!--<td class="item"><a href="?ref=earntech">earntech</a></td>
			<td class="item"><div class="country" style="background-image: url(img/flag/Belgium.png);">Belgium</div></td>
			<td class="item"><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
</td>
			<td class="item">Dutch, English</td>
			<td class="item">
				<ul class="rep_contacts">
					<li class="fb"><a href="https://www.facebook.com/" class="icon" target="_blank"><span>Facebook</span></a></li>
					<li class="vk"><a href="https://vk.com/" class="icon" target="_blank"><span>VKontakte</span></a></li>
					<li class="tw"><a href="https://twitter.com/" class="icon" target="_blank"><span>Twitter</span></a></li>
					<li class="ph"><span class="icon"><span>+441617680042</span></span></li>
					<li class="em"><span class="icon"><span>support@earntech.cc</span></span></li>-->
		</tr>
		<tr>
			<td><a href="?ref=fa7141">fa7141</a></td>
			<td>
			<div class="country" style="background-image: url(img/flag/Bangladesh.png);">Bangladesh</div>
			</td>
			<td>Md farhad mamun</td>
			<td>English, Bangla</td>
			<td>
			<ul><!--	<li class="fb"><a href="https://www.facebook.com/" class="icon" target="_blank"><span>Facebook</span></a></li>
					<li class="vk"><a href="https://vk.com/" class="icon" target="_blank"><span>VKontakte</span></a></li>
					<li class="tw"><a href="https://twitter.com/" class="icon" target="_blank"><span>Twitter</span></a></li>
					<li class="gp"><a href="https://plus.google.com/" class="icon" target="_blank"><span>Google +</span></a></li>
					<li class="sk"><a href="skype:earntech?add" class="icon"><span>earntech</span></a></li> -->
				<li>+0177777777</li>
				<li>538@gmail.com</li>
			</ul>
			</td>
		</tr>
		<tr><!--<td class="item"><a href="?ref=earntech">earntech</a></td>
			<td class="item"><div class="country" style="background-image: url(img/flag/China.png);">China</div></td>
			<td class="item"><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
</td>
			<td class="item">Chinese</td>
			<td class="item">
				<ul class="rep_contacts">
					<li class="fb"><a href="https://www.facebook.com/" class="icon" target="_blank"><span>Facebook</span></a></li>
					<li class="ph"><span class="icon"><span>+441617680042</span></span></li>
					<li class="em"><span class="icon"><span>support@earntech.cc</span></span></li>-->
		</tr>
		<tr>
			<td><a href="?ref=softnm">softnm</a></td>
			<td>
			<div class="country" style="background-image: url(img/flag/Greece.png);">Greece</div>
			</td>
			<td>Nick Manolakis</td>
			<td>Greek,English</td>
			<td>
			<ul>
				<li><a class="icon" href="https://www.facebook.com/" target="_blank">manolakis.nikos</a></li>
				<!-- <li class="tw"><a href="https://twitter.com/" class="icon" target="_blank"><span>Twitter</span></a></li>
					<li class="gp"><a href="https://plus.google.com/" class="icon" target="_blank"><span>Google +</span></a></li> -->
				<li><a class="icon" href="skype:nikmaniac?add">nikmaniac</a></li>
				<li>+441617680042</li>
				<li>softnm@yahoo.com</li>
			</ul>
			</td>
		</tr>
		<tr>
			<td><a href="?ref=Artem91">Artem91</a></td>
			<td>
			<div class="country" style="background-image: url(img/flag/RussianFederation.png);">Russian Federation</div>
			</td>
			<td>Artem</td>
			<td>Russian</td>
			<td>
			<ul>
				<li><a class="icon" href=" https://www.facebook.com/" target="_blank">artem.fadin</a></li>
				<!--<li class="tw"><a href="https://twitter.com/" class="icon" target="_blank"><span>Twitter</span></a></li>
					<li class="gp"><a href="https://plus.google.com/" class="icon" target="_blank"><span>Google +</span></a></li>-->
				<li><a class="icon" href="skype:fernandotorres_9?add">fernandotorres_9</a></li>
				<!--<li class="ph"><span class="icon"><span>+441617680042</span></span></li>-->
				<li>f-torres@mail.ru</li>
			</ul>
			</td>
		</tr>
		<tr>
			<td><a href="?ref=LeX">LeX</a></td>
			<td>
			<div class="country" style="background-image: url(img/flag/RussianFederation.png);">Russian Federation</div>
			</td>
			<td>Alexander Kornienko</td>
			<td>Russian, English</td>
			<td>
			<ul>
				<li><a class="icon" href="https://www.facebook.com/" target="_blank">mr.kornienko</a></li>
				<!--<li class="tw"><a href="https://twitter.com/" class="icon" target="_blank"><span>Twitter</span></a></li>
					<li class="gp"><a href="https://plus.google.com/" class="icon" target="_blank"><span>Google +</span></a></li>-->
				<li><a class="icon" href="skype:mr.kornienko?add">mr.kornienko</a></li>
				<!--<li class="ph"><span class="icon"><span>+441617680042</span></span></li>-->
				<li>sirkornienko@gmail.com</li>
			</ul>
			</td>
		</tr>
		<tr>
			<td><a href="?ref=sanya523">sanya523</a></td>
			<td>
			<div class="country" style="background-image: url(img/flag/RussianFederation.png);">Russian Federation</div>
			</td>
			<td>Alexandr</td>
			<td>Russian</td>
			<td>
			<ul><!-- <li class="fb"><a href="https://www.facebook.com/" class="icon" target="_blank"><span>Facebook</span></a></li>
					<li class="tw"><a href="https://twitter.com/" class="icon" target="_blank"><span>Twitter</span></a></li>
					<li class="gp"><a href="https://plus.google.com/" class="icon" target="_blank"><span>Google +</span></a></li>
					<li class="sk"><a href="skype:earntech?add" class="icon"><span>earntech</span></a></li>-->
				<li>+79685281144</li>
				<li>1075932@mail.ru</li>
			</ul>
			</td>
		</tr>
		<tr>
			<td><a href="?ref=visinvest">visinvest</a></td>
			<td>
			<div class="country" style="background-image: url(img/flag/RussianFederation.png);">Russian Federation</div>
			</td>
			<td>Anton</td>
			<td>Russian</td>
			<td>
			<ul>
				<li><a class="icon" href="https://vk.com/id77067379" target="_blank">https://vk.com/id77067379</a></li>
				<!-- <li class="fb"><a href="https://www.facebook.com/" class="icon" target="_blank"><span>Facebook</span></a></li>
					<li class="tw"><a href="https://twitter.com/" class="icon" target="_blank"><span>Twitter</span></a></li>
					<li class="gp"><a href="https://plus.google.com/" class="icon" target="_blank"><span>Google +</span></a></li>-->
				<li><a class="icon" href="skype:visotarus25?add">visotarus25</a></li>
				<li>+79273837761</li>
				<li>visinvest.net@gmail.com</li>
			</ul>
			</td>
		</tr>
		<tr>
			<td><a href="?ref=Bull">Bull</a></td>
			<td>
			<div class="country" style="background-image: url(img/flag/RussianFederation.png);">Russian Federation</div>
			</td>
			<td>Alexander Bulahov</td>
			<td>Russian, English</td>
			<td>
			<ul><!-- <li class="fb"><a href="https://www.facebook.com/" class="icon" target="_blank"><span>Facebook</span></a></li>
					<li class="tw"><a href="https://twitter.com/" class="icon" target="_blank"><span>Twitter</span></a></li>
					<li class="gp"><a href="https://plus.google.com/" class="icon" target="_blank"><span>Google +</span></a></li>-->
				<li><a class="icon" href="skype:bull0121?add">bull0121</a></li>
				<!--<li class="ph"><span class="icon"><span>+441617680042</span></span></li>-->
				<li>012bull@gmail.com</li>
			</ul>
			</td>
		</tr>
		<tr>
			<td><a href="?ref=Karim">Karim</a></td>
			<td>
			<div class="country" style="background-image: url(img/flag/RussianFederation.png);">Russian Federation</div>
			</td>
			<td>Denis</td>
			<td>Russian</td>
			<td>
			<ul><!--	<li class="tw"><a href="https://twitter.com/" class="icon" target="_blank"><span>Twitter</span></a></li> --><!--	<li class="gp"><a href="https://plus.google.com/" class="icon" target="_blank"><span>Google +</span></a></li> -->
				<li><a class="icon" href="https://vk.com/einvestbiz" target="_blank">VKontakte</a></li>
				<li><a class="icon" href="skype:e-invest.biz?add">e-invest.biz</a></li>
				<!--	<li class="ph"><span class="icon"><span>+441617680042</span></span></li>  -->
				<li>hyippo4ta@gmail.com</li>
			</ul>
			</td>
		</tr>
		<tr>
			<td><a href="?ref=mallgaron">mallgaron</a></td>
			<td>
			<div class="country" style="background-image: url(img/flag/Ukraine.png);">Ukraine</div>
			</td>
			<td>Marina</td>
			<td>Ukrainian, Russian, English</td>
			<td>
			<ul><!--	<li class="tw"><a href="https://twitter.com/" class="icon" target="_blank"><span>Twitter</span></a></li> --><!--	<li class="gp"><a href="https://plus.google.com/" class="icon" target="_blank"><span>Google +</span></a></li> --><!--	<li class="vk"><a href="https://vk.com/einvestbiz" class="icon" target="_blank"><span>VKontakte</span></a></li>  -->
				<li><a class="icon" href="skype:marinka_on-line?add">marinka_on-line</a></li>
				<!--	<li class="ph"><span class="icon"><span>+380969055315</span></span></li>  -->
				<li><a class="icon" href="https://www.facebook.com/marinka.tropina" target="_blank">marinka.tropina</a></li>
				<li>marinka_tropina@mail.ru</li>
			</ul>
			</td>
		</tr>
		<tr>
			<td><a href="?ref=myinvestblog">myinvestblog</a></td>
			<td>
			<div class="country" style="background-image: url(img/flag/Ukraine.png);">Ukraine</div>
			</td>
			<td>Yurii</td>
			<td>English, Russian</td>
			<td>
			<ul>
				<li><a class="icon" href="https://www.facebook.com/myinvestblogru.myinvestblogru/" target="_blank">myinvestblogru.myinvestblogru</a></li>
				<!--<li class="tw"><a href="https://twitter.com/" class="icon" target="_blank"><span>Twitter</span></a></li>
					<li class="gp"><a href="https://plus.google.com/" class="icon" target="_blank"><span>Google +</span></a></li>-->
				<li><a class="icon" href="skype:myinvestblogru.myinvestblogru?add">myinvestblogru.myinvestblogru</a></li>
				<!--<li class="ph"><span class="icon"><span>+441617680042</span></span></li>-->
				<li>E-mail:myinvestblog.ru@gmail.com</li>
			</ul>
			</td>
		</tr>
		<tr><!--<td class="item"><a href="?ref=nripender">nripender</a></td>
			<td class="item"><div class="country" style="background-image: url(img/flag/India.png);">India</div></td>
			<td class="item">Nripender Sharma</td>
			<td class="item">English, Hindi, Punjabi</td>
			<td class="item">
				<ul class="rep_contacts">
				<li class="fb"><a href="https://www.facebook.com/nripender.sharma.9" class="icon" target="_blank"><span>nripender.sharma.9</span></a></li>
					<li class="sk"><a href="skype:Nripender7?add" class="icon"><span>Nripender7</span></a></li>
					<li class="ph"><span class="icon"><span>+91 9416968452</span></span></li>
					<li class="em"><span class="icon"><span>onemenarmy7860@gmail.com</span></span></li>-->
		</tr>
		<tr>
			<td><a href="?ref=trade0">trade0</a></td>
			<td>
			<div class="country" style="background-image: url(img/flag/japan.png);">Japan</div>
			</td>
			<td>Kentaro Adachi</td>
			<td>Japanese</td>
			<td>
			<ul>
				<li><a class="icon" href="https://www.facebook.com/kentaro.adachi.77?ref=bookmarks" target="_blank">Kentaro Adachi</a></li>
				<li><a class="icon" href="skype:buriki.robo?add">buriki.robo</a></li>
				<li>+819060686062</li>
				<li>robot.trade@gmail.com</li>
			</ul>
			</td>
		</tr>
		<tr>
			<td><a href="?ref=fakechan">fakechan</a></td>
			<td>
			<div class="country" style="background-image: url(img/flag/japan.png);">Japan</div>
			</td>
			<td>Yuichiro Tanaka</td>
			<td>Japanese, English</td>
			<td>
			<ul><!--  <li class="fb"><a href="https://www.facebook.com/" class="icon" target="_blank"><span>Facebook</span></a></li>
					<li class="tw"><a href="https://twitter.com/" class="icon" target="_blank"><span>Twitter</span></a></li>
					<li class="gp"><a href="https://plus.google.com/" class="icon" target="_blank"><span>Google +</span></a></li> -->
				<li><a class="icon" href="skype:fakepyo?add">fakepyo</a></li>
				<!--<li class="ph"><span class="icon"><span>+441617680042</span></span></li> -->
				<li>fakepyo@gmail.com</li>
			</ul>
			</td>
		</tr>
		<tr>
			<td><a href="?ref=Raffy09 ">Raffy09</a></td>
			<td>
			<div class="country" style="background-image: url(img/flag/Philippines.png);">Philippines</div>
			</td>
			<td>Raf Ysabelle Bacero</td>
			<td>English, Filipino</td>
			<td>
			<ul>
				<li><a class="icon" href="https://www.facebook.com/bhessy647238?fref=ts/" target="_blank">bhessy647238?fref=ts</a></li>
				<!-- <li class="tw"><a href="https://twitter.com/" class="icon" target="_blank"><span>Twitter</span></a></li>
					<li class="gp"><a href="https://plus.google.com/" class="icon" target="_blank"><span>Google +</span></a></li> -->
				<li><a class="icon" href="skype:raf.bacero21?add">raf.bacero21</a></li>
				<li>+09263433894</li>
				<li>raf_bacero@yahoo.com.ph</li>
			</ul>
			</td>
		</tr>
		<tr>
			<td><a href="?ref=jheiwai">jheiwai</a></td>
			<td>
			<div class="country" style="background-image: url(img/flag/Philippines.png);">Philippines</div>
			</td>
			<td>Jhei Wai</td>
			<td>Filipino, English</td>
			<td>
			<ul>
				<li><a class="icon" href="https://www.facebook.com/jheiwai" target="_blank">jheiwai</a></li>
				<li><a class="icon" href="skype:jheiwai?add">jheiwai</a></li>
				<li>+639358069643</li>
				<li>jheiwai@gmail.com</li>
			</ul>
			</td>
		</tr>
		<tr>
			<td><a href="?ref=bogach8888">bogach8888</a></td>
			<td>
			<div class="country" style="background-image: url(img/flag/Kazakhstan.png);">Kazakhstan</div>
			</td>
			<td>Madi Tambiyev</td>
			<td>Russian</td>
			<td>
			<ul>
				<li><a class="icon" href="https://www.facebook.com/Bogach8888" target="_blank">Bogach8888</a></li>
				<!--<li class="tw"><a href="https://twitter.com/" class="icon" target="_blank"><span>Twitter</span></a></li>
					<li class="gp"><a href="https://plus.google.com/" class="icon" target="_blank"><span>Google +</span></a></li>-->
				<li><a class="icon" href="skype:bogach8888bogach?add">bogach8888bogach</a></li>
				<li>+77765258888</li>
				<li>madi.tambiev@gmail.com</li>
			</ul>
			</td>
		</tr>
		<tr>
			<td><a href="?ref=julietjuly">julietjuly</a></td>
			<td>
			<div class="country" style="background-image: url(img/flag/Nigeria.png);">Nigeria</div>
			</td>
			<td>Juliet Nwankwo</td>
			<td>English</td>
			<td>
			<ul><!--  <li class="fb"><a href="https://www.facebook.com/" class="icon" target="_blank"><span>Facebook</span></a></li>
					<li class="tw"><a href="https://twitter.com/" class="icon" target="_blank"><span>Twitter</span></a></li>
					<li class="gp"><a href="https://plus.google.com/" class="icon" target="_blank"><span>Google +</span></a></li> -->
				<li><a class="icon" href="skype:juliet-nwankwo?add">juliet-nwankwo</a></li>
				<li>+234-7089566727</li>
				<li>E-mail:uchejulymba@gmail.com</li>
			</ul>
			</td>
		</tr>
		<tr>
			<td><a href="?ref=Emmarolex">Emmarolex</a></td>
			<td>
			<div class="country" style="background-image: url(img/flag/Nigeria.png);">Nigeria</div>
			</td>
			<td>Okogwu Emmanuel</td>
			<td>English</td>
			<td>
			<ul>
				<li><a class="icon" href="https://www.facebook.com/" target="_blank">nuel okogwu</a></li>
				<!--<li class="tw"><a href="https://twitter.com/" class="icon" target="_blank"><span>Twitter</span></a></li>
					<li class="gp"><a href="https://plus.google.com/" class="icon" target="_blank"><span>Google +</span></a></li>-->
				<li><a class="icon" href="skype:Nuel2012?add">Nuel2012</a></li>
				<li>+08139097002</li>
				<li>columbus2018@yahoo.com</li>
			</ul>
			</td>
		</tr>
		<tr>
			<td><a href="?ref=richardbrad770">richardbrad770</a></td>
			<td>
			<p><img src="https://www.tsa.gov/profiles/tsa2_gov/themes/tsa_gov_theme/images/icn-us-flag-21px.png" style="height:20px; width:30px" title="usa" /></p>
			</td>
			<td>Richard Brad</td>
			<td>English</td>
			<td>
			<ul>
				<li><a class="icon" href="facebook.com/richardbrad.5" target="_blank">richard.brad.5</a></li>
				<li><a class="icon" href="https://twitter.com/" target="_blank">@richardbrad770</a></li>
				<!-- <li class="gp"><a href="https://plus.google.com/" class="icon" target="_blank"><span>Google +</span></a></li>-->
				<li><a class="icon" href="skype:richardbrad770@outlook.com?add">richardbrad770@outlook.com</a></li>
				<li>&nbsp;</li>
				<li>richardbrad770@gmail.com</li>
			</ul>
			</td>
		</tr>
		<tr>
			<td><a href="?ref=greg">greg</a></td>
			<td>
			<p><img src="https://www.tsa.gov/profiles/tsa2_gov/themes/tsa_gov_theme/images/icn-us-flag-21px.png" style="height:20px; width:30px" title="usa" /></p>

			<p>&nbsp;</p>
			</td>
			<td>Greg bolton</td>
			<td>English</td>
			<td>
			<ul>
				<li>greg</li>
				<!--<li class="tw"><a href="https://twitter.com/" class="icon" target="_blank"><span>Twitter</span></a></li>
					<li class="gp"><a href="https://plus.google.com/" class="icon" target="_blank"><span>Google +</span></a></li>-->
				<li>greg</li>
				<li>gregbolton3214@gmail.com</li>
			</ul>
			</td>
		</tr>
		<tr>
			<td><a href="?ref=Kevinpeter">Kevinpeter</a></td>
			<td>
			<div class="country" style="background-image: url(img/flag/Nigeria.png);">Nigeria</div>
			</td>
			<td>Kevin Peter Gabriel</td>
			<td>English, Hausa</td>
			<td>
			<ul>
				<li><a class="icon" href=" http://facebook.com/kpdanat" target="_blank">kpdanat</a></li>
				<!--<li class="tw"><a href="https://twitter.com/" class="icon" target="_blank"><span>Twitter</span></a></li>
					<li class="gp"><a href="https://plus.google.com/" class="icon" target="_blank"><span>Google +</span></a></li>-->
				<li><a class="icon" href="skype:Kevin.peter1?add">Kevin.peter1</a></li>
				<li>+234 803 5896 187</li>
				<li>kevenpeter@yahoo.com</li>
			</ul>
			</td>
		</tr>
		<tr>
			<td><a href="?ref=hyipincome">hyipincome</a></td>
			<td>
			<div class="country" style="background-image: url(img/flag/Nigeria.png);">Nigeria</div>
			</td>
			<td>James</td>
			<td>English, Yoruba, Pidgin</td>
			<td>
			<ul><!--  <li class="fb"><a href="https://www.facebook.com/" class="icon" target="_blank"><span>Facebook</span></a></li>
					<li class="tw"><a href="https://twitter.com/" class="icon" target="_blank"><span>Twitter</span></a></li>
					<li class="gp"><a href="https://plus.google.com/" class="icon" target="_blank"><span>Google +</span></a></li>
					<li class="sk"><a href="skype:earntech?add" class="icon"><span>earntech</span></a></li>-->
				<li>+2348061168641</li>
				<li>hyipincome01@yahoo.com</li>
			</ul>
			</td>
		</tr>
		<tr>
			<td><a href="?ref=cutetoyin">cutetoyin</a></td>
			<td>
			<div class="country" style="background-image: url(img/flag/Nigeria.png);">Nigeria</div>
			</td>
			<td>Toyin Shoniregun</td>
			<td>English</td>
			<td>
			<ul>
				<li><a class="icon" href="https://www.facebook.com/" target="_blank">ots olu</a></li>
				<li><a class="icon" href="skype:Oluwatoyin.shoniregun?add">Oluwatoyin.shoniregun</a></li>
				<li>+2348052348824</li>
				<li>toyinshoniregun70@gmail.com</li>
			</ul>
			</td>
		</tr>
		<tr>
			<td><a href="?ref=bittu2732015">bittu2732015</a></td>
			<td>
			<div class="country" style="background-image: url(img/flag/India.png);">India</div>
			</td>
			<td>Kushal Das</td>
			<td>Hindi</td>
			<td>
			<ul>
				<li><a class="icon" href=" https://www.facebook.com/profile.php?id=100013951772118" target="_blank">100013951772118</a></li>
				<!-- <li class="tw"><a href="https://twitter.com/" class="icon" target="_blank"><span>Twitter</span></a></li>
					<li class="gp"><a href="https://plus.google.com/" class="icon" target="_blank"><span>Google +</span></a></li>-->
				<li><a class="icon" href="skype:bittu2732015?add">bittu2732015</a></li>
				<!-- <li class="ph"><span class="icon"><span>+441617680042</span></span></li>-->
				<li>bittu2732015@gmail.com</li>
			</ul>
			</td>
		</tr>
		<tr>
			<td><a href="?ref=andresdao">andresdao</a></td>
			<td>
			<div class="country" style="background-image: url(img/flag/Venezuela.png);">Venezuela</div>
			</td>
			<td>Andres</td>
			<td>Spanish, English Italian</td>
			<td>
			<ul>
				<li><a class="icon" href="skype:andres.dao?add">andres.dao</a></li>
				<li>+584122285741</li>
				<li>andresdao@gmail.com</li>
			</ul>
			</td>
		</tr>
		<tr>
			<td><a href="?ref=maga06">maga06</a></td>
			<td>
			<div class="country" style="background-image: url(img/flag/Azerbaijan.png);">Azerbaijan</div>
			</td>
			<td>Mahammad</td>
			<td>Azeri,Russian,Turkish</td>
			<td>
			<ul>
				<li><a class="icon" href="skype:most_wanted647?add">most_wanted647</a></li>
				<li>+994517553563</li>
				<li>anxious91@mail.ru</li>
			</ul>
			</td>
		</tr>
		<tr>
			<td><a href="?ref=malikanwar">malikanwar</a></td>
			<td>
			<div class="country" style="background-image: url(img/flag/Pakistan.png);">Pakistan</div>
			</td>
			<td>Malik Anwar Zia</td>
			<td>English,Urdu,Punjabi,Hindi</td>
			<td>
			<ul>
				<li><a class="icon" href="www.facebook.com/Malik.Advertiser" target="_blank">Malik.Advertiser</a></li>
				<!-- <li class="tw"><a href="https://twitter.com/" class="icon" target="_blank"><span>Twitter</span></a></li>
					<li class="gp"><a href="https://plus.google.com/" class="icon" target="_blank"><span>Google +</span></a></li> -->
				<li><a class="icon" href="skype:malikanwarzia?add">malikanwarzia</a></li>
				<li>+923006039356</li>
				<li>malikmehtabanwar2009@gmail.com</li>
			</ul>
			</td>
		</tr>
		<tr>
			<td><a href="?ref=abdoudz">abdoudz</a></td>
			<td>
			<div class="country" style="background-image: url(img/flag/Algeria.png);">Algeria</div>
			</td>
			<td>Abdou Saad</td>
			<td>English, French, Arabic</td>
			<td>
			<ul>
				<li><a class="icon" href="https://www.facebook.com/karim.karime.52" target="_blank">karim.karime.52</a></li>
				<!--<li class="tw"><a href="https://twitter.com/" class="icon" target="_blank"><span>Twitter</span></a></li>
					<li class="gp"><a href="https://plus.google.com/" class="icon" target="_blank"><span>Google +</span></a></li> -->
				<li><a class="icon" href="skype:abdou.saad3?add">abdou.saad3</a></li>
				<li>+441617680042</li>
				<li>sami_sami1989@hotmail.com</li>
			</ul>
			</td>
		</tr>
		<tr>
			<td><a href="?ref=ELKASHIF000">ELKASHIF000</a></td>
			<td>
			<div class="country" style="background-image: url(img/flag/Egypt.png);">Egypt</div>
			</td>
			<td>Mohamed Elkashif</td>
			<td>Arabic, English</td>
			<td>
			<ul><!--  <li class="fb"><a href="https://www.facebook.com/" class="icon" target="_blank"><span>Facebook</span></a></li>
					<li class="tw"><a href="https://twitter.com/" class="icon" target="_blank"><span>Twitter</span></a></li>
					<li class="gp"><a href="https://plus.google.com/" class="icon" target="_blank"><span>Google +</span></a></li>
					<li class="sk"><a href="skype:earntech?add" class="icon"><span>earntech</span></a></li> -->
				<li>00201157773752</li>
				<li>ELKASHIF000@GMAIL.COM</li>
			</ul>
			</td>
		</tr>
		<tr>
			<td><a href="?ref=Dahal123">Dahal123</a></td>
			<td>
			<div class="country" style="background-image: url(img/flag/Nepal.png);">Nepal</div>
			</td>
			<td>Prashant Dahal</td>
			<td>Hindi, Nepali, English, Maithili, Bojhpuri, Tharu</td>
			<td>
			<ul>
				<li><a class="icon" href="https://www.facebook.com/profile.php?id=100004760406747" target="_blank">100004760406747</a></li>
				<!--<li class="tw"><a href="https://twitter.com/" class="icon" target="_blank"><span>Twitter</span></a></li>
					<li class="gp"><a href="https://plus.google.com/" class="icon" target="_blank"><span>Google +</span></a></li> -->
				<li><a class="icon" href="skype:Admin.Mwrrians?add">Admin.Mwrrians</a></li>
				<li>+919873204875</li>
				<li>CEO@Mwrrians.com</li>
			</ul>
			</td>
		</tr>
		<tr>
			<td><a href="?ref=Lindachen">Lindachen</a></td>
			<td>
			<div class="country" style="background-image: url(img/flag/VietNam.png);">VietNam</div>
			</td>
			<td>Tran Thi Thuy Vinh</td>
			<td>Vietnamese, English</td>
			<td>
			<ul>
				<li><a class="icon" href="https://www.facebook.com/" target="_blank">vinht81@gmail.com</a></li>
				<!--<li class="tw"><a href="https://twitter.com/" class="icon" target="_blank"><span>Twitter</span></a></li>
					<li class="gp"><a href="https://plus.google.com/" class="icon" target="_blank"><span>Google +</span></a></li>-->
				<li><a class="icon" href="skype:Vinhtiep2011?add">Vinhtiep2011</a></li>
				<li>+84904663098</li>
				<li>vinht81@gmail.com</li>
			</ul>
			</td>
		</tr>
	</tbody>
</table>
</div>

<?php echo $_smarty_tpl->getSubTemplate ("footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);

}
}
?>