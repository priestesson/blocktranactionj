<?php /* Smarty version 3.1.27, created on 2018-02-22 17:16:41
         compiled from "/home/dsenemfi/nxtcoininvest.com/tmpl/footer.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:12468790285a8f4149abd643_09197235%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'c1b99ca3d7babfd8094108d119b656896ba82fa8' => 
    array (
      0 => '/home/dsenemfi/nxtcoininvest.com/tmpl/footer.tpl',
      1 => 1481502762,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '12468790285a8f4149abd643_09197235',
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_5a8f4149ac33d8_64635367',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5a8f4149ac33d8_64635367')) {
function content_5a8f4149ac33d8_64635367 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '12468790285a8f4149abd643_09197235';
?>
</div>
		</section>
				<?php echo $_smarty_tpl->getSubTemplate ("footer2.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>

<?php }
}
?>