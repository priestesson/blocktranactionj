<?php /* Smarty version 3.1.27, created on 2018-02-22 17:16:41
         compiled from "/home/dsenemfi/nxtcoininvest.com/tmpl/support.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:21411189995a8f41499f7e98_79890329%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'bd2069865637c919d7f39eaa27cb1be42bc563d1' => 
    array (
      0 => '/home/dsenemfi/nxtcoininvest.com/tmpl/support.tpl',
      1 => 1512842637,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '21411189995a8f41499f7e98_79890329',
  'variables' => 
  array (
    'say' => 0,
    'userinfo' => 0,
    'settings' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_5a8f4149a69367_80900386',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5a8f4149a69367_80900386')) {
function content_5a8f4149a69367_80900386 ($_smarty_tpl) {
if (!is_callable('smarty_modifier_myescape')) require_once '/home/dsenemfi/nxtcoininvest.com/inc/libs/smarty3/plugins/modifier.myescape.php';

$_smarty_tpl->properties['nocache_hash'] = '21411189995a8f41499f7e98_79890329';
echo $_smarty_tpl->getSubTemplate ("header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>


		

<h1>Contact Us</h1>
<div class="separator_2"><span></span></div>

<div class="support_page">
	<div class="contact_wrap">
		<?php echo '<script'; ?>
 async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAOvTgQeAP4IDy7bsXZq5aRwcu1JK-P9Zc&callback=initMap"><?php echo '</script'; ?>
>
		
	
<?php if ($_smarty_tpl->tpl_vars['say']->value == 'send') {?>
Message has been successfully sent. We will back to you in next 24 hours. Thank you.<br><br>
<?php } else { ?>

<?php echo '<script'; ?>
 language=javascript>
<?php if ($_smarty_tpl->tpl_vars['userinfo']->value['logged'] == 1) {?>

function checkform() { 
  if (document.mainform.message.value == '') {
    alert("Please type your message!");
    document.mainform.message.focus();
    return false;
  }
  return true;
}

<?php } else { ?>

function checkform() {
  if (document.mainform.name.value == '') {
    alert("Please type your full name!");
    document.mainform.name.focus();
    return false;
  }
  if (document.mainform.email.value == '') {
    alert("Please enter your e-mail address!");
    document.mainform.email.focus();
    return false;
  }
  if (document.mainform.message.value == '') {
    alert("Please type your message!");
    document.mainform.message.focus();
    return false;
  }
  return true;
}

<?php }?>
<?php echo '</script'; ?>
>
		
		<div id="google_map" class="google_map"></div>
		<ul class="contact_cont">
			<li><span>Main Office:</span> City House, New Station Street, Leeds, LS1 4JE, United Kingdom</li>
			<li><span></span></li> 
			<li><span>E-mail:</span>nxtcoininvest@gmail.com</li>
			<li>Company <span>№10233985</span> <a href="media/cert.pdf" target="_blank"></a></li>
		</ul>
	</div>
	<h2>Support Form</h2>
	To prevent missing emails from <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
's mail server, please check your emails Spam or Junk folder to ensure the message was not filtered. 
	<div class="separator_1"><span></span></div>
	<div class="sf_wrap">
						<form method="post" name="mainform">
			<input type="hidden" name="a" value="support">
			<input type="hidden" name="action" value="send">
			<div class="sf_cont">
				<ul class="clearfix">
					<li>
						<div class="message error hidden">Please type your full name!</div>
												<div class="input_block username">
							<input type="text" name="name" value="" placeholder="Your Name">
						</div>
											</li>
					<li>
						<div class="message error error_1 hidden">Please enter your e-mail address!</div>
						<div class="message error error_2 hidden">That is not a valid e-mail address!</div>
												<div class="input_block email">
							<input type="text" name="email" value="" placeholder="Your E-mail">
						</div>
											</li>
				</ul>
				<div class="textarea">
					<div class="message error hidden">Please type your message!</div>
					<textarea name="message" placeholder="Your Message"></textarea>
				</div>
								<div class="validation full clearfix">
								<?php if ($_smarty_tpl->tpl_vars['userinfo']->value['validation_enabled'] == 1) {?>
					<div class="message error hidden">Please enter validation number!</div>
					<div class="v_image" style="background: #424242 url(?a=show_validation_image&`$userinfo.session_name`=`$userinfo.session_id`&rand=`$userinfo.rand`"|encurl}) no-repeat center center;"></div>
					<input type=text name=validation_number placeholder="Enter validation number">
				</div> <?php }?>
								<div class="submit">
					<input type="submit" value="Send Message">
				</div>
			</div>
		</form>
			</div> <?php }?>
	<div class="rep_sup">
		<h1>Regional Representatives</h1>
		<p>You are able to find an official representative in your Country.</p>
		<div class="separator_2"><span></span></div>
		<a href="?a=cust&page=our_representatives" class="custom_link big red">Our Representatives</a>
	</div>
	
	<!--
	<h1><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
 International</h1>
	<div class="separator_2"><span></span></div>
	<div class="oo_cont clearfix">
		<div class="oo_block clearfix">
			<div class="o_img" style="background-image: url(img/offices/office_1.jpg);"></div>
			<ul>
				<li class="address"><span>Address:</span> 39th Floor. Tower Financial Center, 50th Street and corner of Elvira, Mendez street, Panama City, Panama</li>
				<li class="phone"><span>Phone:</span>soon</li>
				<li class="email"><span>Email:</span> panama_office@forexking.biz  <br>  Regional Manager - Alexandr Fisher</li>
			</ul>
		</div>
		<div class="oo_block clearfix">
			<div class="o_img" style="background-image: url(img/offices/office_2.jpg);"></div>
			<ul>
				<li class="address"><span>Address:</span> 45th Floor The Lee Gardens, Hong-Kong, 33 Hysan Avenue, Causeway Bay, Hong-Kong</li>
				<li class="phone"><span>Phone:</span> soon</li>
				<li class="email"><span>Email:</span> hong-kong_office@forexking.biz <br>  Regional Manager - Raymond Margulis</li>
			</ul>
		</div>
		<div class="oo_block clearfix">
			<div class="o_img" style="background-image: url(img/offices/office_3.jpg);"></div>
			<ul>
				<li class="address"><span>Address:</span> 29th Floor, 1 Raffles Place, Downtown Core, Singapore, 048616, <br> Singapore <br></li>
				<li class="phone"><span>Phone:</span> soon</li>
				<li class="email"><span>Email:</span> singapore_office@forexking.biz <br> Regional Manager - Oskar Pihelgas    </li>
			</ul>
		</div>
		
		-->
	</div>
</div>

					<?php echo $_smarty_tpl->getSubTemplate ("footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);

}
}
?>