<?php /* Smarty version 3.1.27, created on 2018-02-16 08:12:21
         compiled from "/home/dsenemfi/nxtcoininvest.com/tmpl/referal.links.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:612326595a86d8b5ae66b6_66795302%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'eef1faf38c7fbee7ce794779432f906794faeb2d' => 
    array (
      0 => '/home/dsenemfi/nxtcoininvest.com/tmpl/referal.links.tpl',
      1 => 1452757410,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '612326595a86d8b5ae66b6_66795302',
  'variables' => 
  array (
    'settings' => 0,
    'user' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_5a86d8b5ba20f6_68105772',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5a86d8b5ba20f6_68105772')) {
function content_5a86d8b5ba20f6_68105772 ($_smarty_tpl) {
if (!is_callable('smarty_modifier_myescape')) require_once '/home/dsenemfi/nxtcoininvest.com/inc/libs/smarty3/plugins/modifier.myescape.php';

$_smarty_tpl->properties['nocache_hash'] = '612326595a86d8b5ae66b6_66795302';
echo $_smarty_tpl->getSubTemplate ("header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>


<h3>Referral Links.</h3><br><br>

<a href="<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_url']);?>
/<?php echo smarty_modifier_myescape(encurl("?ref=".((string)$_smarty_tpl->tpl_vars['user']->value['username'])));?>
">
The best internet investment<br>
Earn a XXX% daily profit!
</a>

<br><br>
<textarea class=inpts cols=60 rows=4>
<a href=<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_url']);?>
/<?php echo smarty_modifier_myescape(encurl("?ref=".((string)$_smarty_tpl->tpl_vars['user']->value['username'])));?>
>
The best internet investment<br>
Earn a XXX% daily profit!
</a>
</textarea><br><br><br>


<a href=<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_url']);?>
/<?php echo smarty_modifier_myescape(encurl("?ref=".((string)$_smarty_tpl->tpl_vars['user']->value['username'])));?>
>
<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
.<br>
Easy. Safe. No risk.
</a>

<br><br>
<textarea class=inpts cols=60 rows=4>
<a href=<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_url']);?>
/<?php echo smarty_modifier_myescape(encurl("?ref=".((string)$_smarty_tpl->tpl_vars['user']->value['username'])));?>
>
<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
.<br>
Easy. Safe. No risk.
</a>
</textarea><br><br><br>


<a href=<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_url']);?>
/<?php echo smarty_modifier_myescape(encurl("?ref=".((string)$_smarty_tpl->tpl_vars['user']->value['username'])));?>
>
XX% daily for X weeks - total XX% guaranteed
</a>
<br><br>
<textarea class=inpts cols=60 rows=4>
<a href=<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_url']);?>
/<?php echo smarty_modifier_myescape(encurl("?ref=".((string)$_smarty_tpl->tpl_vars['user']->value['username'])));?>
>
XX% daily for X weeks - total XX% guaranteed
</a>
</textarea><br><br><br>



<?php echo $_smarty_tpl->getSubTemplate ("footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>

<?php }
}
?>