<?php /* Smarty version 3.1.27, created on 2017-06-20 16:54:01
         compiled from "/home/cryptoorbit/public_html/tmpl/header.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:4958828159495329077015_77879517%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '5246ac0601218ea89f1964b9f30cf7eae69f0285' => 
    array (
      0 => '/home/cryptoorbit/public_html/tmpl/header.tpl',
      1 => 1481505996,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '4958828159495329077015_77879517',
  'variables' => 
  array (
    'userinfo' => 0,
    'settings' => 0,
    'currency_sign' => 0,
    'last_access' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_5949532909da38_59390328',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5949532909da38_59390328')) {
function content_5949532909da38_59390328 ($_smarty_tpl) {
if (!is_callable('smarty_modifier_myescape')) require_once '/home/cryptoorbit/public_html/inc/libs/smarty3/plugins/modifier.myescape.php';

$_smarty_tpl->properties['nocache_hash'] = '4958828159495329077015_77879517';
echo $_smarty_tpl->getSubTemplate ("logo.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>

			
			<?php if ($_smarty_tpl->tpl_vars['userinfo']->value['logged'] != 1) {?>
			<div class="h_bottom all">
												<div class="hb_arrow"></div>
				<div class="all_cogwheel"></div>
																<div class="hb_bottom all">
					<div class="container clearfix">
						<ul class="h_stat">
							<li>
								<div class="icon icon_1"><span></span></div>
								<div class="hs_info">
									<div class="title">Running Days</div>
									<div class="subtitle"><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_days_online_generated']);?>
</div>
								</div>
							</li>
							<li>
								<div class="icon icon_2"><span></span></div>
								<div class="hs_info">
									<div class="title">Total Accounts</div>
									<div class="subtitle"><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['info_box_total_accounts_generated']);?>
</div>
								</div>
							</li>
							<li>
								<div class="icon icon_3"><span></span></div>
								<div class="hs_info">
									<div class="title">Total Deposited</div>
									<div class="subtitle"><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['currency_sign']->value);?>
 <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['info_box_deposit_funds_generated']);?>
</div>
								</div>
							</li>
							<li>
								<div class="icon icon_4"><span></span></div>
								<div class="hs_info">
									<div class="title">Total Withdraw</div>
									<div class="subtitle"><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['currency_sign']->value);?>
 <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['info_box_withdraw_funds_generated']);?>
</div>
								</div>
							</li>
						</ul>
						<ul class="get_started">
							<li><span class="text">It's time to take the next step!</span></li>
							<li>
								<a href="?a=cust&page=get_started">Get Started Today</a>
								<div class="sub_menu left">
									<ul>
										<li><a href="?a=cust&page=get_started">Get Started Guide</a></li>
										<li><a href="?a=cust&page=our_deposit_methods">Our Deposit Methods</a></li>
										<li><a href="?a=cust&page=popular_exchangers">Popular Exchangers</a></li>
									</ul>
								</div>
							</li>
						</ul>
					</div>
				</div>
							</div> <?php } else { ?>  <div class="h_bottom auth">
												<div class="hb_arrow"></div>
				<div class="auth_cogwheel"></div>
																<div class="hb_bottom auth">
					<div class="auth_button_bg ab_left"></div>
					<div class="auth_button_bg ab_right"></div>
					<div class="container clearfix">
						<ul class="header_auth_list clearfix">
							<li>
								<div class="ha_button deposit clearfix">
									<div class="icon"><span></span></div>
									<a href="?a=deposit">Make Deposit</a>
								</div>
							</li>
							<li>
								<div class="ha_info">
									<div class="ha_user">Hello <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['userinfo']->value['username']);?>
!</div>
									<div class="loading"></div>
									<div class="ha_info_cont"><div>Registration Date: <span><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['userinfo']->value['create_account_date']);?>
</span></div><div>Last Access: <span id="last_access"><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['last_access']->value);?>
</span></div><div>Your Status: <span>Investor</span></div></div>
								</div>
							</li>
							<li>
								<div class="ha_button withdraw clearfix">
									<div class="icon"><span></span></div>
									<a href="?a=withdraw">Withdraw</a>
								</div>
							</li>
						</ul>
					</div>
				</div>
							</div><?php }?>
		</header>
				<section class="wrapper">
			<div data-parallaxify-range-x="-30" class="parallax ip_parallax_1"></div>
			<div data-parallaxify-range-x="30" class="parallax ip_parallax_2"></div>
			<div class="container"><?php }
}
?>