<?php /* Smarty version 3.1.27, created on 2017-11-27 03:54:24
         compiled from "my:tmpl_postback" */ ?>
<?php
/*%%SmartyHeaderCode:1536983385a1bd2c08a9a42_15655870%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'ff05f7aee0ad7987920608a24bcf8c4f4dab1cb2' => 
    array (
      0 => 'my:tmpl_postback',
      1 => 1511772864,
      2 => 'my',
    ),
  ),
  'nocache_hash' => '1536983385a1bd2c08a9a42_15655870',
  'variables' => 
  array (
    'settings' => 0,
    'no_transactions' => 0,
    'transactions' => 0,
    'btc_confirmations' => 0,
    't' => 0,
    'deposit_added' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_5a1bd2c091cce9_21995162',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5a1bd2c091cce9_21995162')) {
function content_5a1bd2c091cce9_21995162 ($_smarty_tpl) {
if (!is_callable('smarty_modifier_myescape')) require_once '/home/dsenemfi/nxtcoininvest.com/inc/libs/smarty3/plugins/modifier.myescape.php';

$_smarty_tpl->properties['nocache_hash'] = '1536983385a1bd2c08a9a42_15655870';
?>
 <html> <head><link href="<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_url']);?>
/style.css" rel="stylesheet" type="text/css"></head> <body onload="update_status_from_iframe()"> <?php echo '<script'; ?>
 language=javascript>  function update_status_from_iframe() { window.parent.document.getElementById("placeforstatus").innerHTML = document.documentElement.innerHTML; }  <?php echo '</script'; ?>
> <?php if ($_smarty_tpl->tpl_vars['no_transactions']->value) {?> <b>Order status:</b> Waiting for payment<Br> <?php echo '<script'; ?>
 language=javascript> window.parent.document.getElementById("btc_form").style.display = ""; window.parent.document.getElementById("coin_payment_image").style.display = "";  <?php echo '</script'; ?>
> <?php } else { ?> <?php if ($_smarty_tpl->tpl_vars['transactions']->value) {?> <?php echo '<script'; ?>
 language=javascript> window.parent.document.getElementById("btc_form").style.display = "none"; window.parent.document.getElementById("coin_payment_image").style.display = "none"; <?php echo '</script'; ?>
> <b>Order status:</b> Waiting for <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['btc_confirmations']->value);?>
 confirmations<br> <?php
$_from = $_smarty_tpl->tpl_vars['transactions']->value;
if (!is_array($_from) && !is_object($_from)) {
settype($_from, 'array');
}
$_smarty_tpl->tpl_vars['t'] = new Smarty_Variable;
$_smarty_tpl->tpl_vars['t']->_loop = false;
foreach ($_from as $_smarty_tpl->tpl_vars['t']->value) {
$_smarty_tpl->tpl_vars['t']->_loop = true;
$foreach_t_Sav = $_smarty_tpl->tpl_vars['t'];
?> Payment: <a href=https://blockchain.info/tx/<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['t']->value['txid']);?>
 target=_blank><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['t']->value['txid']);?>
</a> ( <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['t']->value['confirmations']);?>
 confirmations).<br> 
 <?php
$_smarty_tpl->tpl_vars['t'] = $foreach_t_Sav;
}
?> <?php }?> <?php if (!$_smarty_tpl->tpl_vars['transactions']->value && $_smarty_tpl->tpl_vars['deposit_added']->value == 1) {?> <b>Order status:</b> Deposit created <?php echo '<script'; ?>
 language=javascript> setTimeout('window.top.location.href = "<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_url']);?>
/index.php?a=return_egold&process=yes"; ', 2000); <?php echo '</script'; ?>
> <?php }?> <?php }?> <?php echo '<script'; ?>
 language=javascript> setTimeout("location.reload()", 30000); <?php echo '</script'; ?>
> </body></html> <?php }
}
?>