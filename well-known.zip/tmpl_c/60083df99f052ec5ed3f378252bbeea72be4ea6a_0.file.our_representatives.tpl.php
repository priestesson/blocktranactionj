<?php /* Smarty version 3.1.27, created on 2017-06-20 15:12:00
         compiled from "/home/cryptoorbit/public_html/tmpl/custom/our_representatives.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:41332178059493b40b706b3_25419698%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '60083df99f052ec5ed3f378252bbeea72be4ea6a' => 
    array (
      0 => '/home/cryptoorbit/public_html/tmpl/custom/our_representatives.tpl',
      1 => 1497612139,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '41332178059493b40b706b3_25419698',
  'variables' => 
  array (
    'settings' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_59493b40ccfc84_52844084',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_59493b40ccfc84_52844084')) {
function content_59493b40ccfc84_52844084 ($_smarty_tpl) {
if (!is_callable('smarty_modifier_myescape')) require_once '/home/cryptoorbit/public_html/inc/libs/smarty3/plugins/modifier.myescape.php';

$_smarty_tpl->properties['nocache_hash'] = '41332178059493b40b706b3_25419698';
echo $_smarty_tpl->getSubTemplate ("header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>


<h1>Our Representatives</h1>
<div class="separator_2"><span></span></div>

<div class="rep_page">
	<p class="all_p bg">
To be a Regional Representative of <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
  is a privilege and an opportunity to become a partner in the ready trusted Company. 
In order to become our company's Regional Representative you have to show us to have the ability to attract referrals, to help and guide them in every issue and problem that they can have, to support and promote our project in your geographic region via organizing training seminars, holding regional advertising campaigns, consulting clients on the services of the company, etc. It is a high revenue share that is discussed individually with administrative department. We offer additional bonuses such as: referral commission, partner bonus, special bonuses for responsible cooperation clients for referral commission, etc. 
			</p>
			<p>
If you want to become a Regional Representative of our program, please email your personal details:  <BR>
You should provide next information: <BR>
Your Country: <BR>
Your Name:	<BR>
Your Username in our Program: <BR>
Your E-mail:<BR>
Your Language Spoken:<BR>
Your Skype:<BR>
Your Facebook or any other Social Network:<BR>
Your Telephone if it available:<BR>
<BR>
If you are interested in <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
 regional representative program and wish to become our regional representative in your Country, please write us to partnership@nxtcoininvest.com , <BR>
We will contact you within few days to discuss the opportunity of further cooperation. A personal manager will be assigned to every regional representative working for us. We are waiting for your requests with personal and contact details to get status of official representative in your region.
			</p>
			<BR>We will contact you within few days to discuss the opportunity of further cooperation. A personal manager will be assigned to every regional representative working for us. We are waiting for your requests with personal and contact details to get status of official representative in your region.
	<h2>Approved Regional Representatives</h2>
	<div class="separator_1"><span></span></div>
	<table>
		<tr>
			<td class="inheader">Username</td>
			<td class="inheader">Country</td>
			<td class="inheader">Name</td>
			<td class="inheader">Language</td>
			<td class="inheader" align="right">Contacts</td>
		</tr>
		<tr>
			<td class="item"><a href="?ref=Cooop">Cooop</a></td>
			<td class="item"><div class="country" style="background-image: url(img/flag/Austria.png);">Austria</div></td>
			<td class="item">Oliver Hatz</td>
			<td class="item">German, English</td>
			<td class="item">
				<ul class="rep_contacts">
                                        <li class="fb"><a href="https://www.facebook.com/" class="icon" target="_blank"><span>oliverhatz</span></a></li>
                                        <li class="tw"><a href="https://twitter.com/DJSoundlounge" class="icon" target="_blank"><span>DJSoundlounge</span></a></li>
					<!--<li class="gp"><a href="https://plus.google.com/" class="icon" target="_blank"><span>Google +</span></a></li>
					<li class="sk"><a href="skype:earntech?add" class="icon"><span>earntech</span></a></li>
					<li class="ph"><span class="icon"><span>+441617680042</span></span></li> -->
					<li class="em"><span class="icon"><span>oliver.hatz@gmail.com</span></span></li>
				</ul>
			</td>
		</tr>

		<tr>
			<!--<td class="item"><a href="?ref=earntech">earntech</a></td>
			<td class="item"><div class="country" style="background-image: url(img/flag/Belgium.png);">Belgium</div></td>
			<td class="item"><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
</td>
			<td class="item">Dutch, English</td>
			<td class="item">
				<ul class="rep_contacts">
					<li class="fb"><a href="https://www.facebook.com/" class="icon" target="_blank"><span>Facebook</span></a></li>
					<li class="vk"><a href="https://vk.com/" class="icon" target="_blank"><span>VKontakte</span></a></li>
					<li class="tw"><a href="https://twitter.com/" class="icon" target="_blank"><span>Twitter</span></a></li>
					<li class="ph"><span class="icon"><span>+441617680042</span></span></li>
					<li class="em"><span class="icon"><span>support@earntech.cc</span></span></li>-->
				</ul>
			</td>
		</tr>

		<tr>
			<td class="item"><a href="?ref=fa7141">fa7141</a></td>
			<td class="item"><div class="country" style="background-image: url(img/flag/Bangladesh.png);">Bangladesh</div></td>
			<td class="item">Md farhad mamun</td>
			<td class="item">English, Bangla</td>
			<td class="item">
				<ul class="rep_contacts">
				<!--	<li class="fb"><a href="https://www.facebook.com/" class="icon" target="_blank"><span>Facebook</span></a></li>
					<li class="vk"><a href="https://vk.com/" class="icon" target="_blank"><span>VKontakte</span></a></li>
					<li class="tw"><a href="https://twitter.com/" class="icon" target="_blank"><span>Twitter</span></a></li>
					<li class="gp"><a href="https://plus.google.com/" class="icon" target="_blank"><span>Google +</span></a></li>
					<li class="sk"><a href="skype:earntech?add" class="icon"><span>earntech</span></a></li> -->
					<li class="ph"><span class="icon"><span>+0177777777</span></span></li>  
					<li class="em"><span class="icon"><span>538@gmail.com</span></span></li>
				</ul>
			</td>
		</tr>
		<tr>
			<!--<td class="item"><a href="?ref=earntech">earntech</a></td>
			<td class="item"><div class="country" style="background-image: url(img/flag/China.png);">China</div></td>
			<td class="item"><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
</td>
			<td class="item">Chinese</td>
			<td class="item">
				<ul class="rep_contacts">
					<li class="fb"><a href="https://www.facebook.com/" class="icon" target="_blank"><span>Facebook</span></a></li>
					<li class="ph"><span class="icon"><span>+441617680042</span></span></li>
					<li class="em"><span class="icon"><span>support@earntech.cc</span></span></li>-->
				</ul>
			</td>
		</tr>
                <tr>
			<td class="item"><a href="?ref=softnm">softnm</a></td>
			<td class="item"><div class="country" style="background-image: url(img/flag/Greece.png);">Greece</div></td>
			<td class="item">Nick Manolakis</td>
			<td class="item">Greek,English</td>
			<td class="item">
				<ul class="rep_contacts">
                                        <li class="fb"><a href="https://www.facebook.com/" class="icon" target="_blank"><span>manolakis.nikos</span></a></li>
					<!-- <li class="tw"><a href="https://twitter.com/" class="icon" target="_blank"><span>Twitter</span></a></li>
					<li class="gp"><a href="https://plus.google.com/" class="icon" target="_blank"><span>Google +</span></a></li> -->
					<li class="sk"><a href="skype:nikmaniac?add" class="icon"><span>nikmaniac</span></a></li>
					<li class="ph"><span class="icon"><span>+441617680042</span></span></li>
					<li class="em"><span class="icon"><span>softnm@yahoo.com</span></span></li>
				</ul>
			</td>
		</tr>
                <tr>
			<td class="item"><a href="?ref=Artem91">Artem91</a></td>
			<td class="item"><div class="country" style="background-image: url(img/flag/RussianFederation.png);">Russian Federation</div></td>
			<td class="item">Artem</td>
			<td class="item">Russian</td>
			<td class="item">
				<ul class="rep_contacts">
                                       <li class="fb"><a href=" https://www.facebook.com/" class="icon" target="_blank"><span>artem.fadin</span></a></li>
					<!--<li class="tw"><a href="https://twitter.com/" class="icon" target="_blank"><span>Twitter</span></a></li>
					<li class="gp"><a href="https://plus.google.com/" class="icon" target="_blank"><span>Google +</span></a></li>-->
					<li class="sk"><a href="skype:fernandotorres_9?add" class="icon"><span>fernandotorres_9</span></a></li>
					<!--<li class="ph"><span class="icon"><span>+441617680042</span></span></li>-->
					<li class="em"><span class="icon"><span>f-torres@mail.ru </span></span></li>
				</ul>
			</td>
		</tr>
                <tr>
			<td class="item"><a href="?ref=LeX">LeX</a></td>
			<td class="item"><div class="country" style="background-image: url(img/flag/RussianFederation.png);">Russian Federation</div></td>
			<td class="item">Alexander Kornienko</td>
			<td class="item">Russian, English</td>
			<td class="item">
				<ul class="rep_contacts">
                                       <li class="fb"><a href="https://www.facebook.com/" class="icon" target="_blank"><span>mr.kornienko</span></a></li>
					<!--<li class="tw"><a href="https://twitter.com/" class="icon" target="_blank"><span>Twitter</span></a></li>
					<li class="gp"><a href="https://plus.google.com/" class="icon" target="_blank"><span>Google +</span></a></li>-->
					<li class="sk"><a href="skype:mr.kornienko?add" class="icon"><span>mr.kornienko</span></a></li>
					<!--<li class="ph"><span class="icon"><span>+441617680042</span></span></li>-->
					<li class="em"><span class="icon"><span>sirkornienko@gmail.com</span></span></li>
				</ul>
			</td>
		</tr>
                <tr>
			<td class="item"><a href="?ref=sanya523">sanya523</a></td>
			<td class="item"><div class="country" style="background-image: url(img/flag/RussianFederation.png);">Russian Federation</div></td>
			<td class="item">Alexandr</td>
			<td class="item">Russian</td>
			<td class="item">
				<ul class="rep_contacts">
                                      <!-- <li class="fb"><a href="https://www.facebook.com/" class="icon" target="_blank"><span>Facebook</span></a></li>
					<li class="tw"><a href="https://twitter.com/" class="icon" target="_blank"><span>Twitter</span></a></li>
					<li class="gp"><a href="https://plus.google.com/" class="icon" target="_blank"><span>Google +</span></a></li>
					<li class="sk"><a href="skype:earntech?add" class="icon"><span>earntech</span></a></li>-->
					<li class="ph"><span class="icon"><span>+79685281144</span></span></li>
					<li class="em"><span class="icon"><span>1075932@mail.ru</span></span></li>
				</ul>
			</td>
		</tr>
                <tr>
			<td class="item"><a href="?ref=visinvest">visinvest</a></td>
			<td class="item"><div class="country" style="background-image: url(img/flag/RussianFederation.png);">Russian Federation</div></td>
			<td class="item">Anton</td>
			<td class="item">Russian</td>
			<td class="item">
				<ul class="rep_contacts">
                                       <li class="vk"><a href="https://vk.com/id77067379" class="icon" target="_blank"><span>https://vk.com/id77067379</span></a></li>
                                      <!-- <li class="fb"><a href="https://www.facebook.com/" class="icon" target="_blank"><span>Facebook</span></a></li>
					<li class="tw"><a href="https://twitter.com/" class="icon" target="_blank"><span>Twitter</span></a></li>
					<li class="gp"><a href="https://plus.google.com/" class="icon" target="_blank"><span>Google +</span></a></li>-->
					<li class="sk"><a href="skype:visotarus25?add" class="icon"><span>visotarus25</span></a></li>
					<li class="ph"><span class="icon"><span>+79273837761</span></span></li>
					<li class="em"><span class="icon"><span> visinvest.net@gmail.com</span></span></li>
				</ul>
			</td>
		</tr>
                <tr>
			<td class="item"><a href="?ref=Bull">Bull</a></td>
			<td class="item"><div class="country" style="background-image: url(img/flag/RussianFederation.png);">Russian Federation</div></td>
			<td class="item">Alexander Bulahov</td>
			<td class="item">Russian, English</td>
			<td class="item">
				<ul class="rep_contacts">
                                      <!-- <li class="fb"><a href="https://www.facebook.com/" class="icon" target="_blank"><span>Facebook</span></a></li>
					<li class="tw"><a href="https://twitter.com/" class="icon" target="_blank"><span>Twitter</span></a></li>
					<li class="gp"><a href="https://plus.google.com/" class="icon" target="_blank"><span>Google +</span></a></li>-->
					<li class="sk"><a href="skype:bull0121?add" class="icon"><span>bull0121</span></a></li>
					<!--<li class="ph"><span class="icon"><span>+441617680042</span></span></li>-->
					<li class="em"><span class="icon"><span>012bull@gmail.com</span></span></li>
				</ul>
			</td>
		</tr>
		<tr>
			<td class="item"><a href="?ref=Karim">Karim</a></td>
			<td class="item"><div class="country" style="background-image: url(img/flag/RussianFederation.png);">Russian Federation</div></td>
			<td class="item">Denis</td>
			<td class="item">Russian</td>
			<td class="item">
				<ul class="rep_contacts">
				<!--	<li class="tw"><a href="https://twitter.com/" class="icon" target="_blank"><span>Twitter</span></a></li> --> 
				<!--	<li class="gp"><a href="https://plus.google.com/" class="icon" target="_blank"><span>Google +</span></a></li> -->
				<li class="vk"><a href="https://vk.com/einvestbiz" class="icon" target="_blank"><span>VKontakte</span></a></li>
				<li class="sk"><a href="skype:e-invest.biz?add" class="icon"><span>e-invest.biz</span></a></li>
				<!--	<li class="ph"><span class="icon"><span>+441617680042</span></span></li>  -->
					<li class="em"><span class="icon"><span>hyippo4ta@gmail.com</span></span></li>
				</ul>
			</td>
		</tr>
		
		<tr>
			<td class="item"><a href="?ref=mallgaron">mallgaron</a></td>
			<td class="item"><div class="country" style="background-image: url(img/flag/Ukraine.png);">Ukraine</div></td>
			<td class="item">Marina</td>
			<td class="item">Ukrainian, Russian, English</td>
			<td class="item">
				<ul class="rep_contacts">
				<!--	<li class="tw"><a href="https://twitter.com/" class="icon" target="_blank"><span>Twitter</span></a></li> --> 
				<!--	<li class="gp"><a href="https://plus.google.com/" class="icon" target="_blank"><span>Google +</span></a></li> -->
			<!--	<li class="vk"><a href="https://vk.com/einvestbiz" class="icon" target="_blank"><span>VKontakte</span></a></li>  -->
				<li class="sk"><a href="skype:marinka_on-line?add" class="icon"><span>marinka_on-line</span></a></li>
				<!--	<li class="ph"><span class="icon"><span>+380969055315</span></span></li>  -->
				<li class="fb"><a href="https://www.facebook.com/marinka.tropina" class="icon" target="_blank"><span>marinka.tropina</span></a></li>
					<li class="em"><span class="icon"><span>marinka_tropina@mail.ru</span></span></li>
				</ul>
			</td>
		</tr>
		
		<tr>
			<td class="item"><a href="?ref=myinvestblog">myinvestblog</a></td>
			<td class="item"><div class="country" style="background-image: url(img/flag/Ukraine.png);">Ukraine</div></td>
			<td class="item">Yurii</td>
			<td class="item">English, Russian</td>
			<td class="item">
				<ul class="rep_contacts">
                                       <li class="fb"><a href="https://www.facebook.com/myinvestblogru.myinvestblogru/" class="icon" target="_blank"><span>myinvestblogru.myinvestblogru</span></a></li>
					<!--<li class="tw"><a href="https://twitter.com/" class="icon" target="_blank"><span>Twitter</span></a></li>
					<li class="gp"><a href="https://plus.google.com/" class="icon" target="_blank"><span>Google +</span></a></li>-->
					<li class="sk"><a href="skype:myinvestblogru.myinvestblogru?add" class="icon"><span>myinvestblogru.myinvestblogru</span></a></li>
					<!--<li class="ph"><span class="icon"><span>+441617680042</span></span></li>-->
					<li class="em"><span class="icon"><span>E-mail:myinvestblog.ru@gmail.com</span></span></li>
				</ul>
			</td>
		</tr>
		
		
		<tr>
			<!--<td class="item"><a href="?ref=nripender">nripender</a></td>
			<td class="item"><div class="country" style="background-image: url(img/flag/India.png);">India</div></td>
			<td class="item">Nripender Sharma</td>
			<td class="item">English, Hindi, Punjabi</td>
			<td class="item">
				<ul class="rep_contacts">
				<li class="fb"><a href="https://www.facebook.com/nripender.sharma.9" class="icon" target="_blank"><span>nripender.sharma.9</span></a></li>
					<li class="sk"><a href="skype:Nripender7?add" class="icon"><span>Nripender7</span></a></li>
					<li class="ph"><span class="icon"><span>+91 9416968452</span></span></li>
					<li class="em"><span class="icon"><span>onemenarmy7860@gmail.com</span></span></li>-->
				</ul>
			</td>
		</tr>
		
		<tr>
			<td class="item"><a href="?ref=trade0">trade0</a></td>
			<td class="item"><div class="country" style="background-image: url(img/flag/japan.png);">Japan</div></td>
			<td class="item">Kentaro Adachi</td>
			<td class="item">Japanese</td>
			<td class="item">
				<ul class="rep_contacts">
					<li class="fb"><a href="https://www.facebook.com/kentaro.adachi.77?ref=bookmarks" class="icon" target="_blank"><span>Kentaro Adachi</span></a></li>
					<li class="sk"><a href="skype:buriki.robo?add" class="icon"><span>buriki.robo</span></a></li>
					<li class="ph"><span class="icon"><span>+819060686062</span></span></li>
					<li class="em"><span class="icon"><span>robot.trade@gmail.com</span></span></li>
				</ul>
			</td>
		</tr>
                <tr>
			<td class="item"><a href="?ref=fakechan">fakechan</a></td>
			<td class="item"><div class="country" style="background-image: url(img/flag/japan.png);">Japan</div></td>
			<td class="item">Yuichiro Tanaka</td>
			<td class="item">Japanese, English</td>
			<td class="item">
				<ul class="rep_contacts">
                                     <!--  <li class="fb"><a href="https://www.facebook.com/" class="icon" target="_blank"><span>Facebook</span></a></li>
					<li class="tw"><a href="https://twitter.com/" class="icon" target="_blank"><span>Twitter</span></a></li>
					<li class="gp"><a href="https://plus.google.com/" class="icon" target="_blank"><span>Google +</span></a></li> -->
					<li class="sk"><a href="skype:fakepyo?add" class="icon"><span>fakepyo</span></a></li>
					<!--<li class="ph"><span class="icon"><span>+441617680042</span></span></li> -->
					<li class="em"><span class="icon"><span>fakepyo@gmail.com</span></span></li>
				</ul>
			</td>
		</tr>
		<tr>
			<td class="item"><a href="?ref=Raffy09 ">Raffy09</a></td>
			<td class="item"><div class="country" style="background-image: url(img/flag/Philippines.png);">Philippines</div></td>
			<td class="item">Raf Ysabelle Bacero</td>
			<td class="item">English, Filipino</td>
			<td class="item">
				<ul class="rep_contacts">
                                        <li class="fb"><a href="https://www.facebook.com/bhessy647238?fref=ts/" class="icon" target="_blank"><span>bhessy647238?fref=ts</span></a></li>
					<!-- <li class="tw"><a href="https://twitter.com/" class="icon" target="_blank"><span>Twitter</span></a></li>
					<li class="gp"><a href="https://plus.google.com/" class="icon" target="_blank"><span>Google +</span></a></li> -->
					<li class="sk"><a href="skype:raf.bacero21?add" class="icon"><span>raf.bacero21</span></a></li>
					<li class="ph"><span class="icon"><span>+09263433894</span></span></li>
					<li class="em"><span class="icon"><span>raf_bacero@yahoo.com.ph</span></span></li>
				</ul>
			</td>
		</tr>
		
		<tr>
			<td class="item"><a href="?ref=jheiwai">jheiwai</a></td>
			<td class="item"><div class="country" style="background-image: url(img/flag/Philippines.png);">Philippines</div></td>
			<td class="item"> Jhei Wai</td>
			<td class="item">Filipino, English</td>
			<td class="item">
				<ul class="rep_contacts">
					<li class="fb"><a href="https://www.facebook.com/jheiwai" class="icon" target="_blank"><span>jheiwai</span></a></li>
					<li class="sk"><a href="skype:jheiwai?add" class="icon"><span>jheiwai</span></a></li>
					<li class="ph"><span class="icon"><span>+639358069643</span></span></li>
					<li class="em"><span class="icon"><span>jheiwai@gmail.com</span></span></li>
				</ul>
			</td>
		</tr>
                <tr>
			<td class="item"><a href="?ref=bogach8888">bogach8888</a></td>
			<td class="item"><div class="country" style="background-image: url(img/flag/Kazakhstan.png);">Kazakhstan</div></td>
			<td class="item">Madi Tambiyev</td>
			<td class="item">Russian</td>
			<td class="item">
				<ul class="rep_contacts">
                                       <li class="fb"><a href="https://www.facebook.com/Bogach8888" class="icon" target="_blank"><span>Bogach8888</span></a></li>
					<!--<li class="tw"><a href="https://twitter.com/" class="icon" target="_blank"><span>Twitter</span></a></li>
					<li class="gp"><a href="https://plus.google.com/" class="icon" target="_blank"><span>Google +</span></a></li>-->
					<li class="sk"><a href="skype:bogach8888bogach?add" class="icon"><span>bogach8888bogach</span></a></li>
					<li class="ph"><span class="icon"><span>+77765258888</span></span></li>
					<li class="em"><span class="icon"><span>madi.tambiev@gmail.com</span></span></li>
				</ul>
			</td>
		</tr>
		<tr>
			<td class="item"><a href="?ref=julietjuly">julietjuly</a></td>
			<td class="item"><div class="country" style="background-image: url(img/flag/Nigeria.png);">Nigeria</div></td>
			<td class="item">Juliet Nwankwo</td>
			<td class="item">English</td>
			<td class="item">
				<ul class="rep_contacts">
                                     <!--  <li class="fb"><a href="https://www.facebook.com/" class="icon" target="_blank"><span>Facebook</span></a></li>
					<li class="tw"><a href="https://twitter.com/" class="icon" target="_blank"><span>Twitter</span></a></li>
					<li class="gp"><a href="https://plus.google.com/" class="icon" target="_blank"><span>Google +</span></a></li> -->
					<li class="sk"><a href="skype:juliet-nwankwo?add" class="icon"><span>juliet-nwankwo</span></a></li>
					<li class="ph"><span class="icon"><span>+234-7089566727</span></span></li>
					<li class="em"><span class="icon"><span>E-mail:uchejulymba@gmail.com</span></span></li>
				</ul>
			</td>
		</tr>
                <tr>
			<td class="item"><a href="?ref=Emmarolex">Emmarolex</a></td>
			<td class="item"><div class="country" style="background-image: url(img/flag/Nigeria.png);">Nigeria</div></td>
			<td class="item">Okogwu Emmanuel</td>
			<td class="item">English</td>
			<td class="item">
				<ul class="rep_contacts">
                                       <li class="fb"><a href="https://www.facebook.com/" class="icon" target="_blank"><span>nuel okogwu</span></a></li>
					<!--<li class="tw"><a href="https://twitter.com/" class="icon" target="_blank"><span>Twitter</span></a></li>
					<li class="gp"><a href="https://plus.google.com/" class="icon" target="_blank"><span>Google +</span></a></li>-->
					<li class="sk"><a href="skype:Nuel2012?add" class="icon"><span>Nuel2012</span></a></li>
					<li class="ph"><span class="icon"><span>+08139097002</span></span></li>
					<li class="em"><span class="icon"><span>columbus2018@yahoo.com</span></span></li>
				</ul>
			</td>
		</tr>
                <tr>
			<td class="item"><a href="?ref=phoenixlord">phoenixlord</a></td>
			<td class="item"><div class="country" style="background-image: url(img/flag/Nigeria.png);">Nigeria</div></td>
			<td class="item">Adepoju Fatai</td>
			<td class="item">English, Yoruba</td>
			<td class="item">
				<ul class="rep_contacts">
                                       <li class="fb"><a href="facebook.com/adepoju.fatai.5" class="icon" target="_blank"><span>adepoju.fatai.5</span></a></li>
					<li class="tw"><a href="https://twitter.com/" class="icon" target="_blank"><span>@daphoenixlord</span></a></li>
					<!-- <li class="gp"><a href="https://plus.google.com/" class="icon" target="_blank"><span>Google +</span></a></li>-->
					<li class="sk"><a href="skype:phoenixxlord@outlook.com?add" class="icon"><span>phoenixxlord@outlook.com</span></a></li>
					<li class="ph"><span class="icon"><span>+2347060868888</span></span></li>
					<li class="em"><span class="icon"><span>adepojufatai@gmail.com</span></span></li>
				</ul>
			</td>
		</tr>
                <tr>
			<td class="item"><a href="?ref=Emma4cas">Emma4cas</a></td>
			<td class="item"><div class="country" style="background-image: url(img/flag/Nigeria.png);">Nigeria</div></td>
			<td class="item">Emmanuel Olagunju</td>
			<td class="item">English</td>
			<td class="item">
				<ul class="rep_contacts">
                                       <li class="fb"><a href="https://www.facebook.com/emmacas/" class="icon" target="_blank"><span>emmacas</span></a></li>
					<!--<li class="tw"><a href="https://twitter.com/" class="icon" target="_blank"><span>Twitter</span></a></li>
					<li class="gp"><a href="https://plus.google.com/" class="icon" target="_blank"><span>Google +</span></a></li>-->
					<li class="sk"><a href="skype:emmacas2009?add" class="icon"><span>emmacas2009</span></a></li>
					<li class="ph"><span class="icon"><span>+2348053337970</span></span></li>
					<li class="em"><span class="icon"><span>divineolag@gmail.com</span></span></li>
				</ul>
			</td>
		</tr>
                <tr>
			<td class="item"><a href="?ref=Kevinpeter">Kevinpeter</a></td>
			<td class="item"><div class="country" style="background-image: url(img/flag/Nigeria.png);">Nigeria</div></td>
			<td class="item">Kevin Peter Gabriel</td>
			<td class="item"> English, Hausa</td>
			<td class="item">
				<ul class="rep_contacts">
                                       <li class="fb"><a href=" http://facebook.com/kpdanat" class="icon" target="_blank"><span>kpdanat</span></a></li>
					<!--<li class="tw"><a href="https://twitter.com/" class="icon" target="_blank"><span>Twitter</span></a></li>
					<li class="gp"><a href="https://plus.google.com/" class="icon" target="_blank"><span>Google +</span></a></li>-->
					<li class="sk"><a href="skype:Kevin.peter1?add" class="icon"><span>Kevin.peter1</span></a></li>
					<li class="ph"><span class="icon"><span>+234 803 5896 187</span></span></li>
					<li class="em"><span class="icon"><span>kevenpeter@yahoo.com</span></span></li>
				</ul>
			</td>
		</tr>
                <tr>
			<td class="item"><a href="?ref=hyipincome">hyipincome</a></td>
			<td class="item"><div class="country" style="background-image: url(img/flag/Nigeria.png);">Nigeria</div></td>
			<td class="item">James</td>
			<td class="item">English, Yoruba, Pidgin</td>
			<td class="item">
				<ul class="rep_contacts">
                                     <!--  <li class="fb"><a href="https://www.facebook.com/" class="icon" target="_blank"><span>Facebook</span></a></li>
					<li class="tw"><a href="https://twitter.com/" class="icon" target="_blank"><span>Twitter</span></a></li>
					<li class="gp"><a href="https://plus.google.com/" class="icon" target="_blank"><span>Google +</span></a></li>
					<li class="sk"><a href="skype:earntech?add" class="icon"><span>earntech</span></a></li>-->
					<li class="ph"><span class="icon"><span>+2348061168641</span></span></li>
					<li class="em"><span class="icon"><span>hyipincome01@yahoo.com</span></span></li>
				</ul>
			</td>
		</tr>
                
		<tr>
			<td class="item"><a href="?ref=cutetoyin">cutetoyin</a></td>
			<td class="item"><div class="country" style="background-image: url(img/flag/Nigeria.png);">Nigeria</div></td>
			<td class="item">Toyin Shoniregun</td>
			<td class="item">English</td>
			<td class="item">
				<ul class="rep_contacts">
					<li class="fb"><a href="https://www.facebook.com/" class="icon" target="_blank"><span>ots olu</span></a></li>
					<li class="sk"><a href="skype:Oluwatoyin.shoniregun?add" class="icon"><span>Oluwatoyin.shoniregun</span></a></li>
					<li class="ph"><span class="icon"><span>+2348052348824</span></span></li>
					<li class="em"><span class="icon"><span>toyinshoniregun70@gmail.com</span></span></li>
				</ul>
			</td>
		</tr>
		
		
		<tr>
			<td class="item"><a href="?ref=bittu2732015">bittu2732015</a></td>
			<td class="item"><div class="country" style="background-image: url(img/flag/India.png);">India</div></td>
			<td class="item">Kushal Das</td>
			<td class="item">Hindi</td>
			<td class="item">
				<ul class="rep_contacts">
                                       <li class="fb"><a href=" https://www.facebook.com/profile.php?id=100013951772118" class="icon" target="_blank"><span>100013951772118</span></a></li>
					<!-- <li class="tw"><a href="https://twitter.com/" class="icon" target="_blank"><span>Twitter</span></a></li>
					<li class="gp"><a href="https://plus.google.com/" class="icon" target="_blank"><span>Google +</span></a></li>-->
					<li class="sk"><a href="skype:bittu2732015?add" class="icon"><span>bittu2732015</span></a></li>
					<!-- <li class="ph"><span class="icon"><span>+441617680042</span></span></li>-->
					<li class="em"><span class="icon"><span>bittu2732015@gmail.com</span></span></li>
				</ul>
			</td>
		</tr>
		
		
		
		
		<tr>
			<td class="item"><a href="?ref=andresdao">andresdao</a></td>
			<td class="item"><div class="country" style="background-image: url(img/flag/Venezuela.png);">Venezuela</div></td>
			<td class="item">Andres</td>
			<td class="item">Spanish, English Italian</td>
			<td class="item">
				<ul class="rep_contacts">
					
					<li class="sk"><a href="skype:andres.dao?add" class="icon"><span>andres.dao</span></a></li>
					<li class="ph"><span class="icon"><span>+584122285741</span></span></li>
					<li class="em"><span class="icon"><span>andresdao@gmail.com</span></span></li>
				</ul>
			</td>
		</tr>
		
		
		<tr>
			<td class="item"><a href="?ref=maga06">maga06</a></td>
			<td class="item"><div class="country" style="background-image: url(img/flag/Azerbaijan.png);">Azerbaijan</div></td>
			<td class="item">Mahammad</td>
			<td class="item">Azeri,Russian,Turkish</td>
			<td class="item">
				<ul class="rep_contacts">
					
					<li class="sk"><a href="skype:most_wanted647?add" class="icon"><span>most_wanted647</span></a></li>
					<li class="ph"><span class="icon"><span> +994517553563</span></span></li>
					<li class="em"><span class="icon"><span>anxious91@mail.ru</span></span></li>
				</ul>
			</td>
		</tr>
		
		
		
		<tr>
			<td class="item"><a href="?ref=malikanwar">malikanwar</a></td>
			<td class="item"><div class="country" style="background-image: url(img/flag/Pakistan.png);">Pakistan</div></td>
			<td class="item"> Malik Anwar Zia</td>
			<td class="item">English,Urdu,Punjabi,Hindi</td>
			<td class="item">
				<ul class="rep_contacts">
                                        <li class="fb"><a href="www.facebook.com/Malik.Advertiser" class="icon" target="_blank"><span>Malik.Advertiser</span></a></li>
					<!-- <li class="tw"><a href="https://twitter.com/" class="icon" target="_blank"><span>Twitter</span></a></li>
					<li class="gp"><a href="https://plus.google.com/" class="icon" target="_blank"><span>Google +</span></a></li> -->
					<li class="sk"><a href="skype:malikanwarzia?add" class="icon"><span>malikanwarzia</span></a></li>
					<li class="ph"><span class="icon"><span>+923006039356</span></span></li>
					<li class="em"><span class="icon"><span>malikmehtabanwar2009@gmail.com</span></span></li>
				</ul>
			</td>
		</tr>
		<tr>
			<td class="item"><a href="?ref=abdoudz">abdoudz</a></td>
			<td class="item"><div class="country" style="background-image: url(img/flag/Algeria.png);">Algeria</div></td>
			<td class="item">Abdou Saad</td>
			<td class="item">English, French, Arabic</td>
			<td class="item">
				<ul class="rep_contacts">
                                       <li class="fb"><a href="https://www.facebook.com/karim.karime.52" class="icon" target="_blank"><span>karim.karime.52</span></a></li>
					<!--<li class="tw"><a href="https://twitter.com/" class="icon" target="_blank"><span>Twitter</span></a></li>
					<li class="gp"><a href="https://plus.google.com/" class="icon" target="_blank"><span>Google +</span></a></li> -->
					<li class="sk"><a href="skype:abdou.saad3?add" class="icon"><span>abdou.saad3</span></a></li>
					<li class="ph"><span class="icon"><span>+441617680042</span></span></li>
					<li class="em"><span class="icon"><span>sami_sami1989@hotmail.com</span></span></li>
				</ul>
			</td>
		</tr>
		
		<tr>
			<td class="item"><a href="?ref=ELKASHIF000">ELKASHIF000</a></td>
			<td class="item"><div class="country" style="background-image: url(img/flag/Egypt.png);">Egypt</div></td>
			<td class="item">Mohamed Elkashif</td>
			<td class="item">Arabic, English</td>
			<td class="item">
				<ul class="rep_contacts">
                                     <!--  <li class="fb"><a href="https://www.facebook.com/" class="icon" target="_blank"><span>Facebook</span></a></li>
					<li class="tw"><a href="https://twitter.com/" class="icon" target="_blank"><span>Twitter</span></a></li>
					<li class="gp"><a href="https://plus.google.com/" class="icon" target="_blank"><span>Google +</span></a></li>
					<li class="sk"><a href="skype:earntech?add" class="icon"><span>earntech</span></a></li> -->
					<li class="ph"><span class="icon"><span>00201157773752</span></span></li>
					<li class="em"><span class="icon"><span>ELKASHIF000@GMAIL.COM</span></span></li>
				</ul>
			</td>
		</tr>
		
		<tr>
			<td class="item"><a href="?ref=Dahal123">Dahal123</a></td>
			<td class="item"><div class="country" style="background-image: url(img/flag/Nepal.png);">Nepal</div></td>
			<td class="item">Prashant Dahal</td>
			<td class="item">Hindi, Nepali, English, Maithili, Bojhpuri, Tharu </td>
			<td class="item">
				<ul class="rep_contacts">
                                       <li class="fb"><a href="https://www.facebook.com/profile.php?id=100004760406747" class="icon" target="_blank"><span>100004760406747</span></a></li>
					<!--<li class="tw"><a href="https://twitter.com/" class="icon" target="_blank"><span>Twitter</span></a></li>
					<li class="gp"><a href="https://plus.google.com/" class="icon" target="_blank"><span>Google +</span></a></li> -->
					<li class="sk"><a href="skype:Admin.Mwrrians?add" class="icon"><span>Admin.Mwrrians</span></a></li>
					<li class="ph"><span class="icon"><span>+919873204875</span></span></li>
					<li class="em"><span class="icon"><span>CEO@Mwrrians.com</span></span></li>
				</ul>
			</td>
		</tr>
		<tr>
			<td class="item"><a href="?ref=Lindachen">Lindachen</a></td>
			<td class="item"><div class="country" style="background-image: url(img/flag/VietNam.png);">VietNam</div></td>
			<td class="item">Tran Thi Thuy Vinh</td>
			<td class="item">Vietnamese, English</td>
			<td class="item">
				<ul class="rep_contacts">
                                       <li class="fb"><a href="https://www.facebook.com/" class="icon" target="_blank"><span>vinht81@gmail.com</span></a></li>
					<!--<li class="tw"><a href="https://twitter.com/" class="icon" target="_blank"><span>Twitter</span></a></li>
					<li class="gp"><a href="https://plus.google.com/" class="icon" target="_blank"><span>Google +</span></a></li>-->
					<li class="sk"><a href="skype:Vinhtiep2011?add" class="icon"><span>Vinhtiep2011</span></a></li>
					<li class="ph"><span class="icon"><span>+84904663098</span></span></li>
					<li class="em"><span class="icon"><span>vinht81@gmail.com</span></span></li>
				</ul>
			</td>
		</tr>
		
		
	</table>
</div>

			<?php echo $_smarty_tpl->getSubTemplate ("footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);

}
}
?>