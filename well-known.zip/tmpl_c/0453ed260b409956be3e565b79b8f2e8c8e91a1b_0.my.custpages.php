<?php /* Smarty version 3.1.27, created on 2017-11-27 02:14:11
         compiled from "my:custpages" */ ?>
<?php
/*%%SmartyHeaderCode:5783612065a1bbb438346c4_12758100%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '0453ed260b409956be3e565b79b8f2e8c8e91a1b' => 
    array (
      0 => 'my:custpages',
      1 => 1511766851,
      2 => 'my',
    ),
  ),
  'nocache_hash' => '5783612065a1bbb438346c4_12758100',
  'variables' => 
  array (
    'settings' => 0,
    'no_custom_folder' => 0,
    'pages' => 0,
    'p' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_5a1bbb438cb884_34721421',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5a1bbb438cb884_34721421')) {
function content_5a1bbb438cb884_34721421 ($_smarty_tpl) {
if (!is_callable('smarty_modifier_myescape')) require_once '/home/dsenemfi/nxtcoininvest.com/inc/libs/smarty3/plugins/modifier.myescape.php';

$_smarty_tpl->properties['nocache_hash'] = '5783612065a1bbb438346c4_12758100';
?>
 <div style="display:none"> <b>Custom pages:</b><br><br> You can add any custom html to our script, for example "Rate Us" html where will be stored links to rating sites.<br><br> To create custom page you should follow the next steps:<br> <li>copy "example.tpl" file to [your_document_name].tpl (for example "rate_us.tpl")</li> <li>Change content of the page with your favorite html editor</li> <li>Upload this file to your server into "tmpl/custom" directory</li> <li>Check result - <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_url']);?>
/?a=cust&page=[your_document_name] <br>Example: <a href=<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_url']);?>
/?a=cust&page=rate_us target=_blank><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_url']);?>
/?a=cust&page=rate_us</a></li> <li>Add this link to the top menu (edit "tmpl/logo.tpl" file) or to the left menu (edit "tmpl/left.tpl" file)</li> </div> <?php if ($_smarty_tpl->tpl_vars['no_custom_folder']->value) {?><b style="color:red">Please, create "tmpl/custom/" folder first!</b><br><br><?php }?> <b>Pages:</b><br><br> <table cellspacing=1 cellpadding=2 border=0 width=100<?php echo '%>';?> <tr> <th bgcolor=FFEA00>Page</th> <th bgcolor=FFEA00>Allow</th> <th bgcolor=FFEA00>Link</th> <th bgcolor=FFEA00>Action</th> </tr> <?php if ($_smarty_tpl->tpl_vars['pages']->value) {?> <?php
$_from = $_smarty_tpl->tpl_vars['pages']->value;
if (!is_array($_from) && !is_object($_from)) {
settype($_from, 'array');
}
$_smarty_tpl->tpl_vars['p'] = new Smarty_Variable;
$_smarty_tpl->tpl_vars['p']->_loop = false;
foreach ($_from as $_smarty_tpl->tpl_vars['p']->value) {
$_smarty_tpl->tpl_vars['p']->_loop = true;
$foreach_p_Sav = $_smarty_tpl->tpl_vars['p'];
?> <tr> <td><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['p']->value['name']);?>
</td> <td><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['p']->value['allow']);?>
</td> <td>?a=page&id=<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['p']->value['name']);?>
</td> <td> <a href="?a=custompages&action=edit&page=<?php echo smarty_modifier_myescape(rawurlencode($_smarty_tpl->tpl_vars['p']->value['name']));?>
">[Edit]</a>&nbsp; <a href="?a=custompages&action=edit&page=<?php echo smarty_modifier_myescape(rawurlencode($_smarty_tpl->tpl_vars['p']->value['name']));?>
" onclick="return confirm('Do you really want completelly remove this page?')">[Delete]</a> </td> </tr> <?php
$_smarty_tpl->tpl_vars['p'] = $foreach_p_Sav;
}
?> <?php } else { ?> <tr><td colspan=3 align=center>No pages found</td></tr> <?php }?> </table><br> <?php echo $_smarty_tpl->getSubTemplate ("my:start_info_table", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>
 To create custom page you should follow the next steps:<br> <li>copy "example.tpl" file to [your_document_name].tpl (for example "rate_us.tpl")</li> <li>Change content of the page with your favorite html editor</li> <li>Upload this file to your server into "tmpl/custom" directory</li> <li>Check result - <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_url']);?>
/?a=cust&page=[your_document_name] <br>Example: <a href=<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_url']);?>
/?a=cust&page=rate_us target=_blank><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_url']);?>
/?a=cust&page=rate_us</a></li> <li>Add this link to the top menu (edit "tmpl/logo.tpl" file) or to the left menu (edit "tmpl/left.tpl" file)</li> <?php echo $_smarty_tpl->getSubTemplate ("my:end_info_table", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>
 <?php }
}
?>