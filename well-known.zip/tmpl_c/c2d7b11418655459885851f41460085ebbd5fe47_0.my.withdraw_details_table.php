<?php /* Smarty version 3.1.27, created on 2017-12-29 18:18:58
         compiled from "my:withdraw_details_table" */ ?>
<?php
/*%%SmartyHeaderCode:20812045025a46cd62ebe553_07972556%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'c2d7b11418655459885851f41460085ebbd5fe47' => 
    array (
      0 => 'my:withdraw_details_table',
      1 => 1514589538,
      2 => 'my',
    ),
  ),
  'nocache_hash' => '20812045025a46cd62ebe553_07972556',
  'variables' => 
  array (
    'user' => 0,
    'exchange_system_name' => 0,
    'trans' => 0,
    'account' => 0,
    'converted_to_withdraw' => 0,
    'settings' => 0,
    'orig_fiat' => 0,
    'to_withdraw' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_5a46cd62f42176_16297152',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5a46cd62f42176_16297152')) {
function content_5a46cd62f42176_16297152 ($_smarty_tpl) {
if (!is_callable('smarty_modifier_myescape')) require_once '/home/dsenemfi/nxtcoininvest.com/inc/libs/smarty3/plugins/modifier.myescape.php';

$_smarty_tpl->properties['nocache_hash'] = '20812045025a46cd62ebe553_07972556';
?>
 <tr> <th>User:</th> <td><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['user']->value['username']);?>
 (<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['user']->value['name']);?>
)</td> </tr> <tr> <th>Payment System:</th> <td><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['exchange_system_name']->value);?>
 <img src="images/<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['trans']->value['ec']);?>
.gif" width=44 height=17 align=absmiddle></td> </tr> <tr> <th>Payee Account:</th> <td><?php echo smarty_modifier_myescape((($tmp = @$_smarty_tpl->tpl_vars['account']->value)===null||$tmp==='' ? "n/a" : $tmp));?>
</td> </tr> <?php if ($_smarty_tpl->tpl_vars['converted_to_withdraw']->value) {?> <tr> <th>Amount:</th> <td><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['currency_sign']);
echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['converted_to_withdraw']->value);?>
</td> </tr> <tr> <th><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['orig_fiat']->value);?>
 Amount:</th> <td><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['to_withdraw']->value);?>
</td> </tr> <?php } else { ?> <tr> <th>Amount:</th> <td><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['currency_sign']);
echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['to_withdraw']->value);?>
</td> </tr> <?php }?> <tr> <th>User Comment:</th> <td><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['trans']->value['description']);?>
</td> </tr><?php }
}
?>