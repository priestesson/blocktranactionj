<?php /* Smarty version 3.1.27, created on 2017-12-15 12:55:15
         compiled from "/home/dsenemfi/nxtcoininvest.com/tmpl/change_compound.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:1727989365a340c83a616e5_29251286%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '10a64fb0a69878c9a95a6d4919d2c808044540df' => 
    array (
      0 => '/home/dsenemfi/nxtcoininvest.com/tmpl/change_compound.tpl',
      1 => 1442782298,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1727989365a340c83a616e5_29251286',
  'variables' => 
  array (
    'fatal' => 0,
    'frm' => 0,
    'deposit' => 0,
    'currency_sign' => 0,
    'type' => 0,
    'compound_percents' => 0,
    'p' => 0,
    'settings' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_5a340c83b3c039_24267262',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5a340c83b3c039_24267262')) {
function content_5a340c83b3c039_24267262 ($_smarty_tpl) {
if (!is_callable('smarty_modifier_myescape')) require_once '/home/dsenemfi/nxtcoininvest.com/inc/libs/smarty3/plugins/modifier.myescape.php';

$_smarty_tpl->properties['nocache_hash'] = '1727989365a340c83a616e5_29251286';
echo $_smarty_tpl->getSubTemplate ("header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>


<h3>Change Compounding Percent:</h3><br>

<?php if ($_smarty_tpl->tpl_vars['fatal']->value) {?>
 <?php if ($_smarty_tpl->tpl_vars['fatal']->value == 'deposit_not_found') {?>Wrong deposit ID has been provided<?php }?>
 <?php if ($_smarty_tpl->tpl_vars['fatal']->value == 'compound_forbidden') {?>Compounding is not available for your deposit<?php }?>
<?php } else { ?>

<?php echo '<script'; ?>
>

function openCalculator(id)
{
  w = 225; h = 400;
  t = (screen.height-h-30)/2;
  l = (screen.width-w-30)/2;
  window.open('?a=calendar&type=' + id, 'calculator' + id, "top="+t+",left="+l+",width="+w+",height="+h+",resizable=1,scrollbars=0");
}

<?php echo '</script'; ?>
>

<?php if ($_smarty_tpl->tpl_vars['frm']->value['complete']) {?>
 Compounding percent has been successfully changed.
<br><br>
<?php }?>

<form method=post name=change_compound>
<input type=hidden name=a value=change_compound>
<input type=hidden name=action value=change>
<input type=hidden name=deposit value=<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['deposit']->value['id']);?>
>

<table cellspacing=0 cellpadding=2 border=0>
<tr>
 <td colspan=2>
   Change the compounding percent for <b><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['currency_sign']->value);
echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['deposit']->value['deposit']);?>
</b> 
   deposit in the <b><?php echo smarty_modifier_myescape(htmlspecialchars($_smarty_tpl->tpl_vars['type']->value['name'], ENT_QUOTES, 'UTF-8', true));?>
</b>
 </td>
</tr>
<tr>
 <td nowrap width=1<?php echo '%>';?>Compounding percent: </td>
 <td>
  <select name='percent' class=inpts>
<?php
$_from = $_smarty_tpl->tpl_vars['compound_percents']->value;
if (!is_array($_from) && !is_object($_from)) {
settype($_from, 'array');
}
$_smarty_tpl->tpl_vars['i'] = new Smarty_Variable;
$_smarty_tpl->tpl_vars['i']->_loop = false;
$_smarty_tpl->tpl_vars['p'] = new Smarty_Variable;
foreach ($_from as $_smarty_tpl->tpl_vars['p']->value => $_smarty_tpl->tpl_vars['i']->value) {
$_smarty_tpl->tpl_vars['i']->_loop = true;
$foreach_i_Sav = $_smarty_tpl->tpl_vars['i'];
?>
 <option value="<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['p']->value);?>
" <?php if ($_smarty_tpl->tpl_vars['deposit']->value['compound'] == $_smarty_tpl->tpl_vars['p']->value) {?>selected<?php }?>><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['p']->value);?>
</option>
<?php
$_smarty_tpl->tpl_vars['i'] = $foreach_i_Sav;
}
?>
  </select>
 </td>
</tr>
<?php if ($_smarty_tpl->tpl_vars['settings']->value['enable_calculator']) {?>
<tr>
 <td colspan=2><a href="javascript:openCalculator(<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['type']->value['id']);?>
)">Calculate your profit &gt;&gt;</a></td>
</tr>
<?php }?>
<tr>
 <td><a href="<?php echo smarty_modifier_myescape(encurl("?a=deposit_list"));?>
">Return</a></td>
 <td><input type=submit value="Change" class=sbmt></td>
</tr></table>
</form>

<?php }?>

<?php echo $_smarty_tpl->getSubTemplate ("footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>

<?php }
}
?>