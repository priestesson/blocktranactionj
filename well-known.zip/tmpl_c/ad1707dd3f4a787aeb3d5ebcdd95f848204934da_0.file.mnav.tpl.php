<?php /* Smarty version 3.1.27, created on 2017-06-20 15:04:12
         compiled from "/home/cryptoorbit/public_html/tmpl/mnav.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:10745507815949396cd0c5e6_17731846%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'ad1707dd3f4a787aeb3d5ebcdd95f848204934da' => 
    array (
      0 => '/home/cryptoorbit/public_html/tmpl/mnav.tpl',
      1 => 1481512952,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '10745507815949396cd0c5e6_17731846',
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_5949396cd14757_26562038',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5949396cd14757_26562038')) {
function content_5949396cd14757_26562038 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '10745507815949396cd0c5e6_17731846';
?>
<div class="navigation">
	<ul class="clearfix">
		<li class="account">
			<a href="?a=account">
				<div class="icon"><span></span></div>
				<div class="text">Your<br>Account</div>
			</a>
		</li>
		<li class="earnings">
			<a href="?a=earnings">
				<div class="icon"><span></span></div>
				<div class="text">Earnings<br>History</div>
			</a>
		</li>
		<li class="deposit_list">
			<a href="?a=deposit_list">
				<div class="icon"><span></span></div>
				<div class="text">Your<br>Deposits</div>
			</a>
		</li>
		<li class="deposit_history">
			<a href="?a=deposit_history">
				<div class="icon"><span></span></div>
				<div class="text">Deposits<br>History</div>
			</a>
		</li>
		<li class="withdraw_history">
			<a href="?a=withdraw_history">
				<div class="icon"><span></span></div>
				<div class="text">Withdrawals<br>History</div>
			</a>
		</li>
		<li class="referals">
			<a href="?a=referals">
				<div class="icon"><span></span></div>
				<div class="text">Your<br>Referrals</div>
			</a>
		</li>
		<li class="tell_friend">
			<a href="?a=tell_friend">
				<div class="icon"><span></span></div>
				<div class="text">Tell<br>Friend</div>
			</a>
		</li>
		<li class="edit_account">
			<a href="?a=edit_account">
				<div class="icon"><span></span></div>
				<div class="text">Edit<br>Account</div>
			</a>
		</li>
	</ul>
</div><?php }
}
?>