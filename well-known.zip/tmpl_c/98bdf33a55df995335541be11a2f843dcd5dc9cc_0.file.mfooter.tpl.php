<?php /* Smarty version 3.1.27, created on 2018-02-22 15:59:22
         compiled from "/home/dsenemfi/nxtcoininvest.com/tmpl/mfooter.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:14078090715a8f2f2ad7a983_31844177%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '98bdf33a55df995335541be11a2f843dcd5dc9cc' => 
    array (
      0 => '/home/dsenemfi/nxtcoininvest.com/tmpl/mfooter.tpl',
      1 => 1481513022,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '14078090715a8f2f2ad7a983_31844177',
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_5a8f2f2ad80625_07123631',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5a8f2f2ad80625_07123631')) {
function content_5a8f2f2ad80625_07123631 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '14078090715a8f2f2ad7a983_31844177';
?>
</div><?php echo $_smarty_tpl->getSubTemplate ("footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);

}
}
?>