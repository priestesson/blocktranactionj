<?php /* Smarty version 3.1.27, created on 2017-06-20 15:03:28
         compiled from "/home/cryptoorbit/public_html/tmpl/mfooter.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:30991992159493940dfaf19_05186145%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '750b7c783280321003d487af7d7cb4a00334209f' => 
    array (
      0 => '/home/cryptoorbit/public_html/tmpl/mfooter.tpl',
      1 => 1481513022,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '30991992159493940dfaf19_05186145',
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_59493940dff7c4_74275004',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_59493940dff7c4_74275004')) {
function content_59493940dff7c4_74275004 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '30991992159493940dfaf19_05186145';
?>
</div><?php echo $_smarty_tpl->getSubTemplate ("footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);

}
}
?>