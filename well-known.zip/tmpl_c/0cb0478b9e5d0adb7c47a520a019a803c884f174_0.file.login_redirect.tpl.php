<?php /* Smarty version 3.1.27, created on 2018-02-22 15:58:46
         compiled from "/home/dsenemfi/nxtcoininvest.com/tmpl/login_redirect.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:4603139345a8f2f06df1ea4_59695944%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '0cb0478b9e5d0adb7c47a520a019a803c884f174' => 
    array (
      0 => '/home/dsenemfi/nxtcoininvest.com/tmpl/login_redirect.tpl',
      1 => 1496463032,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '4603139345a8f2f06df1ea4_59695944',
  'variables' => 
  array (
    'settings' => 0,
    'userinfo' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_5a8f2f06e3b6a9_87731131',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5a8f2f06e3b6a9_87731131')) {
function content_5a8f2f06e3b6a9_87731131 ($_smarty_tpl) {
if (!is_callable('smarty_modifier_myescape')) require_once '/home/dsenemfi/nxtcoininvest.com/inc/libs/smarty3/plugins/modifier.myescape.php';

$_smarty_tpl->properties['nocache_hash'] = '4603139345a8f2f06df1ea4_59695944';
?>
<!DOCTYPE html>
<html>
	<head>
		<title></title>
		<meta name="viewport" content="width=1024">
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<meta http-equiv="Refresh" content="2; url=?a=account">
		<link rel="shortcut icon" href="img/favicon.png" type="image/x-icon">
		<link href="https://fonts.googleapis.com/css?family=Roboto:400,700,400italic,700italic&subset=latin,cyrillic" rel="stylesheet" type="text/css">
		<link rel="stylesheet" href="css/style.css"/>
	</head>
	<body>
		<section class="redirect_page">
			<div class="container">
				<div class="rp_logo"><a href="?a=account"><span></span><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
</a></div>
				<div class="rp_info dark_bg">
					<h2>Hello <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['userinfo']->value['username']);?>
!</h2>
					<div class="separator_2"><span></span></div>
					<div class="rp_text">
						<p>You are redirecting to your account now.</p>
					</div>
				</div>
				<a href="?a=account" class="custom_link big green">Go to your account</a>
			</div>
		</section>
	<body>
</html><?php }
}
?>