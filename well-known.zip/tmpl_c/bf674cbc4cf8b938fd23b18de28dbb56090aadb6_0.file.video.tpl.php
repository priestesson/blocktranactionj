<?php /* Smarty version 3.1.27, created on 2017-06-19 04:17:56
         compiled from "/home/cryptoorbit/public_html/tmpl/custom/video.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:188826316559475074b0e871_25082667%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'bf674cbc4cf8b938fd23b18de28dbb56090aadb6' => 
    array (
      0 => '/home/cryptoorbit/public_html/tmpl/custom/video.tpl',
      1 => 1496463262,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '188826316559475074b0e871_25082667',
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_59475074bb7893_19002808',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_59475074bb7893_19002808')) {
function content_59475074bb7893_19002808 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '188826316559475074b0e871_25082667';
echo $_smarty_tpl->getSubTemplate ("header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>


<h1>Our Video</h1>
<div class="separator_2"><span></span></div>
<div class="video_page">
	<ul class="clearfix">
		<li>
			<img src="img/video_img.png">
		</li>
		<li>
			<img src="img/video_img.png">
		</li>
		<li>
			<img src="img/video_img.png">
		</li>
		<li>
			<img src="img/video_img.png">
		</li>
		<li>
			<img src="img/video_img.png">
		</li>
		<li>
			<img src="img/video_img.png">
		</li>
		<li>
			<img src="img/video_img.png">
		</li>
		<li>
			<img src="img/video_img.png">
		</li>
		<li>
			<img src="img/video_img.png">
		</li>
	</ul>
</div>

				<?php echo $_smarty_tpl->getSubTemplate ("footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);

}
}
?>