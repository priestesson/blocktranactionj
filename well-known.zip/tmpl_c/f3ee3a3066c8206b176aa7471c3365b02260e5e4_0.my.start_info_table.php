<?php /* Smarty version 3.1.27, created on 2018-02-23 04:12:34
         compiled from "my:start_info_table" */ ?>
<?php
/*%%SmartyHeaderCode:5513921215a8fdb02398a24_34143925%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'f3ee3a3066c8206b176aa7471c3365b02260e5e4' => 
    array (
      0 => 'my:start_info_table',
      1 => 1519377154,
      2 => 'my',
    ),
  ),
  'nocache_hash' => '5513921215a8fdb02398a24_34143925',
  'variables' => 
  array (
    'size' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_5a8fdb023f8929_43642951',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5a8fdb023f8929_43642951')) {
function content_5a8fdb023f8929_43642951 ($_smarty_tpl) {
if (!is_callable('smarty_modifier_myescape')) require_once '/home/dsenemfi/nxtcoininvest.com/inc/libs/smarty3/plugins/modifier.myescape.php';

$_smarty_tpl->properties['nocache_hash'] = '5513921215a8fdb02398a24_34143925';
?>
 <table cellspacing=0 cellpadding=1 border=0 width=<?php echo smarty_modifier_myescape((($tmp = @$_smarty_tpl->tpl_vars['size']->value)===null||$tmp==='' ? "100%" : $tmp));?>
 bgcolor=#FF8D00> <tr><td bgcolor=#FF8D00> <table cellspacing=0 cellpadding=0 border=0 width=100<?php echo '%>';?> <tr> <td valign=top width=10 bgcolor=#FFFFF2><img src=images/sign.gif></td> <td valign=top bgcolor=#FFFFF2 style="padding: 10px; color: #D20202; font-family: verdana; font-size: 11px;"> <?php }
}
?>