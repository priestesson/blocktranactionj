<?php /* Smarty version 3.1.27, created on 2018-02-22 09:14:09
         compiled from "/home/dsenemfi/nxtcoininvest.com/tmpl/custom/our_benefits.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:12328130065a8ed03144ff84_40934281%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '96930638ccedbe29dbac1d9ba1e1ee2386e7b326' => 
    array (
      0 => '/home/dsenemfi/nxtcoininvest.com/tmpl/custom/our_benefits.tpl',
      1 => 1514628727,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '12328130065a8ed03144ff84_40934281',
  'variables' => 
  array (
    'settings' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_5a8ed0314d09f5_55950413',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5a8ed0314d09f5_55950413')) {
function content_5a8ed0314d09f5_55950413 ($_smarty_tpl) {
if (!is_callable('smarty_modifier_myescape')) require_once '/home/dsenemfi/nxtcoininvest.com/inc/libs/smarty3/plugins/modifier.myescape.php';

$_smarty_tpl->properties['nocache_hash'] = '12328130065a8ed03144ff84_40934281';
$_smarty_tpl->tpl_vars["allow"] = new Smarty_Variable("all", null, 0);?>
<?php $_smarty_tpl->tpl_vars["meta_title"] = new Smarty_Variable('', null, 0);?>
<?php echo $_smarty_tpl->getSubTemplate ("header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>

<h1>Our Benefits</h1>

<div class="separator_2">&nbsp;</div>

<div class="benefits_page">
<ul>
	<li>
	<div class="icon black">&nbsp;</div>

	<div class="bp_wrap">
	<h3><strong>Genuine Investment Platform</strong></h3>

	<div class="separator_1">&nbsp;</div>

	<p>A certificate of incorporation of a private limited company is a legal document relating to the formation of <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
 LTD. <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_url']);?>
 , <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_url']);?>
 or https://www.nxtcoininvest.com website for online investment platform &quot;<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
 - Your Profitable Operator&quot; is property of <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
 LTD. In United Kingdom the certificate of incorporation forms a major constituent part of the constitutional documents of incorporation. It is a document produced by a newly organized corporate entity and submitted to a state office for registration purposes, and this document officially indicates the company&#39;s existence. To download certificate of incorporation <a href="media/cert.pdf" target="_blank"></a></p>

	<p>&nbsp;</p>
	</div>
	</li>
	<li>
	<div class="icon red">&nbsp;</div>

	<div class="bp_wrap">
	<h3><strong>Strong DDoS protection</strong></h3>

	<div class="separator_1">&nbsp;</div>

	<p>Our Website is hosted on a dedicated server using strong DDoS protection to keep all information safe and protect us from the most powerful DDoS attacks. We can guarantee up to 99% uptime. You can absolutely sure that our services are suitable for your particular purposes.</p>
	</div>
	</li>
	<li>
	<div class="icon green">&nbsp;</div>

	<div class="bp_wrap">
	<h3><strong>Comodo Green EV-SSL Encryption</strong></h3>

	<div class="separator_1">&nbsp;</div>

	<p>An EV SSL certificate offers the highest available levels of trust and authentication for our website. The green address bar prominently displays that our company name is genuine and provides highly visual assurance to our customers that our site is secure &ndash; immediately giving to you the confidence to complete the transaction.<br />
	2048-bit, highest assurance SSL Certificate, with 99.9% Browser Recognition with $1,750,000 relying party warranty</p>
	</div>
	</li>
	<li>
	<div class="icon black">&nbsp;</div>

	<div class="bp_wrap">
	<h3><strong>Real Registered Company</strong></h3>

	<div class="separator_1">&nbsp;</div>

	<p>The <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
 LTD is absolutely legit. Our company is registered and works according to United Kingdom laws. A Certificate of Incorporation is a document that is issued to a company when it is registered with Companies House. It is an official certificate issued by the registrar on successful incorporation of a company. The Companies Act 2006 states that when the certificate is issued it is conclusive evidence that the company has been duly registered The <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
 LTD registration number is <strong>№10233985</strong>, anyone can verify the registration information by visiting the official website of the British registrar: <a href="http://wck2.companieshouse.gov.uk"></a>.<br />
	Our Corporate Headquarters is located here: <strong>City House, New Station Street, Leeds, LS1 4JE, United Kingdom </strong></p>
	</div>
	</li>
	<li>
	<div class="icon red">&nbsp;</div>

	<div class="bp_wrap">
	<h3><strong>Domain Registered for 5 Years</strong></h3>

	<div class="separator_1">&nbsp;</div>

	<p>In our business it is essential that we are able to anticipate change and build for the decades to come. Therefore, we create detailed plans for long term perspective. Only by doing this, we can ensure an excellent services.</p>
	</div>
	</li>
	<li>
	<div class="icon green">&nbsp;</div>

	<div class="bp_wrap">
	<h3><strong>Professional Management Team</strong></h3>

	<div class="separator_1">&nbsp;</div>

	<p>The investment portfolio is managed by a team of experienced financial specialists, of lawyers, professional trade analysts who have been working on the currency exchange market for more than 10 years on average. Our experience and contacts ensure access for us to a wide range of local and global resources and bring about benefit from the world&#39;s best and most effective technologies of trading on the Forex and Cryptocurrency market.</p>
	</div>
	</li>
</ul>
</div>

<?php echo $_smarty_tpl->getSubTemplate ("footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);

}
}
?>