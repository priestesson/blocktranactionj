<?php /* Smarty version 3.1.27, created on 2018-02-22 08:23:02
         compiled from "/home/dsenemfi/nxtcoininvest.com/tmpl/custom/privacy_policy.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:13136621275a8ec436799b01_60042495%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '8838eb8fabec267510d17c910133f95a7e354de7' => 
    array (
      0 => '/home/dsenemfi/nxtcoininvest.com/tmpl/custom/privacy_policy.tpl',
      1 => 1496463032,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '13136621275a8ec436799b01_60042495',
  'variables' => 
  array (
    'settings' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_5a8ec436811229_96883596',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5a8ec436811229_96883596')) {
function content_5a8ec436811229_96883596 ($_smarty_tpl) {
if (!is_callable('smarty_modifier_myescape')) require_once '/home/dsenemfi/nxtcoininvest.com/inc/libs/smarty3/plugins/modifier.myescape.php';

$_smarty_tpl->properties['nocache_hash'] = '13136621275a8ec436799b01_60042495';
echo $_smarty_tpl->getSubTemplate ("header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>


<h1>Privacy Policy</h1>
<div class="separator_2"><span></span></div>

<div class="rules_page">
	<p class="all_p green_bg">
An important part of the relationship we have with our clients is the information you share with us. We want you to be clear how we are using your private information.

Our Privacy Policy explains: 
What information we collect and why we collect it.
How we use that information.
We regulate data accumulation and usage at the website. <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
 - Your Profitable Operator protects our clients' privacy and does its best to provide their safety and convenience online.

	</p>
	<h2>Your personal information accumulation</h2>
	<div class="separator_1"><span></span></div>
	<p class="all_p light_bg">
<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
 - Your Profitable Operator accumulates information that you provide to us when registering with our website - your name, ewallet information, secret question, secret answer and e-mail address. We receive such information as the type of browser and operating system used to access our site, geographical location, your IP address, date and time you access our site and domain names. This information is primarily collected for statistical analysis and technical improvements to the site. In case if you reveal your personal data directly through the public message boards of the <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
 - Your Profitable Operator's website, we are irresponsible for data privacy. Please take into consideration that this data can be used by third parties. Please be aware that we are not responsible for the privacy practices of other sites, and we are not liable for their misuse of personally identifiable information. We encourage you to be aware that when you go to another website you should carefully read their privacy statement.

	</p>
		<div class="separator_3"><span></span></div>
	
	<h3>Use of cookies</h3>
	
	
	
		<p class="all_p">
"Cookies" are small bits of text that are used at the <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
 - Your Profitable Operator's website to help you in personalizing your online presence. Cookie is intended to signal the web-server that the user has returned to a particular page. Cookies do not contain any information that personally identifies a user and are totally harmless. Cookies are stored in your web browser that allows <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
 - Your Profitable Operator or a third party to recognize you. The <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
 - Your Profitable Operator's website uses cookies to enable certain functionality and to provide analytics. One of the main purposes of cookies is saving your time, which is very convenient for you. Cookies are necessary for the website to recall some particular information at your following visit. You will get quick access to the necessary <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
 - Your Profitable Operator's website features when you come back to the <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
 - Your Profitable Operator's website again. Cookies can either be session cookies or persistent cookies. A session cookie expires automatically when you close your browser. A persistent cookie will remain until it expires or you delete your cookies. Expiration dates are set in the cookies themselves, some may expire after a few minutes while others may expire after multiple years. You may refuse the use of cookies by selecting the appropriate settings on your browser, however please note that if you do this you may not be able to use the full functionality of this website. 

		</p>
	
	<div class="separator_3"><span></span></div>
	
	<h3>Changes to this statement   </h3>
	
	
	<p class="all_p">
	
	Our Privacy Policy may change from time to time. We will not reduce your rights under this Privacy Policy without your explicit consent. We will post any privacy policy changes on this page. Thereby, we strongly recommend you to review this Statement from time to time not to miss the updates. If the changes are significant, we will provide a more prominent notice (email notification of privacy policy changes). The provisions contained herein supersede all previous notices or statements regarding our privacy practices and the terms and conditions that govern the use of this site.
	</p>
	
	
	<div class="separator_3"><span></span></div>
	
	<h3>Contact Information </h3>
	
	<p class="all_p">
	
	If you have questions or wish to send us comments about this Privacy Policy, please contact us with questions or comments at: abuse@earntech.cc
    
	
	


	</p>
	
	<p class="all_p green_bg">
		
	Thank you for visiting the <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
 - Your Profitable Operator's website.
	</p>
	
	
	<!--
	
	<p class="all_p">
		Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
	</p>
	
	
	<h3>Use of cookies</h3>
	<p class="all_p light_bg">
		Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
	</p>
	<h4>Title - h4</h4>
	<p class="all_p dark_bg">
		Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
	</p>
	<p class="all_p f_letter">
		Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
	</p>
	<a href="#" class="custom_link small green">Green small button</a>
	<a href="#" class="custom_link big green">Green big button</a>
	<a href="#" class="custom_link small red">Red small button</a>
	<a href="#" class="custom_link big red">Red big button</a>
	<div class="separator_3"><span></span></div>
	<ul class="check_list">
		<li>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</li>
		<li>Sed ut perspiciatis unde omnis iste natus error sit.</li>
		<li>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</li>
		<li>Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem.</li>
		<li>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li>
	</ul>
	<div class="separator_3"><span></span></div>
	<p class="all_p">
		Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
	</p>
	
	-->
	
</div>

				<?php echo $_smarty_tpl->getSubTemplate ("footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);

}
}
?>