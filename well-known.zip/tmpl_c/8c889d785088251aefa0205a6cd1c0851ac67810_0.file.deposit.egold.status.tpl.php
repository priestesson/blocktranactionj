<?php /* Smarty version 3.1.27, created on 2018-02-21 19:36:30
         compiled from "/home/dsenemfi/nxtcoininvest.com/tmpl/deposit.egold.status.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:18601782915a8e108ea05263_96833325%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '8c889d785088251aefa0205a6cd1c0851ac67810' => 
    array (
      0 => '/home/dsenemfi/nxtcoininvest.com/tmpl/deposit.egold.status.tpl',
      1 => 1442782298,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '18601782915a8e108ea05263_96833325',
  'variables' => 
  array (
    'process' => 0,
    'frm' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_5a8e108eabf0c8_12118925',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5a8e108eabf0c8_12118925')) {
function content_5a8e108eabf0c8_12118925 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '18601782915a8e108ea05263_96833325';
echo $_smarty_tpl->getSubTemplate ("header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>

<h3>Your Deposit status</h3><br>
<br>
<?php if ($_smarty_tpl->tpl_vars['process']->value == 'yes' || $_smarty_tpl->tpl_vars['frm']->value['m_status'] == 'success') {?>
We have received your deposit. Thank you!
<?php } else { ?>
We have not received your deposit. Please try again.
<?php }?>
<?php echo $_smarty_tpl->getSubTemplate ("footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);

}
}
?>