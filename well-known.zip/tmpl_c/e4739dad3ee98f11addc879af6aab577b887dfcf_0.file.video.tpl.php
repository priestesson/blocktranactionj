<?php /* Smarty version 3.1.27, created on 2018-02-10 14:31:26
         compiled from "/home/dsenemfi/nxtcoininvest.com/tmpl/custom/video.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:2382950975a7f488e8dfd86_58433218%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'e4739dad3ee98f11addc879af6aab577b887dfcf' => 
    array (
      0 => '/home/dsenemfi/nxtcoininvest.com/tmpl/custom/video.tpl',
      1 => 1496463262,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2382950975a7f488e8dfd86_58433218',
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_5a7f488e999076_71965156',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5a7f488e999076_71965156')) {
function content_5a7f488e999076_71965156 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '2382950975a7f488e8dfd86_58433218';
echo $_smarty_tpl->getSubTemplate ("header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>


<h1>Our Video</h1>
<div class="separator_2"><span></span></div>
<div class="video_page">
	<ul class="clearfix">
		<li>
			<img src="img/video_img.png">
		</li>
		<li>
			<img src="img/video_img.png">
		</li>
		<li>
			<img src="img/video_img.png">
		</li>
		<li>
			<img src="img/video_img.png">
		</li>
		<li>
			<img src="img/video_img.png">
		</li>
		<li>
			<img src="img/video_img.png">
		</li>
		<li>
			<img src="img/video_img.png">
		</li>
		<li>
			<img src="img/video_img.png">
		</li>
		<li>
			<img src="img/video_img.png">
		</li>
	</ul>
</div>

				<?php echo $_smarty_tpl->getSubTemplate ("footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);

}
}
?>