<?php /* Smarty version 3.1.27, created on 2018-02-22 15:59:22
         compiled from "/home/dsenemfi/nxtcoininvest.com/tmpl/mnav.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:21261365075a8f2f2ad65307_29602713%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '1aa7f6783585f129063f3eaf93a33454719b4f47' => 
    array (
      0 => '/home/dsenemfi/nxtcoininvest.com/tmpl/mnav.tpl',
      1 => 1481512952,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '21261365075a8f2f2ad65307_29602713',
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_5a8f2f2ad6a116_06093577',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5a8f2f2ad6a116_06093577')) {
function content_5a8f2f2ad6a116_06093577 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '21261365075a8f2f2ad65307_29602713';
?>
<div class="navigation">
	<ul class="clearfix">
		<li class="account">
			<a href="?a=account">
				<div class="icon"><span></span></div>
				<div class="text">Your<br>Account</div>
			</a>
		</li>
		<li class="earnings">
			<a href="?a=earnings">
				<div class="icon"><span></span></div>
				<div class="text">Earnings<br>History</div>
			</a>
		</li>
		<li class="deposit_list">
			<a href="?a=deposit_list">
				<div class="icon"><span></span></div>
				<div class="text">Your<br>Deposits</div>
			</a>
		</li>
		<li class="deposit_history">
			<a href="?a=deposit_history">
				<div class="icon"><span></span></div>
				<div class="text">Deposits<br>History</div>
			</a>
		</li>
		<li class="withdraw_history">
			<a href="?a=withdraw_history">
				<div class="icon"><span></span></div>
				<div class="text">Withdrawals<br>History</div>
			</a>
		</li>
		<li class="referals">
			<a href="?a=referals">
				<div class="icon"><span></span></div>
				<div class="text">Your<br>Referrals</div>
			</a>
		</li>
		<li class="tell_friend">
			<a href="?a=tell_friend">
				<div class="icon"><span></span></div>
				<div class="text">Tell<br>Friend</div>
			</a>
		</li>
		<li class="edit_account">
			<a href="?a=edit_account">
				<div class="icon"><span></span></div>
				<div class="text">Edit<br>Account</div>
			</a>
		</li>
	</ul>
</div><?php }
}
?>