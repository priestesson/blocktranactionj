<?php /* Smarty version 3.1.27, created on 2017-06-16 10:19:16
         compiled from "my:check_ips_access" */ ?>
<?php
/*%%SmartyHeaderCode:17674467725943b0a43d4059_09721727%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'b7a4ca05990c7be61f0b091b064fcfc6db422e16' => 
    array (
      0 => 'my:check_ips_access',
      1 => 1497608356,
      2 => 'my',
    ),
  ),
  'nocache_hash' => '17674467725943b0a43d4059_09721727',
  'variables' => 
  array (
    'frm' => 0,
    'access' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_5943b0a4477c45_69700184',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5943b0a4477c45_69700184')) {
function content_5943b0a4477c45_69700184 ($_smarty_tpl) {
if (!is_callable('smarty_modifier_myescape')) require_once '/home/cryptoorbit/public_html/inc/libs/smarty3/plugins/modifier.myescape.php';

$_smarty_tpl->properties['nocache_hash'] = '17674467725943b0a43d4059_09721727';
?>
<b>Check IPs for double usage:</b><br><br> <table cellspacing=0 cellpadding=0 border=0 width=100<?php echo '%>';?><tr><td class=title> <table cellspacing=1 cellpadding=2 border=0 width=100<?php echo '%>';?> <tr><th colspan=3 class=title><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['frm']->value['ip']);?>
</th></tr> <tr> <th>User</td> <th>Date</td> <th>Last Access</td> <th>Actions</th> </tr> <?php if (isset($_smarty_tpl->tpl_vars['smarty']->value['section']['a'])) unset($_smarty_tpl->tpl_vars['smarty']->value['section']['a']);
$_smarty_tpl->tpl_vars['smarty']->value['section']['a']['name'] = 'a';
$_smarty_tpl->tpl_vars['smarty']->value['section']['a']['loop'] = is_array($_loop=$_smarty_tpl->tpl_vars['access']->value) ? count($_loop) : max(0, (int) $_loop); unset($_loop);
$_smarty_tpl->tpl_vars['smarty']->value['section']['a']['show'] = true;
$_smarty_tpl->tpl_vars['smarty']->value['section']['a']['max'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['a']['loop'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['a']['step'] = 1;
$_smarty_tpl->tpl_vars['smarty']->value['section']['a']['start'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['a']['step'] > 0 ? 0 : $_smarty_tpl->tpl_vars['smarty']->value['section']['a']['loop']-1;
if ($_smarty_tpl->tpl_vars['smarty']->value['section']['a']['show']) {
    $_smarty_tpl->tpl_vars['smarty']->value['section']['a']['total'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['a']['loop'];
    if ($_smarty_tpl->tpl_vars['smarty']->value['section']['a']['total'] == 0)
        $_smarty_tpl->tpl_vars['smarty']->value['section']['a']['show'] = false;
} else
    $_smarty_tpl->tpl_vars['smarty']->value['section']['a']['total'] = 0;
if ($_smarty_tpl->tpl_vars['smarty']->value['section']['a']['show']):

            for ($_smarty_tpl->tpl_vars['smarty']->value['section']['a']['index'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['a']['start'], $_smarty_tpl->tpl_vars['smarty']->value['section']['a']['iteration'] = 1;
                 $_smarty_tpl->tpl_vars['smarty']->value['section']['a']['iteration'] <= $_smarty_tpl->tpl_vars['smarty']->value['section']['a']['total'];
                 $_smarty_tpl->tpl_vars['smarty']->value['section']['a']['index'] += $_smarty_tpl->tpl_vars['smarty']->value['section']['a']['step'], $_smarty_tpl->tpl_vars['smarty']->value['section']['a']['iteration']++):
$_smarty_tpl->tpl_vars['smarty']->value['section']['a']['rownum'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['a']['iteration'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['a']['index_prev'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['a']['index'] - $_smarty_tpl->tpl_vars['smarty']->value['section']['a']['step'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['a']['index_next'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['a']['index'] + $_smarty_tpl->tpl_vars['smarty']->value['section']['a']['step'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['a']['first']      = ($_smarty_tpl->tpl_vars['smarty']->value['section']['a']['iteration'] == 1);
$_smarty_tpl->tpl_vars['smarty']->value['section']['a']['last']       = ($_smarty_tpl->tpl_vars['smarty']->value['section']['a']['iteration'] == $_smarty_tpl->tpl_vars['smarty']->value['section']['a']['total']);
?> <tr bgcolor=#FFFFFF> <td><b><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['access']->value[$_smarty_tpl->getVariable('smarty')->value['section']['a']['index']]['username']);?>
</b></td> <td align=right><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['access']->value[$_smarty_tpl->getVariable('smarty')->value['section']['a']['index']]['date']);?>
</td> <td align=right><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['access']->value[$_smarty_tpl->getVariable('smarty')->value['section']['a']['index']]['last_access_time']);?>
</td> <td align=center><a href=?a=userfunds&id=<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['access']->value[$_smarty_tpl->getVariable('smarty')->value['section']['a']['index']]['id']);?>
>[view]</a>&nbsp; <a href="?a=deleteaccount&id=<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['access']->value[$_smarty_tpl->getVariable('smarty')->value['section']['a']['index']]['id']);?>
" onclick="return confirm('Are you sure you want to delete this user?');">[delete]</a> </td> </tr> <?php endfor; endif; ?> </table> </td></tr></table> <?php }
}
?>