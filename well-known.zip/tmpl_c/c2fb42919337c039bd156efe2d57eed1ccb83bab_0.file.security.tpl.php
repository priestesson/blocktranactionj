<?php /* Smarty version 3.1.27, created on 2018-02-22 08:27:55
         compiled from "/home/dsenemfi/nxtcoininvest.com/tmpl/custom/security.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:11732771085a8ec55b566228_41708774%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'c2fb42919337c039bd156efe2d57eed1ccb83bab' => 
    array (
      0 => '/home/dsenemfi/nxtcoininvest.com/tmpl/custom/security.tpl',
      1 => 1496463032,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '11732771085a8ec55b566228_41708774',
  'variables' => 
  array (
    'settings' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_5a8ec55b5d5670_24050422',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5a8ec55b5d5670_24050422')) {
function content_5a8ec55b5d5670_24050422 ($_smarty_tpl) {
if (!is_callable('smarty_modifier_myescape')) require_once '/home/dsenemfi/nxtcoininvest.com/inc/libs/smarty3/plugins/modifier.myescape.php';

$_smarty_tpl->properties['nocache_hash'] = '11732771085a8ec55b566228_41708774';
echo $_smarty_tpl->getSubTemplate ("header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>



<h1>Security</h1>
<div class="separator_2"><span></span></div>

<div class="rules_page">
	<p class="all_p green_bg">
		Web sites are unfortunately prone to security risks. As you know there are a lot of people who call themselves hackers. They use a known technique to break into a site that is interesting to them, often just to see if they can do it. Given the work being done by tens of thousands of programmers worldwide to improve security, it is not easy to discover a brand new method of attack. Online investment platform vulnerable to hackers, spammers and identity thieves. Countering and attempting to eliminate any return on the hacking investment we have hundreds if not thousands of web security entities. <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
 - Your Profitable Operator is using the majority of popular security options.
	</p>
	<h2>Your personal information security</h2>
	<div class="separator_1"><span></span></div>
	<p class="all_p light_bg">
As befits a good investment program we have a wide range of security, performance and many other options for provide excellent services to every our client. If you already had time to pay attention, we use an Extended Validation SSL Certificate from Comodo with green browser address bar. This means the company has been checked through all the registration data, as well as its financial activity. The use of encryption, such as the Secure Socket Layer (SSL) protocol, protects your personal data at the time of transmission to other website (for example, when it comes to your e-wallet personal data). EV SSL Certificates provide the strongest encryption level available and enable the organization behind a website to present its own verified identity to website visitors. In addition, our site is on a dedicated server and has dedicated IP address. We provide round the clock protection against DDoS attacks so that you can be assured of stable access to your personal account in our system.
	</p>
	
	<h3>How to recognize website using Extended Validation (EV) SSL?</h3>
		
		<p class="all_p">
		A website using EV SSL Certificate will activate highly visible green indicators directly on the browser address bar:
		
		</p>
		
		<div align="center"> <img src="img/sslscreen.png" alt="Green SSL"> </div>
		
		<p class="all_p">
		The name of the Organization that owns the website and the name of the Certificate Authority that issued the Extended Validation (EV) SSL Certificate.
		
		</p>
	
	
	
	<h3>Anti DDoS protection</h3>
	<p class="all_p light_bg">
We have not spared even a single cent when it comes to keeping our members personal information and transactions secure. It has always been our first priority after helping our members to achieve financial security. <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
 - Your Profitable Operator is hosted on dedicated server and DDoS protection is provided from Koddos what is good anti DDoS service provider and will help to keep website online.
	</p>
	
	<p class="all_p green_bg">
<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
 - Your Profitable Operator knows just how important is to the success of your online investing process – and offers the website security options you need to safely invest online. 
	</p>
	
	
	
	<!--
	
	<h4>Title - h4</h4>
	<p class="all_p dark_bg">
		Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
	</p>
	<p class="all_p f_letter">
		Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
	</p>
	<a href="#" class="custom_link small green">Green small button</a>
	<a href="#" class="custom_link big green">Green big button</a>
	<a href="#" class="custom_link small red">Red small button</a>
	<a href="#" class="custom_link big red">Red big button</a>
	<div class="separator_3"><span></span></div>
	<ul class="check_list">
		<li>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</li>
		<li>Sed ut perspiciatis unde omnis iste natus error sit.</li>
		<li>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</li>
		<li>Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem.</li>
		<li>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li>
	</ul>
	<div class="separator_3"><span></span></div>
	<p class="all_p">
		Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
	</p>
	
	-->
</div>
<?php echo $_smarty_tpl->getSubTemplate ("footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);

}
}
?>