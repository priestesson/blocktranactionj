<?php /* Smarty version 3.1.27, created on 2017-11-22 03:17:57
         compiled from "/home/dsenemfi/public_html/tmpl/footer.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:15870747005a1532b5bf9a56_40547809%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '9cd7aea640157d4ed0f61f6f51cc8132425a7041' => 
    array (
      0 => '/home/dsenemfi/public_html/tmpl/footer.tpl',
      1 => 1481502762,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '15870747005a1532b5bf9a56_40547809',
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_5a1532b5c03567_84360382',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5a1532b5c03567_84360382')) {
function content_5a1532b5c03567_84360382 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '15870747005a1532b5bf9a56_40547809';
?>
</div>
		</section>
				<?php echo $_smarty_tpl->getSubTemplate ("footer2.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>

<?php }
}
?>