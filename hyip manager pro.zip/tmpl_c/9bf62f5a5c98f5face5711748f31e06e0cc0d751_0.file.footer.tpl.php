<?php /* Smarty version 3.1.27, created on 2017-06-20 16:54:01
         compiled from "/home/cryptoorbit/public_html/tmpl/footer.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:30071992594953290cc085_39050765%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '9bf62f5a5c98f5face5711748f31e06e0cc0d751' => 
    array (
      0 => '/home/cryptoorbit/public_html/tmpl/footer.tpl',
      1 => 1481502762,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '30071992594953290cc085_39050765',
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_594953290d02e1_73141223',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_594953290d02e1_73141223')) {
function content_594953290d02e1_73141223 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '30071992594953290cc085_39050765';
?>
</div>
		</section>
				<?php echo $_smarty_tpl->getSubTemplate ("footer2.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>

<?php }
}
?>