<?php /* Smarty version 3.1.27, created on 2017-06-16 07:46:37
         compiled from "my:custpages_edit" */ ?>
<?php
/*%%SmartyHeaderCode:189690012859438cdd7fce80_86388051%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '71efbc5efc63f65ee14f7cc51377d51e6080817c' => 
    array (
      0 => 'my:custpages_edit',
      1 => 1497599197,
      2 => 'my',
    ),
  ),
  'nocache_hash' => '189690012859438cdd7fce80_86388051',
  'variables' => 
  array (
    'errors' => 0,
    'page' => 0,
    'plans' => 0,
    'i' => 0,
    'l' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_59438cdd86bd15_84508017',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_59438cdd86bd15_84508017')) {
function content_59438cdd86bd15_84508017 ($_smarty_tpl) {
if (!is_callable('smarty_modifier_myescape')) require_once '/home/cryptoorbit/public_html/inc/libs/smarty3/plugins/modifier.myescape.php';

$_smarty_tpl->properties['nocache_hash'] = '189690012859438cdd7fce80_86388051';
?>
 <?php if ($_smarty_tpl->tpl_vars['errors']->value['file']) {?><b style=color:red>Can not save <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['page']->value['name']);?>
.tpl - check system permissions</b><br><?php }?> <?php if ($_smarty_tpl->tpl_vars['errors']->value['invalid_name']) {?><b style=color:red>Empty Page name (only a-z 0-9 - and _ allowed)</b><br><?php }?> <?php if ($_smarty_tpl->tpl_vars['errors']->value['smarty']) {?><b style=color:red><?php echo smarty_modifier_myescape(htmlspecialchars($_smarty_tpl->tpl_vars['errors']->value['smarty'], ENT_QUOTES, 'UTF-8', true));?>
</b><br><?php }?> <form method=post name=custpage> <input type=hidden name=a value=custompages> <input type=hidden name=action value=edit> <input type=hidden name=action2 value=save> <input type=hidden name=page value=<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['page']->value['name']);?>
> <table cellspacing=0 cellpadding=2 border=0> <tr> <td>Page:</td> <td><input type=text name=page value="<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['page']->value['name']);?>
" class=inpts></td> </tr> <tr> <td>Title:</td> <td><input type=text name=title value="<?php echo smarty_modifier_myescape(htmlspecialchars($_smarty_tpl->tpl_vars['page']->value['title'], ENT_QUOTES, 'UTF-8', true));?>
" class=inpts></td> </tr> <tr> <td>Allow:</td> <td> <select name=allow class=inpts onchange="chkAllow()"> <option value=all <?php if ($_smarty_tpl->tpl_vars['page']->value['allow'] == "all") {?>selected<?php }?>>All</option> <option value=none <?php if ($_smarty_tpl->tpl_vars['page']->value['allow'] == "none") {?>selected<?php }?>>None</option> <option value=logged <?php if ($_smarty_tpl->tpl_vars['page']->value['allow'] == "logged") {?>selected<?php }?>>Logged</option> <option value=deposit <?php if ($_smarty_tpl->tpl_vars['page']->value['allow'] == "deposit") {?>selected<?php }?>>Deposit to</option> <option value=active_deposit <?php if ($_smarty_tpl->tpl_vars['page']->value['allow'] == "active_deposit") {?>selected<?php }?>>Active Deposit to</option> </select> &nbsp; <select name=allowto class=inpts> <option value=0>Any</option> <?php
$_from = $_smarty_tpl->tpl_vars['plans']->value;
if (!is_array($_from) && !is_object($_from)) {
settype($_from, 'array');
}
$_smarty_tpl->tpl_vars['l'] = new Smarty_Variable;
$_smarty_tpl->tpl_vars['l']->_loop = false;
$_smarty_tpl->tpl_vars['i'] = new Smarty_Variable;
foreach ($_from as $_smarty_tpl->tpl_vars['i']->value => $_smarty_tpl->tpl_vars['l']->value) {
$_smarty_tpl->tpl_vars['l']->_loop = true;
$foreach_l_Sav = $_smarty_tpl->tpl_vars['l'];
?> <option value=<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['i']->value);?>
 <?php if ($_smarty_tpl->tpl_vars['page']->value['allowto'] == $_smarty_tpl->tpl_vars['i']->value) {?>selected<?php }?>><?php echo smarty_modifier_myescape(htmlspecialchars($_smarty_tpl->tpl_vars['l']->value, ENT_QUOTES, 'UTF-8', true));?>
</option> <?php
$_smarty_tpl->tpl_vars['l'] = $foreach_l_Sav;
}
?> </select> </td> </tr>  <?php echo '<script'; ?>
> function chkAllow() { var s = document.custpage.allow; var t = document.custpage.allowto; var v = s.options[s.selectedIndex].value; if (v == "deposit" || v == "active_deposit") { t.disabled = false; } else { t.disabled = true; } } chkAllow(); <?php echo '</script'; ?>
> <?php echo '<script'; ?>
 src="//cdn.ckeditor.com/4.4.6/full-all/ckeditor.js"><?php echo '</script'; ?>
>
 <tr> <td colspan=2> <textarea name="content" class="inpts" id="editor1" cols=100 rows=20><?php echo smarty_modifier_myescape(htmlspecialchars($_smarty_tpl->tpl_vars['page']->value['content'], ENT_QUOTES, 'UTF-8', true));?>
</textarea> </td> </tr>  <?php echo '<script'; ?>
> CKEDITOR.replace( "editor1", { removeButtons: "Save,NewPage,Preview,Print,Templates,Spell,Form,Checkbox,Radio,TextField,Textarea,Select,Button,ImageButton,HiddenField,About" } ); <?php echo '</script'; ?>
>  <tr> <td colspan=2><input type=submit value="Save" class=sbmt> <input type=button value="Cancel" class=sbmt onclick="document.location='?a=custompages'"></td> </tr> </table> </form> <?php }
}
?>