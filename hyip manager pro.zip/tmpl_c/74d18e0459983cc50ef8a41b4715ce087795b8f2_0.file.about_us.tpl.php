<?php /* Smarty version 3.1.27, created on 2017-06-20 15:08:36
         compiled from "/home/cryptoorbit/public_html/tmpl/custom/about_us.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:201113590259493a7418c023_82302582%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '74d18e0459983cc50ef8a41b4715ce087795b8f2' => 
    array (
      0 => '/home/cryptoorbit/public_html/tmpl/custom/about_us.tpl',
      1 => 1497796392,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '201113590259493a7418c023_82302582',
  'variables' => 
  array (
    'settings' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_59493a742709e4_47735042',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_59493a742709e4_47735042')) {
function content_59493a742709e4_47735042 ($_smarty_tpl) {
if (!is_callable('smarty_modifier_myescape')) require_once '/home/cryptoorbit/public_html/inc/libs/smarty3/plugins/modifier.myescape.php';

$_smarty_tpl->properties['nocache_hash'] = '201113590259493a7418c023_82302582';
echo $_smarty_tpl->getSubTemplate ("header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>



<h1>About Company</h1>
<div class="separator_2"><span></span></div>

<div class="about_page">
	<div class="about_wrap">
		<div class="title">
			<p><span>Main Office:</span> City House, New Station Street, Leeds, LS1 4JE, United Kingdom</p>
			<p>Company <span>№10233985</span>. To download certificate of incorporation <a href="media/cert.pdf" target="_blank">click here</a></p>
			<p> This information can be verified on the <a href="">Company House website</a>.</p>
		</div>
		<div class="about_cont">
			<p class="all_p">
The <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
  is a fully registered investment company based in the United Kingdom. Our Corporate Headquarters is located here: City House, New Station Street, Leeds, LS1 4JE, United Kingdom. <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
  registration number is №10233985.
The <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
  is constantly expanding the geography of its activities thanks to excellent marketing strategy and break even trading. The company combines several successful profitable business directions, from the multi-currency trading in the Crypto Currency market to trading activity on market and investments in promising Fintech start-ups.
			</p>
			<p class="all_p">
How does it work and where does big money come from? What is Crypto Currency? The Crypto Currency Exchange market is the "place" where currencies are traded. The growth of the Crypto Currency market has been spurred by the development of electronic trading networks and the increase in globalization. Currencies are important to most people around the world because currencies need to be exchanged in order to conduct foreign trade and business. The need to exchange currencies is the main reason why the Crypto Currency market is the largest financial market in the world and continouesly growing. 
			</p>
		</div>
	</div>
	<h2><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
 is safety way to earn money </h2>
	<div class="separator_1"><span></span></div>
	<div class="about_wrap">
		<div class="about_img">
			<p class="all_p">
The Crypto Currency market focuses on the trade of currencies by both large investment banks and individuals around the world. Trading can be done in nearly all currencies, however, a small group known as the 'majors' is used in most trades. These currencies are the bitcoin, the ethereum, ripple, litecoin, only just a few from www.coinmarketcap.com. All currencies are quoted in currency pairs. Traders look to make a profit by betting that a currency's value will either appreciate or depreciate against another currency.
			</p>
			<p class="all_p">
The Crypto Currency market can be very volatile. But we can turn the volatility in our favor with certain trading strategies, such as widening targets, portfolio diversification, minimize risk etc. The activities of our company is also closely related to trading activity on the major stock exchanges. Most stocks are traded on exchanges, which are places where buyers and sellers meet and decide on a price, coin investment & mining.
			</p>
		</div>
	</div>
	<p class="all_p">
Some exchanges are physical locations where transactions are carried out on a trading floor. You've probably seen pictures of a trading floor, in which traders are wildly throwing their arms up, waving, yelling and signaling to each other. The other type of exchange is virtual, composed of a network of computers where trades are made electronically.
The purpose of a crypto currency market is to facilitate the exchange of securities between buyers and sellers, reducing the risks of investing. Really, a crypto currency market is nothing more than a super-sophisticated farmers' market linking traders, buyers and sellers.
	</p>
	<p class="all_p light_bg">
Our professional traders do three things that amateurs often forget. They plan a trading strategy, they monitor market daily and they diarize, track, and analyze each of their trades.

	</p>
	<h2>Best ways to trade</h2>
	<div class="separator_1"><span></span></div>
	<p class="all_p dark_bg">
	<b> Company's mission: </b> is offer stable, lucrative and timely payouts, safety of our clients’ funds and protection of their personal information. Cooperation with <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
 is the key to your financial freedom and impressive results of earning.
	</p>
	<p class="all_p f_letter">
Cryptocurrency market, it is the most popular market today. Cryptocurrency is a real economic breakthrough that revolutionized the world of electronic currencies and formed a unique and invulnerable monetary system. Millions of people around the world are engaged in the improvement of digital currencies and investing in cryptocurrency. Years of practice brought not only experience, but also accurate knowledge about how best to use available skills to achieve predictable high yields with minimum risk by investing high-tech solutions.
<p class="all_p">
Our team also includes specialists who are experts in evaluating new private businesses called fintech start-ups which have most chances to grow into large-scale and highly profitable enterprises. Fintech companies are easing payment processes, reducing fraud, saving users money, promoting financial planning, and ultimately moving a giant industry forward. These days you can find fintech permeating every corner of our industry, changing the way people do research, get loans, manage money and invest. And it doesn't look like that trend is going to stop. Part of what makes fintech so fascinating is not just that it's bringing much-needed change to our industry, but the way it's making life easier for everyday investors. Team of <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
 consists of specialists from different professional fields. To achieve the desired financial effect we combine the efforts of experienced market traders, financial analysts, internet marketers, programmers, professional managers and experts in evaluating new private businesses called start-ups.
	</p>
	</p>
	
	
	
</div>

					<?php echo $_smarty_tpl->getSubTemplate ("footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>

<?php }
}
?>