<?php /* Smarty version 3.1.27, created on 2017-06-20 16:23:02
         compiled from "/home/cryptoorbit/public_html/tmpl/login.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:40313815059494be6e63180_79343234%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '1d367d9d329a04e2256f794b9179b76fcce5a425' => 
    array (
      0 => '/home/cryptoorbit/public_html/tmpl/login.tpl',
      1 => 1481505916,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '40313815059494be6e63180_79343234',
  'variables' => 
  array (
    'frm' => 0,
    'userinfo' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_59494be6f1e796_85446242',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_59494be6f1e796_85446242')) {
function content_59494be6f1e796_85446242 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '40313815059494be6e63180_79343234';
echo $_smarty_tpl->getSubTemplate ("header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>


<h1>Member Login</h1>
<div class="separator_2"><span></span></div>
<div class="login_page">
		<div class="lp_wrap">
		<div class="lp_left">
			<div class="login_cont">
			
			

<?php echo '<script'; ?>
 language=javascript>
function checkform() {
  if (document.mainform.username.value=='') {
    alert("Please type your username!");
    document.mainform.username.focus();
    return false;
  }
  if (document.mainform.password.value=='') {
    alert("Please type your password!");
    document.mainform.password.focus();
    return false;
  }
  return true;
}
<?php echo '</script'; ?>
>


<?php if ($_smarty_tpl->tpl_vars['frm']->value['say'] == 'invalid_login') {?>
<h3>Login error:</h3><br><br>

Your login or password or turing image code is wrong. Please check this information.
<?php }?>
				<form method="post" name="mainform" onsubmit="return checkform()">
					<input type="hidden" name="a" value="do_login">
					<input type="hidden" name="follow" value="">
					<input type="hidden" name="follow_id" value="">
					<ul>
						<li>
							<div class="message error hidden">Please enter your username!</div>
							<div class="input_block username">
								<input type="text" name="username" value="" placeholder="Username">
							</div>
						</li>
						<li>
							<div class="message error hidden" style="display: none;">Please enter your password!</div>
							<div class="input_block password">
								<input type="password" name="password" value="" placeholder="Password">
							</div>
						</li>
									<?php if ($_smarty_tpl->tpl_vars['userinfo']->value['validation_enabled'] == 1) {?>			<li class="validation clearfix">
							<div class="message error hidden">Please enter validation number!</div>
							<div class="v_image" style="background: #424242 url(?a=show_validation_image&`$userinfo.session_name`=`$userinfo.session_id`&rand=`$userinfo.rand`) no-repeat center center;"></div>
							<input type="text" name="validation_number" placeholder="Enter validation number">
						</li> <?php }?>
												<li class="b_login clearfix">
							<input type="submit" value="Log In">
							<a href="?a=forgot_password">Forgot Password?</a>
						</li>
					</ul>
				</form>
			</div>
		</div>
		<div class="lp_right">
			<h3>Not yet registered?</h3>
			<p>
				Registration is quick and easy. You can modify your registration details at any anytime using "Your Account". Click <a href="?a=signup">here</a> to start registration.
			</p>
			<a href="?a=signup" class="custom_link big green">Open an Account</a>
		</div>
	</div>
</div>

					<?php echo $_smarty_tpl->getSubTemplate ("footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);

}
}
?>