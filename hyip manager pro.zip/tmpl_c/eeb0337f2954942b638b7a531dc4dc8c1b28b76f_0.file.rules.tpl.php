<?php /* Smarty version 3.1.27, created on 2017-06-19 04:16:44
         compiled from "/home/cryptoorbit/public_html/tmpl/rules.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:19922793665947502c9c67d2_93047500%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'eeb0337f2954942b638b7a531dc4dc8c1b28b76f' => 
    array (
      0 => '/home/cryptoorbit/public_html/tmpl/rules.tpl',
      1 => 1496463032,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '19922793665947502c9c67d2_93047500',
  'variables' => 
  array (
    'settings' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_5947502cb0bb99_58231585',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5947502cb0bb99_58231585')) {
function content_5947502cb0bb99_58231585 ($_smarty_tpl) {
if (!is_callable('smarty_modifier_myescape')) require_once '/home/cryptoorbit/public_html/inc/libs/smarty3/plugins/modifier.myescape.php';

$_smarty_tpl->properties['nocache_hash'] = '19922793665947502c9c67d2_93047500';
echo $_smarty_tpl->getSubTemplate ("header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>


<h1>Terms & Conditions</h1>
<div class="separator_2"><span></span></div>

<div class="rules_page">
	<div class="separator_1"><span></span></div>
	<p class="all_p green_bg">
Please read the Terms and Conditions carefully before You sign up
	</p>
	<h3>General</h3>
	<p class="all_p dark_bg">
	


 These rules are official and the public offer of <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
 - Your Profitable Operator, acting in accordance with the legislation of Great Britain, on the one hand, and the individual investor. This is equivalent to the conclusion of the Agreement in accordance with international law.
<BR><BR> These rules shall enter into force on the date of registration of the Investor on the website of the program <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
 - Your Profitable Operator and his acceptance of the terms and conditions. If you disagree with these terms and conditions or any part of these terms and conditions, you must not use this website. 
<BR><BR>Any individual or company from any country may open an account with us. You must be at least 18 years of age to use this website.
<BR><BR>You agree that all information, interactions, materials coming from <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
 - Your Profitable Operator are unsolicited and must be kept private, confidential and protected from any disclosure.
<BR><BR>Besides, the information, interactions and materials present herein are not to be regarded as an offer, nor a solicitation for investments in any jurisdiction which deems non-public offers or solicitations unlawful, nor to any person to whom it will be unlawful to make such offer or solicitation.
<BR><BR>Each Investor can register only one personal account, re-registration is not allowed. In case of multiple registrations, the Company reserves the right to block all accounts to ascertain the circumstances.

	</p>
	
	
	
		<h3>Member Registration</h3>
	<p class="all_p dark_bg">
	
You must register as a Member to access certain functions of the Website. You are obliged to provide only complete and accurate information about yourself (the "Registration Data") when registering as a Member or updating your Registration Data.
<BR><BR>You agree to maintain and keep your Registration Data current and to update the Registration Data as soon as it changes. You are responsible for maintaining the security of your password. Our Company and its service providers are not liable for any loss that you may suffer through the use of your password by others.

	</p>
	
	
	
	<h3>Investment Conditions</h3>
	<p class="all_p dark_bg">
	
	Each deposit is considered to be a private transaction between <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
 - Your Profitable Operator and its Member. Members perform all financial transactions solely at their own discretion and their own risk. The Investor personally decides whether or not to invest and how much to invest. All accruals in the Personal Account are made according to the chosen investment package. The Investor has the right to freely dispose of the funds that are on his personal account. The Investor can make a deposit with only help of electronic payment systems used by the Company.
	
	
	
	</p>
	
	
	
	<h3>Refund Policy</h3>
	<p class="all_p dark_bg">
	
	All operations related to the withdrawal of funds carried out only in accordance with the Company’s Refund Policy.
<BR><BR> The Client can only receive a refund of his investment upon expiration of the investment package. 
<BR><BR> You must contact Us to make the right decision before addressing Your complaint to Your payment processor's customer support.

	
	</p>
	
	
	<h3>Confidentiality</h3>
	<p class="all_p dark_bg">
	
	Company undertakes not disclose any personal information of Investor to third parties.
<BR><BR>We act in accordance with policy of complete confidentiality. No information about you, including personal data, information on operations and revenue to anyone except you are available. Your information may only be used by authorized employees of the Company in case of necessity. The only information that is displayed publicly is current deposit statistics, which includes deposit's date and time, amount, payment method and username of the investor. Real name of the Investor is never shown publicly and is never displayed. Investor is allowed to take any username except for forbidden ones. We guarantee confidentiality of all transactions arising from Your membership with the Company at all times.

	
	</p>
	
	
		<h3>Change or Termination</h3>
	<p class="all_p dark_bg">
	
We reserve the right, at our sole discretion and without prior notice, temporarily terminate or suspend the delivery of information through this Website. It can happen when We need to supplement, update, improve or correct the content of this Website. The Website can be shut down temporarily in case of urgent system updates, equipment failures, power cutoffs or natural disasters. The Company does not bear responsibility for direct or indirect losses resulted by such circumstances. 
<BR><BR>We may permanently or temporarily terminate or suspend your access to the Site without notice or liability, if in our sole determination you violate any provision of these Terms of Conditions.

	
	</p>
	
	
	
	
	<h3>Linked Sites</h3>
	<p class="all_p dark_bg">
	
	This website contains links to websites controlled or offered by third parties. We have not reviewed and hereby disclaim responsibility for any information or materials posted at any of the sites. By creating a link to a third party website, we do not endorse or recommend any products or services offered on that website.
	
	</p>
	
	
	
	
	<h3>Links of this website</h3>
	<p class="all_p dark_bg">
	
	
	You can find information about our company on a variety of monitoring websites, forums, blogs etc. We do not track information published by such websites. Opinions or materials provided by such websites may differ from the opinions and materials published on this website and are not endorsed or shared by the management of our company. Our company is not responsible for the privacy policies and other regulations used by third-party websites. We are not responsible for any loss or damage or disclosure of your personal data resulting from the use of the third-party websites.

	</p>
	
	
		<h3>Links to this Website and the Affiliate Program</h3>
	<p class="all_p dark_bg">
	
	You may use and share any links to any page of this website. You should use your unique referral link to take part in the affiliate program. You can publicly share your referral link in your signature on specialized forums of investors or on the pages of own site or blog. You may also send it to your friends, relatives or colleagues to register them in the project. We have no restrictions on the use of referral link other than mass-mailing people unknown to you (also known as spam). Please follow this rule to avoid any problems associated with the blocking of your personal account. 
	
	</p>
	
	
	<h3>Log Files</h3>
	<p class="all_p dark_bg">
	
	We may collect, store and use information about your computer and about your visits to and use of our website (including your IP address, browser type and version, geographical location, operating system, referral source, length of visit, page views and website navigation paths). This information is never linked to personally identifiable information; it is kept confidential and not shared with third parties.
	
	</p>
	
	
	<h3>Cookies</h3>
	<p class="all_p dark_bg">
	
	Our website uses cookies. A cookie is a file containing an identifier (a string of letters and numbers) that is sent by a web server to a web browser and is stored by the browser. The identifier is then sent back to the server each time the browser requests a page from the server. Cookies may be either ‘persistent’ cookies or ‘session’ cookies. A persistent cookie will be stored by a web browser and will remain valid until its set expiry date, unless deleted by the user before the expiry date; a session cookie, on the other hand, will expire at the end of the user session, when the web browser is closed. Cookies do not contain any information that personally identifies a user and are totally harmless. Most browsers allow you to refuse to accept cookies, for example:
	
	<ul class="check_list">
		<li>in Internet Explorer you can block cookies using the cookie handling override settings available by clicking ‘Tools’, ‘Internet Options’, ‘Privacy’ and then ‘Advanced’</li>
		<li>in Firefox you can block all cookies by clicking ‘Tools’, ‘Options’, ‘Privacy’, selecting ‘Use custom settings for history’ from the drop-down menu and unticking ‘Accept cookies from sites’</li>
		<li>in Chrome you can block all cookies by accessing the ‘Customize and control’ menu, and clicking ‘Settings’, ‘Show advanced settings’ and ‘Content settings’, and then selecting ‘Block sites from setting any data’ under the ‘Cookies’ heading.</li>
		
	</ul>
	
	Blocking all cookies will have a negative impact upon the usability of many websites.
    If you block cookies, the website may work incorrectly and you will not be able to use all the features on our website.

	</p>
	
	<BR><BR>
	
	<h3>Website availability and protection against DDoS attacks</h3>
	<p class="all_p dark_bg">
	
	DDoS attacks attempt to bring down and infiltrate websites by flooding the site's origin server with bogus requests, often from multiple locations and networks. If allowed to proceed unchecked, this DDoS attack traffic can produce results ranging from slow page loads to a complete blockage of legitimate site traffic. Given the increasing size, frequency and scale of DDoS attacks, planning for DDoS attack detection and mitigation is a critical business priority. Distributed denial-of-service attacks can paralyze even the most well-structured network for days, freezing online services and crippling a company's reputation. DDoS attacks are destructive stealth weapons that can shutter a business. Our reliance on the Internet continues to grow, and the threat of DDoS attacks continues to expand. In response to the increasing concern of DDoS attacks, our specialists are using professional anti-DDoS solutions to protect our website against most known types of attacks. Our Website is hosted on a dedicated server using strong DDOS protection to keep all information safe and protect us from the most powerful DDOS attacks. 
	
<BR><BR> You are solely responsible for making sure that our services are suitable for your particular purposes. 
	</p>
	
	
	
	<h3>Anti-Spam Policy</h3>
	<p class="all_p dark_bg">
	
	All investors must abide by our strict anti-spam rules that prohibit spamming in any of its forms. It is also stipulated that investors can only make posts about <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
 - Your Profitable Operator on the websites where such posting is allowed. SPAM violators will be immediately and permanently removed from the program.
	
	
	</p>
	
	
	
	
	<h3>Affiliate Program</h3>
	<p class="all_p dark_bg">
	
	<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
 - Your Profitable Operator suggests all registered users of website to participate in affiliate program. Our affiliate program is a great way for you to make money by referring clients. To become a part of the affiliate program you only need to be registered and find a unique referral link in your account. You can use your website, blog, email or even your forum signatures to spread your referral link and promote us to your friends, family, relatives or colleagues and attract referrals. Visitors around the world will use your advertised referral link to join <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
 - Your Profitable Operator and take advantages of our investment services. After registering with your link, a new investor will become your referral. When your referral makes deposit in the program, you will get affiliate commission automatically. 
	Our company offers favorable conditions for multilevel affiliate program. The affiliate program uses multilevel referral commission which will pay 5% from each deposit of level 1 referrals, 2% from each deposit made by your level 2 referrals (people referred by your direct invitees) and 1% of each deposit made by your level 3 referrals (i. e. people referred by your level 2 invitees). 
	The more your referrals invest, the more you can earn. You can either use this money to invest directly from the account balance, or withdraw as ordinary income. We hope it will be a partnership that is mutually beneficial.
	
    </p>
	
	
	
	
	
	
	
	
	
	<h3>Investment Risks</h3>
	<p class="all_p dark_bg">
	
	
	Sophisticated investors know that all investments carry with them some level of risk. An important element of investment management is recognizing various types of risks and controlling their impact on your overall portfolio.
 <BR><BR>   In fact the biggest risk can often be taking no risk at all, because your investment won’t have the growth potential to achieve your goals.

	
    </p>
	
	
	
	<h3>Force Majeure</h3>
	<p class="all_p dark_bg">
	
	
	Force majeure is related to the concept of an "act of God", meaning an event for which no party can be held accountable, such as a hurricane, tornado, earthquake, flood etc. Force majeure also encompasses human actions, however, such as armed conflict, terrorism, insurrection, riot, civil unrest etc. 
<BR><BR>    If an event of Force Majeure occurs neither party is liable to the other party for any failure to perform any obligation.
	
	</p>
	
	
	
	<h3>Acceptance of Terms</h3>
	<p class="all_p dark_bg">
	
	Our Service is offered subject to acceptance of all the terms contained in these Terms of Conditions, including the Privacy Policy and all other operating rules, each of which may be updated by us from time to time without notice to you or liability for such change. Users are advised to periodically review our website for any changes and contact us with any questions.
	
	</p>
	
	
	
	<h3>Communication</h3>
	<p class="all_p dark_bg">
	
	Every client may contact the support service through this website to request any information. You can contact our customer service by different means: either by filling our customer support form or by Email/Tel. You may start a live chat session if one of our representatives are available.

	</p>
	
	<p class="all_p green_bg">
These Terms and Conditions are a part of the agreement between the You and Us. Your using this Website indicates Your understanding, agreement to and acceptance of the Disclaimer and the entire Terms and Conditions.

If You do not agree with any of the above provisions, please do not use any services offered through this Website. 





	</p>
	
	<!--
	
	
	
	
	
	
	
	
	
	
	<h4>Title - h4</h4>
	<p class="all_p dark_bg">
		Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
	</p>
	<p class="all_p f_letter">
		Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
	</p>
	<a href="#" class="custom_link small green">Green small button</a>
	<a href="#" class="custom_link big green">Green big button</a>
	<a href="#" class="custom_link small red">Red small button</a>
	<a href="#" class="custom_link big red">Red big button</a>
	<div class="separator_3"><span></span></div>
	<ul class="check_list">
		<li>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</li>
		<li>Sed ut perspiciatis unde omnis iste natus error sit.</li>
		<li>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</li>
		<li>Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem.</li>
		<li>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li>
	</ul>
	<div class="separator_3"><span></span></div>
	<p class="all_p">
		Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
	</p>
	
	-->
	
</div>

				<?php echo $_smarty_tpl->getSubTemplate ("footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);

}
}
?>