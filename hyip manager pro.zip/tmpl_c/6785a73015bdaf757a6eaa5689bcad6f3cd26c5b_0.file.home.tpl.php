<?php /* Smarty version 3.1.27, created on 2017-06-20 18:29:03
         compiled from "/home/cryptoorbit/public_html/tmpl/home.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:18381751085949696fa176f8_97240570%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '6785a73015bdaf757a6eaa5689bcad6f3cd26c5b' => 
    array (
      0 => '/home/cryptoorbit/public_html/tmpl/home.tpl',
      1 => 1497961198,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '18381751085949696fa176f8_97240570',
  'variables' => 
  array (
    'settings' => 0,
    'currency_sign' => 0,
    'stat_last_deposit' => 0,
    'stat_last_withdrawal' => 0,
    'last_deposits' => 0,
    's' => 0,
    'last_withdrawals' => 0,
    'news' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_5949696fb84894_03485513',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5949696fb84894_03485513')) {
function content_5949696fb84894_03485513 ($_smarty_tpl) {
if (!is_callable('smarty_modifier_myescape')) require_once '/home/cryptoorbit/public_html/inc/libs/smarty3/plugins/modifier.myescape.php';

$_smarty_tpl->properties['nocache_hash'] = '18381751085949696fa176f8_97240570';
echo $_smarty_tpl->getSubTemplate ("logo.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>

			<div class="h_bottom">
								<div class="main_slider">
					<div class="progress_cont">
						<div class="progress_bar" data-slide="0"><span></span></div>
						<div class="progress_bar" data-slide="1"><span></span></div>
						<div class="progress_bar" data-slide="2"><span></span></div>
					</div>
					<div class="arrow"></div>
					<ul class="slides clearfix">
						<li data-slide="0">
							<div class="slide slide_1">
								<div class="container">
									<div class="cogwheel"></div>
									<div class="caption">
										<h2>High and stable profit.</h2>
										<div class="separator_1"><span></span></div>
										<p>
											The experience and skills of our traders and financial experts is the key to the success of the investment fund. The main objective of <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
 investment fund is to ensure high returns in the long term. Our online platform offers a wide variety of opportunities for us and our investors. Safe and quality management of financial assets in the form of invested funds is achieved through well-built trading strategies, thorough analysis of the market and professional experience.
										</p>
									</div>
									<div class="people"></div>
								</div>
							</div>
						</li>
						<li data-slide="1">
							<div class="slide slide_2">
								<div class="container">
									<div class="cogwheel"></div>
									<div class="caption">
										<h2>Profitable affiliate program.</h2>
										<div class="separator_1"><span></span></div>
										<p>
										<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
 suggests all registered users of website to participate in affiliate program. Our affiliate program is a great way for you to make money by referring clients. Receive 5% from every deposit of your direct referral – an investor whom you have invited personally through your personal referral link. If your referral invites someone, you will receive level 2 referral bonus 2% from every deposit of that investor. And if your level 2 referral invites someone, you will receive a level 3 referral bonus of 1%. Just share the word of our investment fund with your friends and other people to create a lucrative income stream paying you from every new deposit in your three-level downline.
										</p>
									</div>
									<div class="people"></div>
								</div>
							</div>
						</li>
						<li data-slide="2">
							<div class="slide slide_3">
								<div class="container">
									<div class="cogwheel"></div>
									<div class="caption">
										<h2>You’ll never be alone…</h2>
										<div class="separator_1"><span></span></div>
										<p>						
											We are available 24/7 and 365 days a year and ready to answer your questions. We have a lot more managers available for support and you can get in touch with a live person within a seconds at any given time. We also evaluate our employee's speed, as well as the staff performance as a whole, on a regular basis. We use best software for your convenience with our live chat section. Please don't forget to check the FAQ section, you are able to find answers all popular questions.	
										</p>
									</div>
									<div class="people"></div>
								</div>
							</div>
						</li>
					</ul>
				</div>
												<div class="hb_bottom all">
					<div class="container clearfix">
						<ul class="h_stat">
							<li>
								<div class="icon icon_1"><span></span></div>
								<div class="hs_info">
									<div class="title">Running Days</div>
									<div class="subtitle"><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_days_online_generated']);?>
</div>
								</div>
							</li>
							<li>
								<div class="icon icon_2"><span></span></div>
								<div class="hs_info">
									<div class="title">Total Accounts</div>
									<div class="subtitle"><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['info_box_total_accounts_generated']);?>
</div>
								</div>
							</li>
							<li>
								<div class="icon icon_3"><span></span></div>
								<div class="hs_info">
									<div class="title">Total Deposited</div>
									<div class="subtitle"><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['currency_sign']->value);?>
 <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['info_box_deposit_funds_generated']);?>
</div>
								</div>
							</li>
							<li>
								<div class="icon icon_4"><span></span></div>
								<div class="hs_info">
									<div class="title">Total Withdraw</div>
									<div class="subtitle"><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['currency_sign']->value);?>
 <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['info_box_withdraw_funds_generated']);?>
</div>
								</div>
							</li>
						</ul>
						<ul class="get_started">
							<li><span class="text">It's time to take the next step!</span></li>
							<li>
								<a href="?a=cust&page=get_started">Get Started Today</a>
								<div class="sub_menu top">
									<ul>
										<li><a href="?a=cust&page=get_started">Get Started Guide</a></li>
										<li><a href="?a=cust&page=our_deposit_methods">Our Deposit Methods</a></li>
										<li><a href="?a=cust&page=popular_exchangers">Popular Exchangers</a></li>
									</ul>
								</div>
							</li>
						</ul>
					</div>
				</div>
							</div>
		</header>
				<section class="inv_plans">
			<div data-parallaxify-range-x="-30" class="parallax ip_parallax_1"></div>
			<div data-parallaxify-range-x="30" class="parallax ip_parallax_2"></div>
			<div class="container">
				<h1>Our investment plans</h1>
				<div class="separator_2"><span></span></div>
				<ul class="plans_cont clearfix">
					<li class="plan_1 calc_link">
						<div class="plan_title">
							<div class="icon"></div>
							<p><span class="s1">130%</span> Daily<br>for <span class="s1">60</span> Days</p>
						</div>
						<div class="plan_info">
							<div>- Minimum: <span>$10</span></div>
							<div>- Maximum: <span>$1,000</span></div>
							<div>- Principal: <span>Back</span></div>
						</div>
						<div class="plan_button"><span>Calculator</span></div>
					</li>
					<li class="plan_2 calc_link">
						<div class="plan_title">
							<div class="icon"></div>
							<p><span class="s1">160%</span> Daily<br>for <span class="s1">120</span> Days</p>
						</div>
						<div class="plan_info">
							<div>- Minimum: <span>$10</span></div>
							<div>- Maximum: <span>$10,000</span></div>
							<div>- Principal: <span>Back</span></div>
						</div>
						<div class="plan_button"><span>Calculator</span></div>
					</li>
					<li class="plan_3 calc_link">
						<div class="plan_title">
							<div class="icon"></div>
							<p><span class="s1">200%</span> After<br><span class="s1">180</span> <span class="s2">Days</span></p>
						</div>
						<div class="plan_info">
							<div>- Minimum: <span>$20</span></div>
							<div>- Maximum: <span>$20,000</span></div>
							<div>- Principal: <span>Include</span></div>
						</div>
						<div class="plan_button"><span>Calculator</span></div>
					</li>
					<li class="plan_4 calc_link">
						<div class="plan_title">
							<div class="icon"></div>
							<p><span class="s1">260%</span> After<br><span class="s1">240</span> <span class="s2">Days</span></p>
						</div>
						<div class="plan_info">
							<div>- Minimum: <span>$20</span></div>
							<div>- Maximum: <span>$50,000</span></div>
							<div>- Principal: <span>Include</span></div>
						</div>
						<div class="plan_button"><span>Calculator</span></div>
					</li>
					<li class="plan_5 calc_link">
						<div class="plan_title">
							<div class="icon"></div>
							<p><span class="s1">300%</span> After<br><span class="s1">300</span> <span class="s2">Days</span></p>
						</div>
						<div class="plan_info">
							<div>- Minimum: <span>$50</span></div>
							<div>- Maximum: <span>$50,000</span></div>
							<div>- Principal: <span>Include</span></div>
						</div>
						<div class="plan_button"><span>Calculator</span></div>
					</li>
					<li class="plan_6 calc_link">
						<div class="plan_title">
							<div class="icon"></div>
							<p><span class="s1">365%</span> After<br><span class="s1">365</span> <span class="s2">Days</span></p>
						</div>
						<div class="plan_info">
							<div>- Minimum: <span>$100</span></div>
							<div>- Maximum: <span>$50,000</span></div>
							<div>- Principal: <span>Include</span></div>
						</div>
						<div class="plan_button"><span>Calculator</span></div>
					</li>
					<li class="plan_7 calc_link">
						<div class="plan_title">
							<div class="icon"></div>
							<p><span class="s1">500%</span> After<br><span class="s1">540</span> <span class="s2">Days</span></p>
						</div>
						<div class="plan_info">
							<div>- Minimum: <span>$100</span></div>
							<div>- Maximum: <span>$100,000</span></div>
							<div>- Principal: <span>Include</span></div>
						</div>
						<div class="plan_button"><span>Calculator</span></div>
					</li>
				</ul>
			</div>
		</section>
		<section class="home_about">
			<div class="container clearfix">
				<div class="about">
					<h2>Welcome to <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
 Website</h2>
					<div class="separator_1"><span></span></div>
					<div class="text">
						<p>
							Are you looking for stable income from your investments? We can help you by providing the necessary platform. The <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
 LTD is modern investment company from the UK. The company's business is closely related to trading activity in the multi - Crypto Currency market, as well as on the Stock Exchange, coin investment & mining. Our company also offers a high-return investing in promising Fintech start-ups and digital currency known as Bitcoin. Currently, <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
 is entering into a new phase of its development. Since we have begun to get stable and high profit we need new investment interactions.
						</p>
						<p>
							Our company has developed and launched an online platform for investors that allows making deposits and regular accruals of profits in automatic mode. This will help us to multiply our present profit level many times. The Company is attracting investments to benefit from the effect of scale - the higher the investment, the higher the return. <br>
							Join us, get in into your financial well-being!
							<a href="?a=cust&page=about_us">Read More</a>
						</p>
					</div>
				</div>
				<div class="affiliate">
					<h2>Our Referral Commission</h2>
					<div class="separator_1"><span></span></div>
					<div class="aff_cont">
						<div class="icon"><span></span></div>
						<div class="aff aff_1">
							<span></span>
							<div class="text">
								<div class="title">1 level</div>
								<div class="subtitle">5%</div>
							</div>
						</div>
						<div class="aff aff_2">
							<span></span>
							<div class="text">
								<div class="title">2 level</div>
								<div class="subtitle">2%</div>
							</div>
						</div>
						<div class="aff aff_3">
							<span></span>
							<div class="text">
								<div class="title">3 level</div>
								<div class="subtitle">1%</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="arrow"></div>
		</section>
		<section class="rl_wrap">
			<div class="container clearfix">
				<div class="home_rep">
					<h2>Regional Representatives</h2>
					<div class="separator_1"><span></span></div>
					<div class="hr_cont">
						<p><span>Earn up to <span>11%</span></span><br>Referral Commission as<br>Regional Representative</p>
						<a href="?a=cust&page=our_representatives" class="custom_link big red">Our Representatives</a>
					</div>
				</div>
				<div class="home_landing">
					<h2>Our Landing Page</h2>
					<div class="separator_1"><span></span></div>
					<div class="hl_cont">
						<div class="text_1">Looking for promotion materials?</div>
						<div class="text_2">Check our Landing page</div>
						<a href="?a=cust&page=landing_en" target="_blank">Click here to see Landing Page.</a>
					</div>
				</div>
			</div>
		</section>
		<section class="vf_wrap">
			<div class="container clearfix">
				<div class="promo_video">
					<h2>Video Presentation</h2>
					<div class="separator_1"><span></span></div>
					<div class="v_block">
						<iframe width="490" height="276" src="https://www.youtube.com/embed/Gc2en3nHxA4" frameborder="0" allowfullscreen></iframe>
					</div>
					<ul class="clearfix">
						<li><a href="?a=cust&page=video" class="custom_link big green">Other Videos</a></li>
						<li><a href="https://www.youtube.com/channel/" class="custom_link big red" target="_blank">Our Youtube channel</a></li>
					</ul>
				</div>
				<div class="f_group">
					<h2>Our Facebook page</h2>
					<div class="separator_1"><span></span></div>
					<div class="fb_plugin">
						<div id="fb-root"></div>
						
						<?php echo '<script'; ?>
>
							(function(d, s, id) {
							var js, fjs = d.getElementsByTagName(s)[0];
							if (d.getElementById(id)) return;
							js = d.createElement(s); js.id = id;
							js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.5";
							fjs.parentNode.insertBefore(js, fjs);
							}(document, 'script', 'facebook-jssdk'));
						<?php echo '</script'; ?>
>
						
						<div class="fb-page" data-href="https://www.facebook.com/" data-tabs="timeline" data-width="490" data-height="330" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"></div>
					</div>
				</div>
			</div>
			<div class="arrow"></div>
		</section>
		
		<!--
		<section class="m_reviews">
			<div class="container clearfix">
			


			<h1>Video Testimonials</h1>
				<div class="separator_2"><span></span></div>
				<div class="rev_carousel">
					<ul class="slides clearfix">
						<li>
							
						</li>
						<li>
							<div class="test_img"></div>
						</li>
						<li>
							<div class="test_img"></div>
						</li>
						<li>
							<div class="test_img"></div>
						</li>
						<li>
							<div class="test_img"></div>
						</li>
						<li>
							<div class="test_img"></div>
						</li>
					</ul>
				</div>
			</div>
		</section>
		
		-->
		
		<section class="live_stat">
			<div data-parallaxify-range-x="-30" class="parallax ip_parallax_1"></div>
			<div data-parallaxify-range-x="30" class="parallax ip_parallax_2"></div>
			<div class="container">
				<h1>Live Statistic</h1>
				<div class="separator_2"><span></span></div>
				<ul class="stat_cont clearfix">
					<li class="full_stat">
						<div class="title">Full Statistic<div class="icon"></div></div>
						<ul>
							<li>Started:<span><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_start_month_str_generated']);?>
 <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_start_day']);?>
, <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_start_year']);?>
</span></li>
							<li>Running Days:<span><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_days_online_generated']);?>
</span></li>
							<li>Total Accounts:<span><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['info_box_total_accounts_generated']);?>
</span></li>
							<li>Total Deposited:<span><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['currency_sign']->value);?>
 <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['info_box_deposit_funds_generated']);?>
</span></li>
							<li>Total Withdraw:<span><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['currency_sign']->value);?>
 <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['info_box_withdraw_funds_generated']);?>
</span></li>
							<li>Newest Member:<span><?php if ($_smarty_tpl->tpl_vars['settings']->value['show_info_box_newest_member_generated']) {
echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['show_info_box_newest_member_generated']);
} else { ?>N/A<?php }?></span></li>
							<li>Visitors Online:<span><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['info_box_visitor_online_generated']);?>
</span></li>
							<li>Last Deposit:<span><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['currency_sign']->value);?>
 <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['stat_last_deposit']->value['amount']);?>
 (<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['stat_last_deposit']->value['username']);?>
)</span></li>
							<li>Last Withdraw:<span><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['currency_sign']->value);?>
 <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['stat_last_withdrawal']->value['amount']);?>
 (<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['stat_last_withdrawal']->value['username']);?>
)</span></li>
							<li>Last Update:<span><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['show_info_box_last_update_generated']);?>
</span></li>
						</ul>
					</li>
					<li class="inv_last">
						<div class="title">Investors Last<div class="icon"></div></div>
						<ul>
						<?php if ($_smarty_tpl->tpl_vars['last_deposits']->value) {?>
						<?php
$_from = $_smarty_tpl->tpl_vars['last_deposits']->value;
if (!is_array($_from) && !is_object($_from)) {
settype($_from, 'array');
}
$_smarty_tpl->tpl_vars['s'] = new Smarty_Variable;
$_smarty_tpl->tpl_vars['s']->_loop = false;
foreach ($_from as $_smarty_tpl->tpl_vars['s']->value) {
$_smarty_tpl->tpl_vars['s']->_loop = true;
$foreach_s_Sav = $_smarty_tpl->tpl_vars['s'];
?>
			<li><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['s']->value['username']);?>
<span style="background: url(images/<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['s']->value['ec']);?>
.gif) no-repeat right center;"><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['currency_sign']->value);
echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['s']->value['amount']);?>
</span></li>
		<?php
$_smarty_tpl->tpl_vars['s'] = $foreach_s_Sav;
}
} else { ?>
		
		<li>No data found:<span style="">N/A</span></li>
		<?php }?>
	</ul>
					</li>
					<li class="paid_out">
						<div class="title">Paid Out<div class="icon"></div></div>
						<ul>
		
	<?php if ($_smarty_tpl->tpl_vars['last_withdrawals']->value) {
$_from = $_smarty_tpl->tpl_vars['last_withdrawals']->value;
if (!is_array($_from) && !is_object($_from)) {
settype($_from, 'array');
}
$_smarty_tpl->tpl_vars['s'] = new Smarty_Variable;
$_smarty_tpl->tpl_vars['s']->_loop = false;
foreach ($_from as $_smarty_tpl->tpl_vars['s']->value) {
$_smarty_tpl->tpl_vars['s']->_loop = true;
$foreach_s_Sav = $_smarty_tpl->tpl_vars['s'];
?>	
<li class="clearfix"><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['s']->value['username']);?>
:<span style="background: url(images/<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['s']->value['ec']);?>
.gif) no-repeat right center;"><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['currency_sign']->value);
echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['s']->value['amount']);?>
</span></li>
		<?php
$_smarty_tpl->tpl_vars['s'] = $foreach_s_Sav;
}
?> <?php } else { ?>
		<li class="clearfix">No data found:<span style="">N/A</span></li>
		<?php }?>
		
	</ul>
					</li>
				</ul>
			</div>
		</section>
		<section class="nc_wrap">
			<div class="container clearfix">
				<div class="last_news">
					<h2>Our Latest News</h2>
					<div class="separator_1"><span></span></div>
								<?php if (isset($_smarty_tpl->tpl_vars['smarty']->value['section']['s'])) unset($_smarty_tpl->tpl_vars['smarty']->value['section']['s']);
$_smarty_tpl->tpl_vars['smarty']->value['section']['s']['name'] = 's';
$_smarty_tpl->tpl_vars['smarty']->value['section']['s']['loop'] = is_array($_loop=$_smarty_tpl->tpl_vars['news']->value) ? count($_loop) : max(0, (int) $_loop); unset($_loop);
$_smarty_tpl->tpl_vars['smarty']->value['section']['s']['show'] = true;
$_smarty_tpl->tpl_vars['smarty']->value['section']['s']['max'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['s']['loop'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['s']['step'] = 1;
$_smarty_tpl->tpl_vars['smarty']->value['section']['s']['start'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['s']['step'] > 0 ? 0 : $_smarty_tpl->tpl_vars['smarty']->value['section']['s']['loop']-1;
if ($_smarty_tpl->tpl_vars['smarty']->value['section']['s']['show']) {
    $_smarty_tpl->tpl_vars['smarty']->value['section']['s']['total'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['s']['loop'];
    if ($_smarty_tpl->tpl_vars['smarty']->value['section']['s']['total'] == 0)
        $_smarty_tpl->tpl_vars['smarty']->value['section']['s']['show'] = false;
} else
    $_smarty_tpl->tpl_vars['smarty']->value['section']['s']['total'] = 0;
if ($_smarty_tpl->tpl_vars['smarty']->value['section']['s']['show']):

            for ($_smarty_tpl->tpl_vars['smarty']->value['section']['s']['index'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['s']['start'], $_smarty_tpl->tpl_vars['smarty']->value['section']['s']['iteration'] = 1;
                 $_smarty_tpl->tpl_vars['smarty']->value['section']['s']['iteration'] <= $_smarty_tpl->tpl_vars['smarty']->value['section']['s']['total'];
                 $_smarty_tpl->tpl_vars['smarty']->value['section']['s']['index'] += $_smarty_tpl->tpl_vars['smarty']->value['section']['s']['step'], $_smarty_tpl->tpl_vars['smarty']->value['section']['s']['iteration']++):
$_smarty_tpl->tpl_vars['smarty']->value['section']['s']['rownum'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['s']['iteration'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['s']['index_prev'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['s']['index'] - $_smarty_tpl->tpl_vars['smarty']->value['section']['s']['step'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['s']['index_next'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['s']['index'] + $_smarty_tpl->tpl_vars['smarty']->value['section']['s']['step'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['s']['first']      = ($_smarty_tpl->tpl_vars['smarty']->value['section']['s']['iteration'] == 1);
$_smarty_tpl->tpl_vars['smarty']->value['section']['s']['last']       = ($_smarty_tpl->tpl_vars['smarty']->value['section']['s']['iteration'] == $_smarty_tpl->tpl_vars['smarty']->value['section']['s']['total']);
?>		<div class="news_cont">
	<h4><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['news']->value[$_smarty_tpl->getVariable('smarty')->value['section']['s']['index']]['title']);?>
</h4>
	<div class="news_text"><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['news']->value[$_smarty_tpl->getVariable('smarty')->value['section']['s']['index']]['small_text']);?>
</div>
	<div class="news_b clearfix">
		<div class="date"><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['news']->value[$_smarty_tpl->getVariable('smarty')->value['section']['s']['index']]['d']);?>
</div>
		<a href="?a=news" class="custom_link small green">Read More</a>
	</div>
</div> <?php endfor; endif; ?>

									</div>
				<div class="charts">
					<h2>Our Cryptocurrency Chart</h2>
					<div class="separator_1"><span></span></div>
					<div class="chart_cont">
						<iframe width="488" height="203" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://myip.ms/crypto.php?m=7777&amp;&amp;c=00c68b&amp;p=2&amp;c5=9a9a9a&amp;c6=424242&amp;c12=fff&amp;c14=e6e6e6&amp;c18=e6e6e6&amp;c19=e6e6e6&amp;h=203&amp;w=488&amp;t=usd"></iframe>
					</div>
				</div>
			</div>
		</section>
		


<?php echo $_smarty_tpl->getSubTemplate ("footer2.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);

}
}
?>