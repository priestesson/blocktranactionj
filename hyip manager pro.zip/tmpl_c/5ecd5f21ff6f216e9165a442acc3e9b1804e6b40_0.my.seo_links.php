<?php /* Smarty version 3.1.27, created on 2017-06-18 12:25:18
         compiled from "my:seo_links" */ ?>
<?php
/*%%SmartyHeaderCode:19475873245946712e5be290_39430014%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '5ecd5f21ff6f216e9165a442acc3e9b1804e6b40' => 
    array (
      0 => 'my:seo_links',
      1 => 1497788718,
      2 => 'my',
    ),
  ),
  'nocache_hash' => '19475873245946712e5be290_39430014',
  'variables' => 
  array (
    'settings' => 0,
    'actions' => 0,
    'a' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_5946712e6a2750_75185732',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5946712e6a2750_75185732')) {
function content_5946712e6a2750_75185732 ($_smarty_tpl) {
if (!is_callable('smarty_modifier_myescape')) require_once '/home/cryptoorbit/public_html/inc/libs/smarty3/plugins/modifier.myescape.php';

$_smarty_tpl->properties['nocache_hash'] = '19475873245946712e5be290_39430014';
?>
<b>Review settings:</b><br><br> <?php echo $_smarty_tpl->getSubTemplate ("my:start_info_table", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>
 Before enable this option be sure you have configure your web server correctly.<br> For Apache web server you should place these lines to .htaccess file in the script root folder: <div style="border:dotted 1px black;padding:3px;margin:3px;background:#fff;"> RewriteEngine on <br> RewriteCond %&#123;REQUEST_FILENAME&#125; -f [OR]<br> RewriteCond %&#123;REQUEST_FILENAME&#125; -d <br> RewriteRule ^.*$ - [NC,L]<br> RewriteRule .* index.php [L]<br> </div> Be aware to replace an action code with other action code. It will makes first action unavailable. <?php echo $_smarty_tpl->getSubTemplate ("my:end_info_table", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>
 <br> <form method=post> <input type=hidden name=a value=seo_links> <input type=hidden name=action value=save_settings> <input type=checkbox value=1 name=seo_links <?php if ($_smarty_tpl->tpl_vars['settings']->value['seo_links'] == 1) {?>checked<?php }?>> Use SEO links<br><br> <input type=submit value="Save" class=sbmt> </form> <br><br> <?php echo '<script'; ?>
> var acts_size = <?php echo smarty_modifier_myescape(count($_smarty_tpl->tpl_vars['actions']->value));?>
;  function check_actions() { var dacts = {}; for(i=1;i<acts_size;i++) { if (o = document.getElementById("def"+i)) { n = o.innerHTML; dacts[n] = 1; } } var vacts = {}; for(i=1;i<acts_size;i++) { if (o = document.getElementById("val"+i)) { n = o.value; if (n != "" && !n.match(/^[a-zA-Z0-9\-\_\.]+$/)) { alert("Action should not have spaces and other special chars. Alphabet characters, digits, dot, underscore and minus only. Please change."); o.focus(); return false; } if (dacts[n] == 1) { alert("You can not set default name for other action. Please change."); o.focus(); return false; } if (vacts[n] == 1) { alert("You can not set same names for several actions. Please change."); o.focus(); return false; } if (n != "") vacts[n] = 1; } } return true; }  <?php echo '</script'; ?>
> <b>Actions:</b><br><br> <form method=post onsubmit="return check_actions()"> <input type=hidden name=a value=seo_links> <input type=hidden name=action value=save> <table cellspacing=1 cellpadding=2 border=0 width=100<?php echo '%>';?> <tr> <th bgcolor=FFEA00 width=120>Default</th> <th bgcolor=FFEA00>Rename</th> </tr> <?php
$_from = $_smarty_tpl->tpl_vars['actions']->value;
if (!is_array($_from) && !is_object($_from)) {
settype($_from, 'array');
}
$_smarty_tpl->tpl_vars['a'] = new Smarty_Variable;
$_smarty_tpl->tpl_vars['a']->_loop = false;
$_smarty_tpl->tpl_vars['__foreach_acts'] = new Smarty_Variable(array('iteration' => 0));
foreach ($_from as $_smarty_tpl->tpl_vars['a']->value) {
$_smarty_tpl->tpl_vars['a']->_loop = true;
$_smarty_tpl->tpl_vars['__foreach_acts']->value['iteration']++;
$foreach_a_Sav = $_smarty_tpl->tpl_vars['a'];
?> <tr> <td id="def<?php echo smarty_modifier_myescape((isset($_smarty_tpl->tpl_vars['__foreach_acts']->value['iteration']) ? $_smarty_tpl->tpl_vars['__foreach_acts']->value['iteration'] : null));?>
"><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['a']->value['default']);?>
</td> <td><input type=text name="actions[<?php echo smarty_modifier_myescape(htmlspecialchars($_smarty_tpl->tpl_vars['a']->value['default'], ENT_QUOTES, 'UTF-8', true));?>
]" value="<?php echo smarty_modifier_myescape(htmlspecialchars($_smarty_tpl->tpl_vars['a']->value['replace'], ENT_QUOTES, 'UTF-8', true));?>
" class=inpts size=30 id="val<?php echo smarty_modifier_myescape((isset($_smarty_tpl->tpl_vars['__foreach_acts']->value['iteration']) ? $_smarty_tpl->tpl_vars['__foreach_acts']->value['iteration'] : null));?>
"></td> </tr> <?php
$_smarty_tpl->tpl_vars['a'] = $foreach_a_Sav;
}
?> <tr> <td></td> <td><input type=submit value="Save" class=sbmt></td> </tr> </table><br> </form> <?php echo $_smarty_tpl->getSubTemplate ("my:start_info_table", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>
 Here you could change names of actions links.<br> <?php echo $_smarty_tpl->getSubTemplate ("my:end_info_table", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);

}
}
?>