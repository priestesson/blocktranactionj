<?php /* Smarty version 3.1.27, created on 2017-06-19 04:17:05
         compiled from "/home/cryptoorbit/public_html/tmpl/rateus.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:12787673645947504156a3d0_66335429%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '8800684c21b8ff4370dc3f1998c36351657091c6' => 
    array (
      0 => '/home/cryptoorbit/public_html/tmpl/rateus.tpl',
      1 => 1481520540,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '12787673645947504156a3d0_66335429',
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_5947504162d4a6_81813788',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5947504162d4a6_81813788')) {
function content_5947504162d4a6_81813788 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '12787673645947504156a3d0_66335429';
echo $_smarty_tpl->getSubTemplate ("header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>


<h1>Rate Us</h1>
<div class="separator_2"><span></span></div>

<div class="rateus_page">
	<table>
		
                 <tr>
			<td align="center">Monitor Button</td>
			<td align="center">Monitor Button</td>
			<td align="center">Monitor Button</td>
			<td align="center">Monitor Button</td>
                 
		</tr>
		
		  <tr>
			<td align="center">Monitor Button</td>
			<td align="center">Monitor Button</td>
			<td align="center">Monitor Button</td>
			<td align="center">Monitor Button</td>
                 
		</tr>
		
		
		  <tr>
			<td align="center">Monitor Button</td>
			<td align="center">Monitor Button</td>
			<td align="center">Monitor Button</td>
			<td align="center">Monitor Button</td>
                 
		</tr>
		
		
		  <tr>
			<td align="center">Monitor Button</td>
			<td align="center">Monitor Button</td>
			<td align="center">Monitor Button</td>
			<td align="center">Monitor Button</td>
                 
		</tr>
		
		  <tr>
			<td align="center">Monitor Button</td>
			<td align="center">Monitor Button</td>
			<td align="center">Monitor Button</td>
			<td align="center">Monitor Button</td>
                 
		</tr>
		
		  <tr>
			<td align="center">Monitor Button</td>
			<td align="center">Monitor Button</td>
			<td align="center">Monitor Button</td>
			<td align="center">Monitor Button</td>
                 
		</tr>
                
	</table>
</div>

					</div>
		</section>
				<?php echo $_smarty_tpl->getSubTemplate ("footer2.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);

}
}
?>