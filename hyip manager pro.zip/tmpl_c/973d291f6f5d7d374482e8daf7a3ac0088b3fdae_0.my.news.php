<?php /* Smarty version 3.1.27, created on 2017-06-20 13:44:58
         compiled from "my:news" */ ?>
<?php
/*%%SmartyHeaderCode:712876583594926daae6020_32056107%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '973d291f6f5d7d374482e8daf7a3ac0088b3fdae' => 
    array (
      0 => 'my:news',
      1 => 1497966298,
      2 => 'my',
    ),
  ),
  'nocache_hash' => '712876583594926daae6020_32056107',
  'variables' => 
  array (
    'news' => 0,
    'n' => 0,
    'frm' => 0,
    'colpages' => 0,
    'edit_news' => 0,
    'languages' => 0,
    'l' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_594926dac77861_83053412',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_594926dac77861_83053412')) {
function content_594926dac77861_83053412 ($_smarty_tpl) {
if (!is_callable('smarty_modifier_myescape')) require_once '/home/cryptoorbit/public_html/inc/libs/smarty3/plugins/modifier.myescape.php';

$_smarty_tpl->properties['nocache_hash'] = '712876583594926daae6020_32056107';
?>
 <b>Add/Edit News:</b><br><br> <?php if ($_smarty_tpl->tpl_vars['news']->value) {?> <table cellspacing=1 cellpadding=2 border=0 width=100<?php echo '%>';?> <?php
$_from = $_smarty_tpl->tpl_vars['news']->value;
if (!is_array($_from) && !is_object($_from)) {
settype($_from, 'array');
}
$_smarty_tpl->tpl_vars['n'] = new Smarty_Variable;
$_smarty_tpl->tpl_vars['n']->_loop = false;
foreach ($_from as $_smarty_tpl->tpl_vars['n']->value) {
$_smarty_tpl->tpl_vars['n']->_loop = true;
$foreach_n_Sav = $_smarty_tpl->tpl_vars['n'];
?> <tr><td> <b><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['n']->value['title']);?>
</b><br> <?php if ($_smarty_tpl->tpl_vars['n']->value['private']) {?><b style="color: red">private</b><?php }?> <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['n']->value['small_text']);?>
<br> <small><i><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['n']->value['d']);?>
</i></small> <a href="?a=news&action=edit&id=<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['n']->value['id']);?>
&page=<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['frm']->value['page']);?>
#editform">[EDIT]</a> <a href="?a=news&action=delete&id=<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['n']->value['id']);?>
&page=<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['frm']->value['page']);?>
" onclick="return confirm('Do you really want to delete news?')">[REMOVE]</a> </td></tr> <?php
$_smarty_tpl->tpl_vars['n'] = $foreach_n_Sav;
}
?> </table> <center> <?php if ($_smarty_tpl->tpl_vars['colpages']->value > 1) {?> <?php if ($_smarty_tpl->tpl_vars['frm']->value['page'] > 1) {?><a href="?a=news&page=<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['frm']->value['page']-1);?>
">&lt;&lt;</a>&nbsp;<?php }?> <?php if (isset($_smarty_tpl->tpl_vars['smarty']->value['section']['p'])) unset($_smarty_tpl->tpl_vars['smarty']->value['section']['p']);
$_smarty_tpl->tpl_vars['smarty']->value['section']['p']['name'] = 'p';
$_smarty_tpl->tpl_vars['smarty']->value['section']['p']['start'] = (int) 1;
$_smarty_tpl->tpl_vars['smarty']->value['section']['p']['loop'] = is_array($_loop=$_smarty_tpl->tpl_vars['colpages']->value) ? count($_loop) : max(0, (int) $_loop); unset($_loop);
$_smarty_tpl->tpl_vars['smarty']->value['section']['p']['step'] = ((int) 1) == 0 ? 1 : (int) 1;
$_smarty_tpl->tpl_vars['smarty']->value['section']['p']['show'] = true;
$_smarty_tpl->tpl_vars['smarty']->value['section']['p']['max'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['p']['loop'];
if ($_smarty_tpl->tpl_vars['smarty']->value['section']['p']['start'] < 0)
    $_smarty_tpl->tpl_vars['smarty']->value['section']['p']['start'] = max($_smarty_tpl->tpl_vars['smarty']->value['section']['p']['step'] > 0 ? 0 : -1, $_smarty_tpl->tpl_vars['smarty']->value['section']['p']['loop'] + $_smarty_tpl->tpl_vars['smarty']->value['section']['p']['start']);
else
    $_smarty_tpl->tpl_vars['smarty']->value['section']['p']['start'] = min($_smarty_tpl->tpl_vars['smarty']->value['section']['p']['start'], $_smarty_tpl->tpl_vars['smarty']->value['section']['p']['step'] > 0 ? $_smarty_tpl->tpl_vars['smarty']->value['section']['p']['loop'] : $_smarty_tpl->tpl_vars['smarty']->value['section']['p']['loop']-1);
if ($_smarty_tpl->tpl_vars['smarty']->value['section']['p']['show']) {
    $_smarty_tpl->tpl_vars['smarty']->value['section']['p']['total'] = min(ceil(($_smarty_tpl->tpl_vars['smarty']->value['section']['p']['step'] > 0 ? $_smarty_tpl->tpl_vars['smarty']->value['section']['p']['loop'] - $_smarty_tpl->tpl_vars['smarty']->value['section']['p']['start'] : $_smarty_tpl->tpl_vars['smarty']->value['section']['p']['start']+1)/abs($_smarty_tpl->tpl_vars['smarty']->value['section']['p']['step'])), $_smarty_tpl->tpl_vars['smarty']->value['section']['p']['max']);
    if ($_smarty_tpl->tpl_vars['smarty']->value['section']['p']['total'] == 0)
        $_smarty_tpl->tpl_vars['smarty']->value['section']['p']['show'] = false;
} else
    $_smarty_tpl->tpl_vars['smarty']->value['section']['p']['total'] = 0;
if ($_smarty_tpl->tpl_vars['smarty']->value['section']['p']['show']):

            for ($_smarty_tpl->tpl_vars['smarty']->value['section']['p']['index'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['p']['start'], $_smarty_tpl->tpl_vars['smarty']->value['section']['p']['iteration'] = 1;
                 $_smarty_tpl->tpl_vars['smarty']->value['section']['p']['iteration'] <= $_smarty_tpl->tpl_vars['smarty']->value['section']['p']['total'];
                 $_smarty_tpl->tpl_vars['smarty']->value['section']['p']['index'] += $_smarty_tpl->tpl_vars['smarty']->value['section']['p']['step'], $_smarty_tpl->tpl_vars['smarty']->value['section']['p']['iteration']++):
$_smarty_tpl->tpl_vars['smarty']->value['section']['p']['rownum'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['p']['iteration'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['p']['index_prev'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['p']['index'] - $_smarty_tpl->tpl_vars['smarty']->value['section']['p']['step'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['p']['index_next'] = $_smarty_tpl->tpl_vars['smarty']->value['section']['p']['index'] + $_smarty_tpl->tpl_vars['smarty']->value['section']['p']['step'];
$_smarty_tpl->tpl_vars['smarty']->value['section']['p']['first']      = ($_smarty_tpl->tpl_vars['smarty']->value['section']['p']['iteration'] == 1);
$_smarty_tpl->tpl_vars['smarty']->value['section']['p']['last']       = ($_smarty_tpl->tpl_vars['smarty']->value['section']['p']['iteration'] == $_smarty_tpl->tpl_vars['smarty']->value['section']['p']['total']);
?> <?php if ($_smarty_tpl->getVariable('smarty')->value['section']['p']['index'] == $_smarty_tpl->tpl_vars['frm']->value['page']) {?> <b><?php echo smarty_modifier_myescape($_smarty_tpl->getVariable('smarty')->value['section']['p']['index']);?>
</b>&nbsp; <?php } else { ?> <a href="?a=news&page=<?php echo smarty_modifier_myescape($_smarty_tpl->getVariable('smarty')->value['section']['p']['index']);?>
"><?php echo smarty_modifier_myescape($_smarty_tpl->getVariable('smarty')->value['section']['p']['index']);?>
</a>&nbsp; <?php }?> <?php endfor; endif; ?> <?php if ($_smarty_tpl->tpl_vars['frm']->value['page'] < $_smarty_tpl->tpl_vars['colpages']->value) {?><a href="?a=news&page=<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['frm']->value['page']+1);?>
">&gt;&gt;</a>&nbsp;<?php }?> <?php }?> </center> <br> <?php }?> <?php echo $_smarty_tpl->getSubTemplate ("my:start_info_table", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>
 Here you can manage your program news.<br> Your newly added news will appear on your site index page (if you have enabled 'Show news box in InfoBox Settings section')<br> Small text will appear on Index page. If you omit Small Text then the system will show first 100-120 characters of your Full Text.<br> If you omit Full Text than the system will show Small Text on all the news page. <?php echo $_smarty_tpl->getSubTemplate ("my:end_info_table", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>
 <br><br><a name="editform"></a> <form method=post> <input type=hidden name=a value=news> <?php if ($_smarty_tpl->tpl_vars['edit_news']->value) {?> <input type=hidden name=action value=edit> <input type=hidden name=save value=1> <input type=hidden name=id value=<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['edit_news']->value['id']);?>
> <?php } else { ?> <input type=hidden name=action value=add> <?php }?> <input type=hidden name=page value=<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['frm']->value['page']);?>
> <table cellspacing=0 cellpadding=2 border=0> <tr> <td nowrap width=1<?php echo '%>';?>Select language</td> <td> <select name="lang" class=inpts> <?php
$_from = $_smarty_tpl->tpl_vars['languages']->value;
if (!is_array($_from) && !is_object($_from)) {
settype($_from, 'array');
}
$_smarty_tpl->tpl_vars['l'] = new Smarty_Variable;
$_smarty_tpl->tpl_vars['l']->_loop = false;
foreach ($_from as $_smarty_tpl->tpl_vars['l']->value) {
$_smarty_tpl->tpl_vars['l']->_loop = true;
$foreach_l_Sav = $_smarty_tpl->tpl_vars['l'];
?> <option value="<?php echo smarty_modifier_myescape(htmlspecialchars($_smarty_tpl->tpl_vars['l']->value, ENT_QUOTES, 'UTF-8', true));?>
" <?php if ($_smarty_tpl->tpl_vars['l']->value == $_smarty_tpl->tpl_vars['edit_news']->value['lang']) {?>selected<?php }?>><?php echo smarty_modifier_myescape(htmlspecialchars($_smarty_tpl->tpl_vars['l']->value, ENT_QUOTES, 'UTF-8', true));?>
</option> <?php
$_smarty_tpl->tpl_vars['l'] = $foreach_l_Sav;
}
?> </select> </td> </tr> <tr> <td colspan=2>Title</td> </tr> <tr> <td colspan=2> <input type="text" name="title" value="<?php echo smarty_modifier_myescape(htmlspecialchars($_smarty_tpl->tpl_vars['edit_news']->value['title'], ENT_QUOTES, 'UTF-8', true));?>
" class=inpts size=100> </td> </tr> <?php if ($_smarty_tpl->tpl_vars['edit_news']->value) {?> <tr> <td colspan=2>Date</td> </tr> <tr> <td colspan=2> <input type="text" name="date" value="<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['edit_news']->value['date']);?>
" class=inpts size=100> </td> </tr> <?php }?> <tr> <td colspan=2>Small Text</td> </tr> <tr> <td colspan=2> <textarea name=small_text class=inpts cols=100 rows=3><?php echo smarty_modifier_myescape(htmlspecialchars($_smarty_tpl->tpl_vars['edit_news']->value['small_text'], ENT_QUOTES, 'UTF-8', true));?>
</textarea> </td> </tr> <tr> <td colspan=2>Full Text</td> </tr> <tr> <td colspan=2> <textarea name=full_text class=inpts cols=100 rows=5><?php echo smarty_modifier_myescape(htmlspecialchars($_smarty_tpl->tpl_vars['edit_news']->value['full_text'], ENT_QUOTES, 'UTF-8', true));?>
</textarea> </td> </tr> <tr> <td colspan=2><input type=submit value="<?php if ($_smarty_tpl->tpl_vars['edit_news']->value) {?>Edit<?php } else { ?>Add<?php }?>" class=sbmt></td> </tr></table> </form> <?php }
}
?>