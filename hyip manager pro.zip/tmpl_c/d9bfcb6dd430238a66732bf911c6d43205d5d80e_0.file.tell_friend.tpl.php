<?php /* Smarty version 3.1.27, created on 2017-06-16 08:00:32
         compiled from "/home/cryptoorbit/public_html/tmpl/tell_friend.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:361462088594390208622f7_00534389%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'd9bfcb6dd430238a66732bf911c6d43205d5d80e' => 
    array (
      0 => '/home/cryptoorbit/public_html/tmpl/tell_friend.tpl',
      1 => 1442782298,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '361462088594390208622f7_00534389',
  'variables' => 
  array (
    'say' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_59439020a8c6c7_57999727',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_59439020a8c6c7_57999727')) {
function content_59439020a8c6c7_57999727 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '361462088594390208622f7_00534389';
echo $_smarty_tpl->getSubTemplate ("header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>



<h3>Tell friend:</h3><br><br>

<?php if ($_smarty_tpl->tpl_vars['say']->value == 'invite_sent') {?>
Your invite/invites has been successfully sent.<br><br>
<?php }?>

<form action="index.php" method=post >
<input type=hidden name=a value=tell_friend>
<input type=hidden name=action value=tell_friend>
<table cellspacing=0 cellpadding=2 border=0>
<tr>
 <td>Name 1:</td>
 <td><input type=text name=name1 class=inpts></td>
 <td>Email 1:</td>
 <td><input type=text name=email1 class=inpts></td>
</tr>
<tr>
 <td>Name 2:</td>
 <td><input type=text name=name2 class=inpts></td>
 <td>Email 2:</td>
 <td><input type=text name=email2 class=inpts></td>
</tr>
<tr>
 <td>Name 3:</td>
 <td><input type=text name=name3 class=inpts></td>
 <td>Email 3:</td>
 <td><input type=text name=email3 class=inpts></td>
</tr>
<tr>
 <td colspan=4 align=center><input type=submit value="Send" class=sbmt></td>
</tr>
</table>
</form>

<?php echo $_smarty_tpl->getSubTemplate ("footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>


<?php }
}
?>