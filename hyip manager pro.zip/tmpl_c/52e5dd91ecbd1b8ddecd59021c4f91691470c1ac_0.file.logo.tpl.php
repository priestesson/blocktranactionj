<?php /* Smarty version 3.1.27, created on 2017-11-22 03:20:27
         compiled from "/home/dsenemfi/public_html/tmpl/logo.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:20503699335a15334beac299_06060189%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '52e5dd91ecbd1b8ddecd59021c4f91691470c1ac' => 
    array (
      0 => '/home/dsenemfi/public_html/tmpl/logo.tpl',
      1 => 1497963376,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '20503699335a15334beac299_06060189',
  'variables' => 
  array (
    'settings' => 0,
    'userinfo' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_5a15334becf9f7_05265010',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5a15334becf9f7_05265010')) {
function content_5a15334becf9f7_05265010 ($_smarty_tpl) {
if (!is_callable('smarty_modifier_myescape')) require_once '/home/dsenemfi/public_html/inc/libs/smarty3/plugins/modifier.myescape.php';

$_smarty_tpl->properties['nocache_hash'] = '20503699335a15334beac299_06060189';
?>
<!DOCTYPE html>
<html>
	<head>
		<title><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
  - Your Profitable Operator</title>
		<meta name="viewport" content="width=1024">
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<link rel="shortcut icon" href="img/favicon.png" type="image/x-icon">
		<link href="https://fonts.googleapis.com/css?family=Roboto:400,700,400italic,700italic&subset=latin,cyrillic" rel="stylesheet" type="text/css">
		<link rel="stylesheet" href="css/style.css"/>
		<?php echo '<script'; ?>
 src="https://code.jquery.com/jquery-latest.min.js"><?php echo '</script'; ?>
>
		<?php echo '<script'; ?>
 type="text/javascript" src="js/jquery.flexslider-min.js"><?php echo '</script'; ?>
>
		<?php echo '<script'; ?>
 type="text/javascript" src="js/jquery.animateSprite.min.js"><?php echo '</script'; ?>
>
		<?php echo '<script'; ?>
 type="text/javascript" src="js/jquery.parallaxify.min.js"><?php echo '</script'; ?>
>
		<?php echo '<script'; ?>
 type="text/javascript" src="js/jquery.arcticmodal-0.3.min.js"><?php echo '</script'; ?>
>
		<?php echo '<script'; ?>
 type="text/javascript" src="js/calculator.js"><?php echo '</script'; ?>
>
		<?php echo '<script'; ?>
 type="text/javascript" src="js/functions.js"><?php echo '</script'; ?>
>
		
		
		
	</head>
	<body>
		<header class="header">
			<div class="h_top">
				<div class="container clearfix">
					<ul class="h_social">
						<li><a href="https://www.facebook.com/" class="fb" target="_blank">Facebook</a></li>
						<li><a href="https://twitter.com/" class="tw" target="_blank">Twitter</a></li>
						<li><a href="https://plus.google.com/" class="gp" target="_blank">Google +</a></li>
						<li><a href="https://vk.com/" class="vk" target="_blank">VKontakte</a></li>
					</ul>
					<ul class="h_contacts">
						<li><span class="phone"></span>+441138680VIP (9:00 AM - 9:00 PM)</li>  
						<li><span class="email"></span>admin@<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
 </li>
					</ul>
				<?php if ($_smarty_tpl->tpl_vars['userinfo']->value['logged'] != 1) {?>	<ul class="h_auth">
												<li><a href="?a=signup" class="register"><span></span>Register</a></li>
						<li>or</li>
						<li><span class="login login_link"><span></span>Login</span></li>
											</ul>   <?php } else { ?> <ul class="h_auth">
												<li><a href="?a=account" class="register"><span></span>Your Account</a></li>
						<li>or</li>
						<li><a href="?a=logout" class="logout"><span></span>Logout</a></li>
											</ul><?php }?>
					<ul class="h_lang">
						<li>Language:</li>
						<li>
							<div class="flag_cont">
								<div class="flag en"></div> <!-- en, ru, de, it, vi, fr, po, ch, ja, to, uk -->
								<div class="sub_lang">
									<ul>
										<li class="en active"><a href="?language=default">English</a></li>
										<li class="ru"><a href="?language=ru">Русский</a></li>
										<li class="de"><span>Deutsch</span></li>
										<li class="it"><span>Italiano</span></li>
										<li class="vi"><span>Tiếng Việt</span></li>
										<li class="fr"><span>Français</span></li>
										<li class="po"><span>Português</span></li>
										<li class="ch"><span>中文</span></li>
										<li class="ja"><span>日本</span></li>
										<li class="to"><span>Türkçe</span></li>
										<li class="uk"><span>Українська</span></li> 
									</ul>  
								</div>
							</div>
						</li>
					</ul> 
				</div>
			</div>
			<div class="h_middle">
				<div class="container clearfix">
					<div class="logo">
						<a href="?a=home"><span></span><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
 </a>
					</div>
					<div class="live_chat">
			
					 <a href="?a=support"><img src="img/online.gif"></a>
					</div>
					<nav class="main_menu">
						<ul class="clearfix">
							<li><a href="?a=home">Home Page</a></li>
							<li class="parent">
								<a href="?a=cust&page=about_us">About Us</a>
								<div class="sub_menu">
									<ul>
										<li><a href="?a=cust&page=about_us">About Company</a></li>
										<!-- <li><a href="?a=cust&page=our_team">Our Team</a></li> -->
										<!-- <li><a href="?a=cust&page=our_platform">Our Platform</a></li> -->
										<li><a href="?a=cust&page=our_benefits">Our Benefits</a></li>
										<!---<li><a href="?a=cust&page=our_representatives">Our Representatives</a></li>-----> 
										<li><a href="?a=cust&page=get_started">Get Started Guide</a></li>
										<li><a href="?a=cust&page=our_deposit_methods">Our Deposit Methods</a></li>
										<li><a href="?a=cust&page=popular_exchangers">Popular Exchangers</a></li>
										<li><a href="?a=news">Our News</a></li>
										<!--<li><a href="?a=cust&page=video">Our Video</a></li>-->
										<li><a href="?a=cust&page=privacy_policy">Privacy Policy</a></li>
										<li><a href="?a=cust&page=antispam_policy">Anti-Spam Policy</a></li>
										<li><a href="?a=cust&page=security">Security</a></li>
										<li><a href="?a=cust&page=banners">Our Banners</a></li>
									</ul>
								</div>
							</li>
							<li><a href="?a=faq">FAQ</a></li>
							<li><a href="?a=rules">Terms</a></li>
							<li><a href="?a=rateus">Rate Us</a></li>
							<li><a href="?a=support">Contact Us</a></li>
						</ul>
					</nav>
				</div>
			</div><?php }
}
?>