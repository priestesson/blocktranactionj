<?php /* Smarty version 3.1.27, created on 2017-06-20 14:58:02
         compiled from "/home/cryptoorbit/public_html/tmpl/login_redirect.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:994725068594937fac99699_07623037%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'b37e7d3dd04b94dfd14e070d913560734c613ca0' => 
    array (
      0 => '/home/cryptoorbit/public_html/tmpl/login_redirect.tpl',
      1 => 1496463032,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '994725068594937fac99699_07623037',
  'variables' => 
  array (
    'settings' => 0,
    'userinfo' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_594937fad2c1f7_11573262',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_594937fad2c1f7_11573262')) {
function content_594937fad2c1f7_11573262 ($_smarty_tpl) {
if (!is_callable('smarty_modifier_myescape')) require_once '/home/cryptoorbit/public_html/inc/libs/smarty3/plugins/modifier.myescape.php';

$_smarty_tpl->properties['nocache_hash'] = '994725068594937fac99699_07623037';
?>
<!DOCTYPE html>
<html>
	<head>
		<title></title>
		<meta name="viewport" content="width=1024">
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<meta http-equiv="Refresh" content="2; url=?a=account">
		<link rel="shortcut icon" href="img/favicon.png" type="image/x-icon">
		<link href="https://fonts.googleapis.com/css?family=Roboto:400,700,400italic,700italic&subset=latin,cyrillic" rel="stylesheet" type="text/css">
		<link rel="stylesheet" href="css/style.css"/>
	</head>
	<body>
		<section class="redirect_page">
			<div class="container">
				<div class="rp_logo"><a href="?a=account"><span></span><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
</a></div>
				<div class="rp_info dark_bg">
					<h2>Hello <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['userinfo']->value['username']);?>
!</h2>
					<div class="separator_2"><span></span></div>
					<div class="rp_text">
						<p>You are redirecting to your account now.</p>
					</div>
				</div>
				<a href="?a=account" class="custom_link big green">Go to your account</a>
			</div>
		</section>
	<body>
</html><?php }
}
?>