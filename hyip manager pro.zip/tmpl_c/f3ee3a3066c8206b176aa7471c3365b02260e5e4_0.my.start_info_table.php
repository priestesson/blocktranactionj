<?php /* Smarty version 3.1.27, created on 2017-11-22 03:20:34
         compiled from "my:start_info_table" */ ?>
<?php
/*%%SmartyHeaderCode:12841245135a153352416da6_93269672%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'f3ee3a3066c8206b176aa7471c3365b02260e5e4' => 
    array (
      0 => 'my:start_info_table',
      1 => 1511338834,
      2 => 'my',
    ),
  ),
  'nocache_hash' => '12841245135a153352416da6_93269672',
  'variables' => 
  array (
    'size' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_5a153352423d25_32136842',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5a153352423d25_32136842')) {
function content_5a153352423d25_32136842 ($_smarty_tpl) {
if (!is_callable('smarty_modifier_myescape')) require_once '/home/dsenemfi/public_html/inc/libs/smarty3/plugins/modifier.myescape.php';

$_smarty_tpl->properties['nocache_hash'] = '12841245135a153352416da6_93269672';
?>
 <table cellspacing=0 cellpadding=1 border=0 width=<?php echo smarty_modifier_myescape((($tmp = @$_smarty_tpl->tpl_vars['size']->value)===null||$tmp==='' ? "100%" : $tmp));?>
 bgcolor=#FF8D00> <tr><td bgcolor=#FF8D00> <table cellspacing=0 cellpadding=0 border=0 width=100<?php echo '%>';?> <tr> <td valign=top width=10 bgcolor=#FFFFF2><img src=images/sign.gif></td> <td valign=top bgcolor=#FFFFF2 style="padding: 10px; color: #D20202; font-family: verdana; font-size: 11px;"> <?php }
}
?>