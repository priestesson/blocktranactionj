<?php /* Smarty version 3.1.27, created on 2017-06-19 10:26:14
         compiled from "/home/cryptoorbit/public_html/tmpl/custom/antispam_policy.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:9322256245947a6c63d51b7_05281434%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '2297cfbc71805441470514573a13d9e84d87e2ac' => 
    array (
      0 => '/home/cryptoorbit/public_html/tmpl/custom/antispam_policy.tpl',
      1 => 1496463032,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '9322256245947a6c63d51b7_05281434',
  'variables' => 
  array (
    'settings' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_5947a6c64c8ad6_65587054',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5947a6c64c8ad6_65587054')) {
function content_5947a6c64c8ad6_65587054 ($_smarty_tpl) {
if (!is_callable('smarty_modifier_myescape')) require_once '/home/cryptoorbit/public_html/inc/libs/smarty3/plugins/modifier.myescape.php';

$_smarty_tpl->properties['nocache_hash'] = '9322256245947a6c63d51b7_05281434';
echo $_smarty_tpl->getSubTemplate ("header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);
?>


<h1>Anti-Spam Policy</h1>
<div class="separator_2"><span></span></div>

<div class="rules_page">
	<p class="all_p green_bg">
<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
 - Your Profitable Operator is trying to provide excellent services for its clients worldwide. 
That's why we offer you our Anti-Spam Policy to ascertain that we vigorously oppose the sending of spam. Spam is unsolicited email sent in bulk. It is a major irritant to internet service providers and internet users alike. 
The sending of spam is also unlawful in many jurisdictions. All investors must abide by our strict anti-spam rules that prohibit spamming in any of its forms. Spam violators will be immediately and permanently removed from the program. If you see that our material is being involved in spamming activities, please notify us immediately!



	</p>
	<h2>The definition of spam</h2>
	<div class="separator_1"><span></span></div>
	
	<p class="all_p">
The word "Spam" as applied to Email means "Unsolicited Bulk Email". Email spam is any email that meets the following three criteria:
	</p>
	<ul class="check_list">
		<li>Anonymity (The address and identity of the sender are concealed)</li>
		<li>Mass Mailing (The email is sent to large groups of people)</li>
		<li>Unsolicited (The email is not requested by the recipients)</li>
	</ul>
	
	<p class="all_p">
There are a number of other less formal characteristics that you will typically find present in spam emails. There is usually no way for a recipient to opt-out of future email sends. Email spam is any email that was not requested by a user but was sent to that user and many others, typically (but not always) with malicious intent.
	</p>
	
	<div class="separator_3"><span></span></div>
	
	<h3>What does our anti-spam policy include ?</h3>
	<p class="all_p">
	
	<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
 - Your Profitable Operator does not participate or endorse any type of spamming activities. Our company reserves the right to determine in their sole discretion what constitutes actionable spam, and what measures are necessary in response to such spam activities. All investors must abide by our strict anti-spam rules that prohibit spamming in any of its forms. It is also stipulated that investors can only make posts about <?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
 - Your Profitable Operator on the websites, forums or in chat rooms where such posting is allowed. In any other case such posting will be considered as spam and spam violators will be immediately and permanently removed from the program.
We will not tolerate spam or any type of unsolicited email in this program.
	</p>
	<div class="separator_3"><span></span></div>
	
	<h3>Asume measures</h3>
	
	<p class="all_p">
	Our company does not promote this website with the help of spam. In case if you received such an e-mail, be sure we have nothing to do with it! No third parties are involved into our business affairs.
	</p>
	
	<div class="separator_3"><span></span></div>
	<h3>We never send spam</h3>
	
		<p class="all_p green_bg">
	Please inform our Customer Service about spamming! Make sure that you didn't forget to mention a full spam e-mail header and a copy of the spam e-mail.
	
	</p>
	
	
	
	<!--
	
	
	
	<p class="all_p green_bg">
		Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
	</p>
	<h3>Title - h3</h3>
	<p class="all_p light_bg">
		Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
	</p>
	<h4>Title - h4</h4>
	<p class="all_p dark_bg">
		Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
	</p>
	<p class="all_p f_letter">
		Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
	</p>
	<a href="#" class="custom_link small green">Green small button</a>
	<a href="#" class="custom_link big green">Green big button</a>
	<a href="#" class="custom_link small red">Red small button</a>
	<a href="#" class="custom_link big red">Red big button</a>
	<div class="separator_3"><span></span></div>
	<ul class="check_list">
		<li>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</li>
		<li>Sed ut perspiciatis unde omnis iste natus error sit.</li>
		<li>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</li>
		<li>Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem.</li>
		<li>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li>
	</ul>
	<div class="separator_3"><span></span></div>
	<p class="all_p">
		Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
	</p>
	
	-->
	
</div>

			<?php echo $_smarty_tpl->getSubTemplate ("footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0);

}
}
?>