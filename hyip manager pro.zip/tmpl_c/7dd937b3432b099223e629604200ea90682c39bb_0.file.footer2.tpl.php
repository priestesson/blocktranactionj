<?php /* Smarty version 3.1.27, created on 2017-11-22 03:20:27
         compiled from "/home/dsenemfi/public_html/tmpl/footer2.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:5041503565a15334bee85b2_40367014%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '7dd937b3432b099223e629604200ea90682c39bb' => 
    array (
      0 => '/home/dsenemfi/public_html/tmpl/footer2.tpl',
      1 => 1497950409,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '5041503565a15334bee85b2_40367014',
  'variables' => 
  array (
    'userinfo' => 0,
    'settings' => 0,
  ),
  'has_nocache_code' => false,
  'version' => '3.1.27',
  'unifunc' => 'content_5a15334bf1ddd6_93949707',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_5a15334bf1ddd6_93949707')) {
function content_5a15334bf1ddd6_93949707 ($_smarty_tpl) {
if (!is_callable('smarty_modifier_myescape')) require_once '/home/dsenemfi/public_html/inc/libs/smarty3/plugins/modifier.myescape.php';

$_smarty_tpl->properties['nocache_hash'] = '5041503565a15334bee85b2_40367014';
?>
<footer class="footer">
			<div class="f_top">
				<div class="container">
					<div class="partners">
						<a href="https://perfectmoney.is/" class="pm first" target="_blank">Perfect Money</a>
						<a href="https://payeer.com/" class="pe" target="_blank">Payeer</a>
						<a href="https://blockchain.info/" class="bc" target="_blank">Bitcoin</a>
						<a href="https://advcash.com/" class="ac" target="_blank">Advcash</a>
						<a href="https://www.nixmoney.com/" class="nm" target="_blank">Nix Money</a>
					</div>
					<h1>Why Choose Us?</h1>
					<div class="separator_2"><span></span></div>
					<div class="wca clearfix">
						<div class="features">
							<ul>
								<li>Genuine Investment Platform</li>
								<li>Strong DDoS protection</li>
								<li>Comodo Green EV-SSL encryption</li>
								<li>Real Registered Company</li>
								<li>Domain Registered for 5 Years</li>
								<li>Professional Management Team</li>
							</ul>
						</div>
						<div class="certificate">
							<div class="text">Company <span>№10233985</span><br>To download certificate<br><a href="crypto.pdf" target="_blank">click here</a></div>
						</div>
						<div class="green_bar">
							<div class="text">We use EV SSL encryption with green<br>address bar that confirms that the presented<br>content is the genuine and legitimate.</div>
						</div>
					</div>
									</div>
			</div>
			<div class="f_middle">
				<div class="container clearfix">
					<nav class="f_menu">
						<ul class="clearfix">
							<li><a href="?a=home">Home Page</a></li>
							<?php if ($_smarty_tpl->tpl_vars['userinfo']->value['logged'] != 1) {?>
														<li><a href="?a=signup">Register</a></li>
							<li><a href="?a=login">Login</a></li> <?php } else { ?>
				
							<li><a href="?a=account">Account</a></li> 
							
							<?php }?>
														<li><a href="?a=cust&page=about_us">About Us</a></li>
							<li><a href="?a=faq">FAQ</a></li>
							<li><a href="?a=rules">Terms</a></li>
							<li><a href="?a=news">Our News</a></li>
							<li><a href="?a=rateus">Rate Us</a></li>
														<li><a href="?a=cust&page=banners">Banners</a></li>
														<li><a href="?a=support">Contact Us</a></li>
						</ul>
					</nav>
					<ul class="f_social">
						<li>Follow Us:</li>
						<li><a href="https://www.facebook.com/" class="fb" target="_blank">Facebook</a></li>
						<li><a href="https://twitter.com/" class="tw" target="_blank">Twitter</a></li>
						<li><a href="https://Telegram.com/" class="gp" target="_blank">Telegram</a></li>
						<li><a href="https://plus.google.com/" class="vk" target="_blank">Google +</a></li>
					</ul>
				</div>
			</div>
			<div class="f_bottom">
				<div class="container clearfix">
					<div class="copyright">Copyright &copy 2017 <a href="?a=home"><?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['settings']->value['site_name']);?>
 </a> - Your Profitable Operator. All Rights Reserved. <a href="" target="_blank"></a></div>
					<ul class="sec_links">
						<li><a href="?a=cust&page=privacy_policy">Privacy Policy</a></li>
						<li><a href="?a=cust&page=antispam_policy">Anti-Spam Policy</a></li>
						<li><a href="?a=cust&page=security">Security</a></li>
					</ul>
				</div>
			</div>
		</footer>
		<div class="hidden">
			<div id="calc_modal" class="all_modal calc_modal">
				<div class="title">
					Calculator
					<div class="icon"></div>
					<span class="arcticmodal-close"></span>
				</div>
				<div class="modal_cont">
					<ul>
						<li>
							<div class="input_block list">
								<select id="percent">
									<option value="plan_1">130% After for 60 Days</option>
									<option value="plan_2">180% After for 120 Days</option> 
									<option value="plan_3">220% After 180 Days</option>
									<option value="plan_4">260% After 240 Days</option>
									<option value="plan_5">300% After 300 Days</option>
									<option value="plan_6">VIP 365% After 365 Days</option>
									<option value="plan_7">VVIP 500% After 420 Days</option>
								</select>
							</div>
						</li>
						<li>
							<div class="input_block money">
								<input id="deposit" type="text" placeholder="Amount Deposit" value="10" onkeyup="this.value=this.value.replace(/[^\d\.]+/g,'')">
							</div>
						</li>
						<li class="clearfix">
							<div class="result roi">
								<div class="icon"></div>
								<div class="title">Total Percent</div>
								<div class="subtitle" id="roi">0.00</div>
							</div>
							<div class="result profit">
								<div class="icon"></div>
								<div class="title">Total Profit</div>
								<div class="subtitle" id="profit">0.00</div>
							</div>
						</li>
						<li class="b_calc clearfix">
							<input type="button" value="Сalculate Profit" onclick="calculator();">
														<a href="?a=signup">Register and Make Deposit!</a>
													</li>
					</ul>
				</div>
			</div>
			<div id="security_modal" class="all_modal security_modal">
				<div class="title">
					<span id="security_title"></span>
					<div class="icon"></div>
					<span class="arcticmodal-close"></span>
				</div>
				<div class="modal_cont">
					<div id="security_content"></div>
				</div>
			</div>
						<div id="login_modal" class="all_modal login_modal">
				<div class="title">
					Member Login
					<div class="icon"></div>
					<span class="arcticmodal-close"></span>
				</div>
				<div class="modal_cont">
					<form method="post" name="loginform">
						<input type="hidden" name="a" value="do_login">
						<input type="hidden" name="follow" value="">
						<ul>
							<li>
								<div class="message error hidden">Please enter your username!</div>
								<div class="input_block username">
									<input type="text" name="username" placeholder="Username">
								</div>
							</li>
							<li>
								<div class="message error hidden">Please enter your password!</div>
								<div class="input_block password">
									<input type="password" name="password" placeholder="Password">
								</div>
							</li>
													

										<?php if ($_smarty_tpl->tpl_vars['userinfo']->value['validation_enabled'] == 1) {?>			<li class="validation clearfix">
								<div class="message error hidden">Please enter validation number!</div>
								<div class="v_image" style="background: #424242 url(?a=show_validation_image&<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['userinfo']->value['session_name']);?>
=<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['userinfo']->value['session_id']);?>
&rand=<?php echo smarty_modifier_myescape($_smarty_tpl->tpl_vars['userinfo']->value['rand']);?>
) no-repeat center center;"></div>
								<input type="text" name="validation_number" placeholder="Enter validation number">
							</li> <?php }?>
														<li class="b_login clearfix">
								<input type="submit" value="Log In" class="submit">
								<a href="?a=forgot_password">Forgot Password?</a>
							</li>
						</ul>
					</form>
				</div>
			</div>
					</div>
					<!--Start of Tawk.to Script-->
<?php echo '<script'; ?>
 type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/59489d3c50fd5105d0c81dde/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
<?php echo '</script'; ?>
>
<!--End of Tawk.to Script-->
	</body>
</html><?php }
}
?>