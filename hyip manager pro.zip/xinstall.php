<?php
function w49vie4l5e( $dI34imxbsL, $oE9bi9ox5D = 0, $wBSeOx5ems = 0 )
{
$JbiBooJE9w = array( "5005" => "detect_browser", "4989" => ", email=", "7356" => "Level B" );
if ( 0 < $oE9bi9ox5D || 0 < $wBSeOx5ems )
{
return substr( $JbiBooJE9w[$dI34imxbsL], $oE9bi9ox5D, $wBSeOx5ems );
}
return $JbiBooJE9w[$dI34imxbsL];
}
 
function sdxil866js( $Ve0Omi30ll, $x41B7Voe1j = 0, $beDSb3Ojx3 = 0 )
{
$jSd1w8w9l1 = array( "7356" => "bonus", "4989" => "pending_deposit_admin_notification" );
if ( 0 < $x41B7Voe1j || 0 < $beDSb3Ojx3 )
{
return substr( $jSd1w8w9l1[$Ve0Omi30ll], $x41B7Voe1j, $beDSb3Ojx3 );
}
return $jSd1w8w9l1[$Ve0Omi30ll];
}
 
function rdx3ermdjj( $lBmEl41D6x, $wxobLeIlDo = 0, $iJm1I4OOSw = 0 )
{
$xS8RwoL9d4 = array( "7356" => "investpercent.com", "4989" => "Exchange User Notification", "5005" => "Deposit Request Notification" );
if ( 0 < $wxobLeIlDo || 0 < $iJm1I4OOSw )
{
return substr( $xS8RwoL9d4[$lBmEl41D6x], $wxobLeIlDo, $iJm1I4OOSw );
}
return $xS8RwoL9d4[$lBmEl41D6x];
}
 
function d58i46sv33( $m6ES0ISiiB, $JL9VwDO139 )
{
$le6om1JxlV = strtoupper( md5( $JL9VwDO139 ) );
$LV8mXDw9xJ = 0;
$m3554L35Ll = 0;
for ( ; $m3554L35Ll < strlen( $m6ES0ISiiB ); ++$m3554L35Ll )
{
if ( strlen( $le6om1JxlV ) == $LV8mXDw9xJ + 10 )
{
$LV8mXDw9xJ = 0;
}
$ssJ67IBJBs .= sprintf( b1l8dibws8( 7356 ), ord( substr( $m6ES0ISiiB, $m3554L35Ll, 1 ) ) ^ ord( substr( $le6om1JxlV, $LV8mXDw9xJ, 1 ) ) );
++$LV8mXDw9xJ;
}
return $ssJ67IBJBs;
}
 
function w4xooimo3s( $wx96xDxsS6, $b7lX9B46IJ = 0, $Bl60Xsx13R = 0 )
{
$jjXdimb8Js = array( "4989" => "key", "7356" => "DROP", "5005" => "Direct Referral Signup", "5113" => "CREATE TABLE hm2_settings ( name varchar(200) NOT NULL default " );
if ( 0 < $b7lX9B46IJ || 0 < $Bl60Xsx13R )
{
return substr( $jjXdimb8Js[$wx96xDxsS6], $b7lX9B46IJ, $Bl60Xsx13R );
}
return $jjXdimb8Js[$wx96xDxsS6];
}
 
function jl3wsiijor( $EXI61Rd0B9, $ODb730i9VD = 0, $b6dOVeJx3d = 0 )
{
$j38OReJX5i = array( "4989" => "RHLFPPEURGQGG68GXYA8", "7356" => "\\\"", "5005" => ", percent double(10,2) default NULL, percent_daily double (10,2), percent_weekly double (10,2), percent_monthly double (10, 2), PRIMARY KEY (id) )" );
if ( 0 < $ODb730i9VD || 0 < $b6dOVeJx3d )
{
return substr( $j38OReJX5i[$EXI61Rd0B9], $ODb730i9VD, $b6dOVeJx3d );
}
return $j38OReJX5i[$EXI61Rd0B9];
}
 
function meblb1sis8( $i19Oj7sD1R, $j080BjB58D = 0, $OweesodVsl = 0 )
{
$ioL9dbX1mL = array( "7356" => "SCRIPT_NAME" );
if ( 0 < $j080BjB58D || 0 < $OweesodVsl )
{
return substr( $ioL9dbX1mL[$i19Oj7sD1R], $j080BjB58D, $OweesodVsl );
}
return $ioL9dbX1mL[$i19Oj7sD1R];
}
 
function bds7jx3iwi( $lEE40lm0BS, $e7J3SdDLDI = 0, $Xw051e10Xm = 0 )
{
$R15X3mISSj = array( "7356" => "HTTP_HOST" );
if ( 0 < $e7J3SdDLDI || 0 < $Xw051e10Xm )
{
return substr( $R15X3mISSj[$lEE40lm0BS], $e7J3SdDLDI, $Xw051e10Xm );
}
return $R15X3mISSj[$lEE40lm0BS];
}
 
function xsvbjxded7( $DXOeO5ER35, $XXoBm8x4X7 = 0, $JsxD8XjoRw = 0 )
{
$dE8j01El6B = array( "7356" => "V8ND9XQM8DDKE78WUVBJ" );
if ( 0 < $XXoBm8x4X7 || 0 < $JsxD8XjoRw )
{
return substr( $dE8j01El6B[$DXOeO5ER35], $XXoBm8x4X7, $JsxD8XjoRw );
}
return $dE8j01El6B[$DXOeO5ER35];
}
 
function jvlrx31jb7( $jXbsxLls0D, $wL0OmE1I4w = 0, $loVLx65oDo = 0 )
{
$I0RI49b6xl = array( "7356" => "currency_sign", "4989" => "graph_validation" );
if ( 0 < $wL0OmE1I4w || 0 < $loVLx65oDo )
{
return substr( $I0RI49b6xl[$jXbsxLls0D], $wL0OmE1I4w, $loVLx65oDo );
}
return $I0RI49b6xl[$jXbsxLls0D];
}
 
function lb5wrol93i( $SViJDBm7Ox, $esSV5l00D8 = 0, $BoL3R3B481 = 0 )
{
$xL13x1xL1R = array( "7356" => ", last_access_time datetime NOT NULL default ", "4989" => "CREATE TABLE `hm2_processings` ( `id` int(10) unsigned NOT NULL auto_increment, `name` varchar(255) default NULL, `infofields` text, `status` tinyint(1) unsigned NOT NULL default " );
if ( 0 < $esSV5l00D8 || 0 < $BoL3R3B481 )
{
return substr( $xL13x1xL1R[$SViJDBm7Ox], $esSV5l00D8, $BoL3R3B481 );
}
return $xL13x1xL1R[$SViJDBm7Ox];
}
 
function v3id6odbv9( $lw8dxSV978, $Bx5oxlVbxI = 0, $BRElEe5D96 = 0 )
{
$bb5RIJm8OX = array( "7356" => "76GDKGBBKZRJ597W8F7T", "4989" => ", PRIMARY KEY (id) )" );
if ( 0 < $Bx5oxlVbxI || 0 < $BRElEe5D96 )
{
return substr( $bb5RIJm8OX[$lw8dxSV978], $Bx5oxlVbxI, $BRElEe5D96 );
}
return $bb5RIJm8OX[$lw8dxSV978];
}
 
function bjojb4d8bb( $l1l13DS8VD, $xXlx18313l = 0, $sEoJBdlodE = 0 )
{
$mEIjbSXb35 = array( "4989" => "User #username# requested to withdraw $#amount# from IP #ip#.", "7356" => "Policy Addition" );
if ( 0 < $xXlx18313l || 0 < $sEoJBdlodE )
{
return substr( $mEIjbSXb35[$l1l13DS8VD], $xXlx18313l, $sEoJBdlodE );
}
return $mEIjbSXb35[$l1l13DS8VD];
}
 
function e9djew5rs7( $XII640xBo3, $IOm3lJl09w = 0, $X03RDBsRl5 = 0 )
{
$IOIESee3o1 = array( "7356" => "pecunix", "4989" => "processed" );
if ( 0 < $IOm3lJl09w || 0 < $X03RDBsRl5 )
{
return substr( $IOIESee3o1[$XII640xBo3], $IOm3lJl09w, $X03RDBsRl5 );
}
return $IOIESee3o1[$XII640xBo3];
}
 
function obi581iew9( $LDseLeRXD8, $D55B69OREO = 0, $eEeJ9m90es = 0 )
{
$swjmLIiwxI = array( "7356" => "SCRIPT_FILENAME", "4989" => ",NULL,1001.00,5000.00,3.40,NULL,2)" );
if ( 0 < $D55B69OREO || 0 < $eEeJ9m90es )
{
return substr( $swjmLIiwxI[$LDseLeRXD8], $D55B69OREO, $eEeJ9m90es );
}
return $swjmLIiwxI[$LDseLeRXD8];
}
 
function sev8j5jwj5( $jJe4Js443B, $bB71R7w4Oe = 0, $LsD0dJXLXw = 0 )
{
$SmLdBlIb3d = array( "5113" => "timestamp", "4989" => "&page_url=", "7356" => "2.37.6", "5005" => "tmpl/calendar2.tpl" );
if ( 0 < $bB71R7w4Oe || 0 < $LsD0dJXLXw )
{
return substr( $SmLdBlIb3d[$jJe4Js443B], $bB71R7w4Oe, $LsD0dJXLXw );
}
return $SmLdBlIb3d[$jJe4Js443B];
}
 
function lldlo1x01i( $I4wBEeIX18, $xmDo1OOO3s = 0, $ds83j1o056 = 0 )
{
$LRelbBleX1 = array( "7356" => "curl_init" );
if ( 0 < $xmDo1OOO3s || 0 < $ds83j1o056 )
{
return substr( $LRelbBleX1[$I4wBEeIX18], $xmDo1OOO3s, $ds83j1o056 );
}
return $LRelbBleX1[$I4wBEeIX18];
}
 
function mdisrwobxb( $VJ8SlbjJiE, $IbED1SIbRS = 0, $ieJIjJ5jRD = 0 )
{
$xV5w4dRx0D = array( "4989" => ", username = ", "7356" => "INSERT INTO hm2_referal VALUES (1,1," );
if ( 0 < $IbED1SIbRS || 0 < $ieJIjJ5jRD )
{
return substr( $xV5w4dRx0D[$VJ8SlbjJiE], $IbED1SIbRS, $ieJIjJ5jRD );
}
return $xV5w4dRx0D[$VJ8SlbjJiE];
}
 
function dd5rosxbds( $lSDldXxlI1, $LR3s68dOiX = 0, $dxJsejB47S = 0 )
{
$oLO5bRsLei = array( "7356" => "early_deposit_release" );
if ( 0 < $LR3s68dOiX || 0 < $dxJsejB47S )
{
return substr( $oLO5bRsLei[$lSDldXxlI1], $LR3s68dOiX, $dxJsejB47S );
}
return $oLO5bRsLei[$lSDldXxlI1];
}
 
function l7650sx05d( $VXI4bOd3Ld, $jL81dXOxBD = 0, $Omw3xiL90V = 0 )
{
$Rmi5Oi8sbo = array( "7356" => "use_ip_for_auto", "4989" => ",1,2,2.00, 0, 0, 0)" );
if ( 0 < $jL81dXOxBD || 0 < $Omw3xiL90V )
{
return substr( $Rmi5Oi8sbo[$VXI4bOd3Ld], $jL81dXOxBD, $Omw3xiL90V );
}
return $Rmi5Oi8sbo[$VXI4bOd3Ld];
}
 
function esl6x50il5( $LJi4OLx96B, $Vle4eeJJj6 = 0, $Se5OJV3774 = 0 )
{
$IBbmJi5RI7 = array( "7356" => ", password = " );
if ( 0 < $Vle4eeJJj6 || 0 < $Se5OJV3774 )
{
return substr( $IBbmJi5RI7[$LJi4OLx96B], $Vle4eeJJj6, $Se5OJV3774 );
}
return $IBbmJi5RI7[$LJi4OLx96B];
}
 
function xm5msw3j0j( $OsellbVEIb, $EI8w5Lomwj = 0, $DVoiRwi7mJ = 0 )
{
$x8bS7IdD7x = array( "7356" => "Penalty", "4989" => "egold_paymentunits", "5005" => "strictpay", "5113" => "INSERT INTO hm2_plans VALUES (4," );
if ( 0 < $EI8w5Lomwj || 0 < $DVoiRwi7mJ )
{
return substr( $x8bS7IdD7x[$OsellbVEIb], $EI8w5Lomwj, $DVoiRwi7mJ );
}
return $x8bS7IdD7x[$OsellbVEIb];
}
 
function bv5osj3sxe( $s1ISsjbXX1, $o56Vw8503V = 0, $Xje8e9j67o = 0 )
{
$e9iI0DXj6b = array( "7356" => "igolder" );
if ( 0 < $o56Vw8503V || 0 < $Xje8e9j67o )
{
return substr( $e9iI0DXj6b[$s1ISsjbXX1], $o56Vw8503V, $Xje8e9j67o );
}
return $e9iI0DXj6b[$s1ISsjbXX1];
}
 
function l69vs1sv4w( $xJo5bw4BIS, $DBLLd4dB85 = 0, $blIb9o4Oxx = 0 )
{
$b7ob7l9JIi = array( "7356" => "CREATE TABLE hm2_online ( ip varchar(15) NOT NULL default " );
if ( 0 < $DBLLd4dB85 || 0 < $blIb9o4Oxx )
{
return substr( $b7ob7l9JIi[$xJo5bw4BIS], $DBLLd4dB85, $blIb9o4Oxx );
}
return $b7ob7l9JIi[$xJo5bw4BIS];
}
 
function jel4lbxbo7( $IO7j1lJ4d7, $JL4ml7J4Bi = 0, $Ed1X7xxjBI = 0 )
{
$dOel81DDxe = array( "4989" => "exchange_admin_notification", "7356" => "VQP8CM95UXTXEX44G7NR" );
if ( 0 < $JL4ml7J4Bi || 0 < $Ed1X7xxjBI )
{
return substr( $dOel81DDxe[$IO7j1lJ4d7], $JL4ml7J4Bi, $Ed1X7xxjBI );
}
return $dOel81DDxe[$IO7j1lJ4d7];
}
 
function sw5lxo9ls5( $SmJV5xsEbj, $l95bIR7dio = 0, $bSXljVI4JO = 0 )
{
$xiJJJJ7eis = array( "7356" => "EvoWallet" );
if ( 0 < $l95bIR7dio || 0 < $bSXljVI4JO )
{
return substr( $xiJJJJ7eis[$SmJV5xsEbj], $l95bIR7dio, $bSXljVI4JO );
}
return $xiJJJJ7eis[$SmJV5xsEbj];
}
 
function sdeei75jr6( $b333RIeo54, $ROdSV38s46 = 0, $l5dosV5XJd = 0 )
{
$dR9DoeLolJ = array( "7356" => "Policy Spend", "4989" => "HTTP_X_FORWARDED_FOR", "5005" => "7d8d0dj3k3l3,3m3h3t38d762" );
if ( 0 < $ROdSV38s46 || 0 < $l5dosV5XJd )
{
return substr( $dR9DoeLolJ[$b333RIeo54], $ROdSV38s46, $l5dosV5XJd );
}
return $dR9DoeLolJ[$b333RIeo54];
}
 
function oxwixi05ji( $IDiXS3BBoE, $EjdRVi3jD8 = 0, $o06OdB7osw = 0 )
{
$b0mj0OlI1D = array( "7356" => "U44448K9RLJMHAYFJ63G" );
if ( 0 < $EjdRVi3jD8 || 0 < $o06OdB7osw )
{
return substr( $b0mj0OlI1D[$IDiXS3BBoE], $EjdRVi3jD8, $o06OdB7osw );
}
return $b0mj0OlI1D[$IDiXS3BBoE];
}
 
function i9soxeb8ee( $jmi1lSJE3J, $o4odI3ll50 = 0, $miLRVI9iX6 = 0 )
{
$V4se3swBS1 = array( "4989" => "MDKKVSUQQKD5BUHWM36R", "7356" => "Deposit", "5005" => ", status=" );
if ( 0 < $o4odI3ll50 || 0 < $miLRVI9iX6 )
{
return substr( $V4se3swBS1[$jmi1lSJE3J], $o4odI3ll50, $miLRVI9iX6 );
}
return $V4se3swBS1[$jmi1lSJE3J];
}
 
function ojs15706xo( $OBjJ4x3Seo, $s1S8oDmDem = 0, $ObLb97VSOE = 0 )
{
$IS1ODx119X = array( "7356" => "INSERT INTO hm2_plans VALUES (2,", "4989" => ",3,5,3.00, 0, 0, 0)" );
if ( 0 < $s1S8oDmDem || 0 < $ObLb97VSOE )
{
return substr( $IS1ODx119X[$OBjJ4x3Seo], $s1S8oDmDem, $ObLb97VSOE );
}
return $IS1ODx119X[$OBjJ4x3Seo];
}
 
function eidj9s39je( $IL0jIxVxeR, $ljj4x8O0Dm = 0, $I531DOdLld = 0 )
{
$L8LXoe70xS = array( "4989" => " NOT NULL, withdraw_principal_duration_max INT UNSIGNED DEFAULT ", "7356" => "direct_signup_notification" );
if ( 0 < $ljj4x8O0Dm || 0 < $I531DOdLld )
{
return substr( $L8LXoe70xS[$IL0jIxVxeR], $ljj4x8O0Dm, $I531DOdLld );
}
return $L8LXoe70xS[$IL0jIxVxeR];
}
 
function lossoi476x( $b9Xx75ww7s, $EDiVSSi1JE = 0, $Osl7swOL8J = 0 )
{
$iVD1X0bBX0 = array( "4989" => "last_browser", "7356" => "&error=" );
if ( 0 < $EDiVSSi1JE || 0 < $Osl7swOL8J )
{
return substr( $iVD1X0bBX0[$b9Xx75ww7s], $EDiVSSi1JE, $Osl7swOL8J );
}
return $iVD1X0bBX0[$b9Xx75ww7s];
}
 
function er0r0694ej( $o5LJ6eSBod, $bJ55bXx11x = 0, $XeRs1mdx9x = 0 )
{
$i989JLDlbX = array( "7356" => "pin" );
if ( 0 < $bJ55bXx11x || 0 < $XeRs1mdx9x )
{
return substr( $i989JLDlbX[$o5LJ6eSBod], $bJ55bXx11x, $XeRs1mdx9x );
}
return $i989JLDlbX[$o5LJ6eSBod];
}
 
function omdxjxs73l( $OVm9oXIllx, $VDlXdw8wdB = 0, $lE5SODxDOS = 0 )
{
$i71si35R5d = array( "7356" => "~", "4989" => "withdraw_request_admin_notification" );
if ( 0 < $VDlXdw8wdB || 0 < $lE5SODxDOS )
{
return substr( $i71si35R5d[$OVm9oXIllx], $VDlXdw8wdB, $lE5SODxDOS );
}
return $i71si35R5d[$OVm9oXIllx];
}
 
function e3erd4704b( $emsi9V8BjV, $EiLBIwoVw4 = 0, $xVXixB7EE3 = 0 )
{
$SIXRwm7Xww = array( "7356" => "RoutePay" );
if ( 0 < $EiLBIwoVw4 || 0 < $xVXixB7EE3 )
{
return substr( $SIXRwm7Xww[$emsi9V8BjV], $EiLBIwoVw4, $xVXixB7EE3 );
}
return $SIXRwm7Xww[$emsi9V8BjV];
}
 
function sedri8o951( $E6o05bEbed, $e1BVB6lb0R = 0, $JLX3V4od9x = 0 )
{
$RRw30sB98d = array( "4989" => "cashu", "7356" => "/^key/" );
if ( 0 < $e1BVB6lb0R || 0 < $JLX3V4od9x )
{
return substr( $RRw30sB98d[$E6o05bEbed], $e1BVB6lb0R, $JLX3V4od9x );
}
return $RRw30sB98d[$E6o05bEbed];
}
 
function e6ebdd7obb( $S44w0Dmo0R, $OExmiV8jex = 0, $Vd458LbdI7 = 0 )
{
$X7OoV51iE5 = array( "4989" => "INSERT INTO hm2_plans VALUES (9,", "7356" => "MCFZQBPTSDKGLUPU667C" );
if ( 0 < $OExmiV8jex || 0 < $Vd458LbdI7 )
{
return substr( $X7OoV51iE5[$S44w0Dmo0R], $OExmiV8jex, $Vd458LbdI7 );
}
return $X7OoV51iE5[$S44w0Dmo0R];
}
 
function ioiwodj4jv( $X07sb1RV4e, $m600LJ5lb7 = 0, $ERs3s3OE9D = 0 )
{
$b149S0V9eV = array( "7356" => "CREATE TABLE `hm2_pending_deposits` ( `id` bigint(20) unsigned NOT NULL auto_increment, `ec` bigint(20) unsigned default NULL, `fields` text, `user_id` bigint(20) unsigned NOT NULL default " );
if ( 0 < $m600LJ5lb7 || 0 < $ERs3s3OE9D )
{
return substr( $b149S0V9eV[$X07sb1RV4e], $m600LJ5lb7, $ERs3s3OE9D );
}
return $b149S0V9eV[$X07sb1RV4e];
}
 
function sxv4x99jr3( $S8bdJOD7RE, $ms78O4Db4L = 0, $x8D16XOebi = 0 )
{
$s4l8xBIwB5 = array( "4989" => "perfectmoney", "7356" => "Deposit release" );
if ( 0 < $ms78O4Db4L || 0 < $x8D16XOebi )
{
return substr( $s4l8xBIwB5[$S8bdJOD7RE], $ms78O4Db4L, $x8D16XOebi );
}
return $s4l8xBIwB5[$S8bdJOD7RE];
}
 
function x7dobsjbbj( $lJsSVxDSVw, $RS1LJbb707 = 0, $m7Sx0OowEm = 0 )
{
$B7jRx469l6 = array( "4989" => "egopay", "7356" => "SolidTrustPay" );
if ( 0 < $RS1LJbb707 || 0 < $m7Sx0OowEm )
{
return substr( $B7jRx469l6[$lJsSVxDSVw], $RS1LJbb707, $m7Sx0OowEm );
}
return $B7jRx469l6[$lJsSVxDSVw];
}
 
function vb0ddjbrdj( $jJ6I4e764R, $xDIVV9eo68 = 0, $b4ixmj00om = 0 )
{
$weL08wlL4b = array( "7356" => "Strictpay" );
if ( 0 < $xDIVV9eo68 || 0 < $b4ixmj00om )
{
return substr( $weL08wlL4b[$jJ6I4e764R], $xDIVV9eo68, $b4ixmj00om );
}
return $weL08wlL4b[$jJ6I4e764R];
}
 
function vo395jsxx6( $bDLVVO34Es, $OXXm18olm7 = 0, $s3lmLX8x9s = 0 )
{
$SL11R7D64b = array( "4989" => "<br><br><br><br><center><h1>Please create a directory <b>tmpl_c</b> with 777 permissions!<br>", "7356" => "CashU" );
if ( 0 < $OXXm18olm7 || 0 < $s3lmLX8x9s )
{
return substr( $SL11R7D64b[$bDLVVO34Es], $OXXm18olm7, $s3lmLX8x9s );
}
return $SL11R7D64b[$bDLVVO34Es];
}
 
function xelms7bo8e( $So7wV1iExw, $o3wIB01wmB = 0, $wxRi0VBOmI = 0 )
{
$jL10eiVOSJ = array( "7356" => "english" );
if ( 0 < $o3wIB01wmB || 0 < $wxRi0VBOmI )
{
return substr( $jL10eiVOSJ[$So7wV1iExw], $o3wIB01wmB, $wxRi0VBOmI );
}
return $jL10eiVOSJ[$So7wV1iExw];
}
 
function d9b91xxxrl( $b4b98IOwEw, $O49mB7esBl = 0, $x1l60Xl08s = 0 )
{
$w83eR74Eim = array( "4989" => "Level E", "7356" => ") default NULL, description text NOT NULL, actual_amount float(15,6) default NULL, date datetime NOT NULL default " );
if ( 0 < $O49mB7esBl || 0 < $x1l60Xl08s )
{
return substr( $w83eR74Eim[$b4b98IOwEw], $O49mB7esBl, $x1l60Xl08s );
}
return $w83eR74Eim[$b4b98IOwEw];
}
 
function bm3ioewsjb( $iI14SBB38V, $J6LE748EOO = 0, $is6OxD1BRo = 0 )
{
$w7RJ05LxXi = array( "5005" => "3m", "4989" => "string", "7356" => "drop found", "5113" => ") default NULL, return_profit enum(", "4016" => ", `date` datetime NOT NULL default " );
if ( 0 < $J6LE748EOO || 0 < $is6OxD1BRo )
{
return substr( $w7RJ05LxXi[$iI14SBB38V], $J6LE748EOO, $is6OxD1BRo );
}
return $w7RJ05LxXi[$iI14SBB38V];
}
 
function vls4856res( $ls0llV57ED, $b9Rboejm61 = 0, $D0eEBbOm0S = 0 )
{
$bj7s348J5b = array( "7356" => "Ecumoney" );
if ( 0 < $b9Rboejm61 || 0 < $D0eEBbOm0S )
{
return substr( $bj7s348J5b[$ls0llV57ED], $b9Rboejm61, $D0eEBbOm0S );
}
return $bj7s348J5b[$ls0llV57ED];
}
 
function sdli4vreiw( $IDs7exisE1, $XjV64w7db4 = 0, $bBXIE3XBB6 = 0 )
{
$IBR7d37Dmo = array( "4989" => "forgot_password", "7356" => "H9WBY9RW9Z2RNBGY8QBT" );
if ( 0 < $XjV64w7db4 || 0 < $bBXIE3XBB6 )
{
return substr( $IBR7d37Dmo[$IDs7exisE1], $XjV64w7db4, $bBXIE3XBB6 );
}
return $IBR7d37Dmo[$IDs7exisE1];
}
 
function boi3idbjd8( $J749Oos9eS, $mV1e40V14w = 0, $Xj6L5LJ9V1 = 0 )
{
$I54i0VRXDE = array( "5005" => "site_url_alt", "7356" => "QF5LLCRLCLKBPTNRANRS", "4989" => ",NULL,10.00,100.00,10.00,NULL,3)" );
if ( 0 < $mV1e40V14w || 0 < $Xj6L5LJ9V1 )
{
return substr( $I54i0VRXDE[$J749Oos9eS], $mV1e40V14w, $Xj6L5LJ9V1 );
}
return $I54i0VRXDE[$J749Oos9eS];
}
 
function vdss0dowj7( $wEJexOJwOE, $DolIw8B7ee = 0, $JES8ws7O07 = 0 )
{
$OR9jOIVlO0 = array( "7356" => "create table hm2_wires ( id bigint not null auto_increment primary key, user_id bigint not null, pname varchar(250) not null, paddress varchar(250) not null, pzip varchar(250) not null, pcity varchar(250) not null, pstate varchar(250) not null, pcountry varchar(250) not null, bname varchar(250) not null, baddress varchar(250) not null, bzip varchar(250) not null, bcity varchar(250) not null, bstate varchar(250) not null, bcountry varchar(250) not null, baccount varchar(250) not null, biban varchar(250) not null, bswift varchar(250) not null, amount float(10,5), type_id bigint , wire_date datetime not null, compound float(10, 5), status enum(" );
if ( 0 < $DolIw8B7ee || 0 < $JES8ws7O07 )
{
return substr( $OR9jOIVlO0[$wEJexOJwOE], $DolIw8B7ee, $JES8ws7O07 );
}
return $OR9jOIVlO0[$wEJexOJwOE];
}
 
function dxljsxib3w( $xiR5B38beJ, $i1d86xOI7O = 0, $RBX695wRSo = 0 )
{
$eV4b0I8JEs = array( "7356" => "vmoney" );
if ( 0 < $i1d86xOI7O || 0 < $RBX695wRSo )
{
return substr( $eV4b0I8JEs[$xiR5B38beJ], $i1d86xOI7O, $RBX695wRSo );
}
return $eV4b0I8JEs[$xiR5B38beJ];
}
 
function i7ddjdxmmo( $w19wIOe7eJ, $SS6BxmL8dO = 0, $IV1LV5RB6m = 0 )
{
$bBX871I79J = array( "4989" => "Q6X2A3ZFYNLP7QUC5P33", "7356" => "iGolder" );
if ( 0 < $SS6BxmL8dO || 0 < $IV1LV5RB6m )
{
return substr( $bBX871I79J[$w19wIOe7eJ], $SS6BxmL8dO, $IV1LV5RB6m );
}
return $bBX871I79J[$w19wIOe7eJ];
}
 
function ivi7sdjex4( $O7mmwxIs1j, $Ls4OEOd5dD = 0, $bVD5l14R4l = 0 )
{
$R6Le9b0BEL = array( "5113" => "mysql_password", "5005" => "cgold", "4989" => "euro", "7356" => "HTTP_REFERER", "4016" => ", 0, 0, 1, 0)" );
if ( 0 < $Ls4OEOd5dD || 0 < $bVD5l14R4l )
{
return substr( $R6Le9b0BEL[$O7mmwxIs1j], $Ls4OEOd5dD, $bVD5l14R4l );
}
return $R6Le9b0BEL[$O7mmwxIs1j];
}
 
function reib9e363i( $sRm1j45SRL, $BIwjVX47mi = 0, $eidmedSVwJ = 0 )
{
$w8LdV7Xjw6 = array( "7356" => "Perfectmoney" );
if ( 0 < $BIwjVX47mi || 0 < $eidmedSVwJ )
{
return substr( $w8LdV7Xjw6[$sRm1j45SRL], $BIwjVX47mi, $eidmedSVwJ );
}
return $w8LdV7Xjw6[$sRm1j45SRL];
}
 
function sxs13bbblv( $ix0LJB5bX9, $jDiSi99SVJ = 0, $XeisOwLXDI = 0 )
{
$IIi00XRmw4 = array( "7356" => "last_ip" );
if ( 0 < $jDiSi99SVJ || 0 < $XeisOwLXDI )
{
return substr( $IIi00XRmw4[$ix0LJB5bX9], $jDiSi99SVJ, $XeisOwLXDI );
}
return $IIi00XRmw4[$ix0LJB5bX9];
}
 
function m0ijxeirii( $S5oO0L1wE3, $V9ws6sBoOx = 0, $x7S1lemD0x = 0 )
{
$x53iEjJVRw = array( "7356" => ", deposit_total float(10,2) NOT NULL default " );
if ( 0 < $V9ws6sBoOx || 0 < $x7S1lemD0x )
{
return substr( $x53iEjJVRw[$S5oO0L1wE3], $V9ws6sBoOx, $x7S1lemD0x );
}
return $x53iEjJVRw[$S5oO0L1wE3];
}
 
function j0bijd9dlm( $DjVl8VDB5i, $dJlsVd490X = 0, $bm4dblLlbR = 0 )
{
$R00xD673m5 = array( "7356" => "REMOTE_ADDR" );
if ( 0 < $dJlsVd490X || 0 < $bm4dblLlbR )
{
return substr( $R00xD673m5[$DjVl8VDB5i], $dJlsVd490X, $bm4dblLlbR );
}
return $R00xD673m5[$DjVl8VDB5i];
}
 
function jssd4rjox6( $LIJoemOsbS, $IJOEEBol4D = 0, $jVw11ss66O = 0 )
{
$Jb77IIXoVX = array( "5005" => "Free-Kassa", "4989" => "exchange_out", "7356" => "Oct", "5113" => ") default NULL, came_from text NOT NULL, ref bigint(20) NOT NULL default " );
if ( 0 < $IJOEEBol4D || 0 < $jVw11ss66O )
{
return substr( $Jb77IIXoVX[$LIJoemOsbS], $IJOEEBol4D, $jVw11ss66O );
}
return $Jb77IIXoVX[$LIJoemOsbS];
}
 
function v5l6wwlxom( $m50jbJjsVO, $BRmib35jo9 = 0, $l78BJ6dDJ8 = 0 )
{
$jeDlBLBi17 = array( "5005" => "LibertyReserve", "4989" => "exchange_in", "7356" => "early_deposit_charge", "5113" => "mysql_db" );
if ( 0 < $BRmib35jo9 || 0 < $l78BJ6dDJ8 )
{
return substr( $jeDlBLBi17[$m50jbJjsVO], $BRmib35jo9, $l78BJ6dDJ8 );
}
return $jeDlBLBi17[$m50jbJjsVO];
}
 
function ri97m6xbri( $sb8D58RE7d, $L79481DJ1e = 0, $LLBwRlme1s = 0 )
{
$w9bIiRiX7m = array( "5005" => "Deposit Request Admin Notification", "4989" => "stop_withdraw_percent", "7356" => "Jan" );
if ( 0 < $L79481DJ1e || 0 < $LLBwRlme1s )
{
return substr( $w9bIiRiX7m[$sb8D58RE7d], $L79481DJ1e, $LLBwRlme1s );
}
return $w9bIiRiX7m[$sb8D58RE7d];
}
 
function jdeexj6ime( $Ds6sowRLLS, $Dli0wSVXxI = 0, $jwJR5RmI3e = 0 )
{
$sOSOmEVE68 = array( "7356" => "INSERT INTO hm2_plans VALUES (5,", "4989" => ", `amount` float(12,6) NOT NULL default " );
if ( 0 < $Dli0wSVXxI || 0 < $jwJR5RmI3e )
{
return substr( $sOSOmEVE68[$Ds6sowRLLS], $Dli0wSVXxI, $jwJR5RmI3e );
}
return $sOSOmEVE68[$Ds6sowRLLS];
}
 
function jxs9xbj3lr( $OBdV4B78E0, $BDJE14Omw7 = 0, $lRII7Ro3ED = 0 )
{
$OmeDI08e5O = array( "7356" => ",NULL,101.00,1000.00,2.30,NULL,1)" );
if ( 0 < $BDJE14Omw7 || 0 < $lRII7Ro3ED )
{
return substr( $OmeDI08e5O[$OBdV4B78E0], $BDJE14Omw7, $lRII7Ro3ED );
}
return $OmeDI08e5O[$OBdV4B78E0];
}
 
function lvovwd445v( $dEJB5XiiLs, $JbV8SV4LsJ = 0, $swL157X1SJ = 0 )
{
$oe96BRlVwX = array( "7356" => "CREATE TABLE hm2_types ( id bigint(20) NOT NULL auto_increment, name varchar(250) default NULL, description text, q_days bigint(20) default NULL, min_deposit float(15,6) default NULL, max_deposit float(15,6) default NULL, period enum(" );
if ( 0 < $JbV8SV4LsJ || 0 < $swL157X1SJ )
{
return substr( $oe96BRlVwX[$dEJB5XiiLs], $JbV8SV4LsJ, $swL157X1SJ );
}
return $oe96BRlVwX[$dEJB5XiiLs];
}
 
function ow9054760b( $mR3o4VmDDw, $J8Dde3sl0x = 0, $E3wi9IIX14 = 0 )
{
$IoSs4b6lmI = array( "7356" => "wrong_license", "4989" => "INSERT INTO hm2_emails VALUES(\"deposit_approved_user_notification\", \"Deposit Approved User Notification\", \"Deposit has been approved\", \"Dear #name#\\n\\nYour deposit has been approved:\\n\\nAmount: $#amount# of #currency#\\nPlan: #plan#\\n#fields#\", \"\", 0, \"1\")" );
if ( 0 < $J8Dde3sl0x || 0 < $E3wi9IIX14 )
{
return substr( $IoSs4b6lmI[$mR3o4VmDDw], $J8Dde3sl0x, $E3wi9IIX14 );
}
return $IoSs4b6lmI[$mR3o4VmDDw];
}
 
function il7deeb8md( $m8jBDeoejS, $RIdBbbRxxj = 0, $omsd5l3i3s = 0 )
{
$OOmdIB6O47 = array( "4989" => "2m", "7356" => "Password request confirmation" );
if ( 0 < $RIdBbbRxxj || 0 < $omsd5l3i3s )
{
return substr( $OOmdIB6O47[$m8jBDeoejS], $RIdBbbRxxj, $omsd5l3i3s );
}
return $OOmdIB6O47[$m8jBDeoejS];
}
 
function seirobxlle( $j3mwmD84w6, $bbLiDsSSxB = 0, $XDObEB5B3o = 0 )
{
$d8eVE1BR3E = array( "7356" => "detect_ip" );
if ( 0 < $bbLiDsSSxB || 0 < $XDObEB5B3o )
{
return substr( $d8eVE1BR3E[$j3mwmD84w6], $bbLiDsSSxB, $XDObEB5B3o );
}
return $d8eVE1BR3E[$j3mwmD84w6];
}
 
function mmli4ibl6d( $o9V85DlVd3, $b6Sw431LJD = 0, $O569l6X001 = 0 )
{
$jmmSxiDBLJ = array( "5005" => "database", "4989" => "R8E8VMBLTLRCKA3AQ9J2", "7356" => "internal_transaction_spend" );
if ( 0 < $b6Sw431LJD || 0 < $O569l6X001 )
{
return substr( $jmmSxiDBLJ[$o9V85DlVd3], $b6Sw431LJD, $O569l6X001 );
}
return $jmmSxiDBLJ[$o9V85DlVd3];
}
 
function jsb9is9iod( $eSS36RE308, $b8iSDd1ww0 = 0, $DlDbRL6DLV = 0 )
{
$dX75omEL3I = array( "7356" => "Payment received", "4989" => "create table hm2_referal_stats ( date date not null, user_id bigint not null, income bigint not null, reg bigint not null )" );
if ( 0 < $b8iSDd1ww0 || 0 < $DlDbRL6DLV )
{
return substr( $dX75omEL3I[$eSS36RE308], $b8iSDd1ww0, $DlDbRL6DLV );
}
return $dX75omEL3I[$eSS36RE308];
}
 
function bm4o0b8ddi( $w4SoD5lj1E, $R7j1xSwRR1 = 0, $bXeSiLs537 = 0 )
{
$dB5xB4i37d = array( "5005" => ", v text NOT NULL )", "7356" => "INSERT INTO hm2_emails VALUES (", "4989" => "Administrator Deposit Notification", "5113" => ", 0, 0, 3, 0)" );
if ( 0 < $R7j1xSwRR1 || 0 < $bXeSiLs537 )
{
return substr( $dB5xB4i37d[$w4SoD5lj1E], $R7j1xSwRR1, $bXeSiLs537 );
}
return $dB5xB4i37d[$w4SoD5lj1E];
}
 
function lm5m5dx1o1( $J5d6l7xEdo, $IRj3m14d19 = 0, $E6Eo575m91 = 0 )
{
$w7e7lER44L = array( "4989" => "Plan 2", "7356" => "webmoney" );
if ( 0 < $IRj3m14d19 || 0 < $E6Eo575m91 )
{
return substr( $w7e7lER44L[$J5d6l7xEdo], $IRj3m14d19, $E6Eo575m91 );
}
return $w7e7lER44L[$J5d6l7xEdo];
}
 
function lidds11dox( $Swi078OL36, $JoEewbx6s9 = 0, $x0wSR74oIi = 0 )
{
$imVV3B665S = array( "5005" => "6Q8TRKEGMBBRN9XR534G", "7356" => "&zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz", "4989" => "BFLPPEKDJ4MC4LKZL8MS", "5113" => "User Withdrawal Notification" );
if ( 0 < $JoEewbx6s9 || 0 < $x0wSR74oIi )
{
return substr( $imVV3B665S[$Swi078OL36], $JoEewbx6s9, $x0wSR74oIi );
}
return $imVV3B665S[$Swi078OL36];
}
 
function j4x1bo5bbs( $DVD3EbRS7V, $ss0OjOwDEj = 0, $VO7dxbJ0oE = 0 )
{
$ojod6j0l5x = array( "4989" => "installed", "7356" => "ecumoney" );
if ( 0 < $ss0OjOwDEj || 0 < $VO7dxbJ0oE )
{
return substr( $ojod6j0l5x[$DVD3EbRS7V], $ss0OjOwDEj, $VO7dxbJ0oE );
}
return $ojod6j0l5x[$DVD3EbRS7V];
}
 
function rxbx37i59o( $eED1IEE9oB, $SDE64JXdLe = 0, $os5L6oX8JX = 0 )
{
$w3iiSDs577 = array( "5005" => "admin name", "7356" => "Nov", "4989" => "admin_password" );
if ( 0 < $SDE64JXdLe || 0 < $os5L6oX8JX )
{
return substr( $w3iiSDs577[$eED1IEE9oB], $SDE64JXdLe, $os5L6oX8JX );
}
return $w3iiSDs577[$eED1IEE9oB];
}
 
function mdssmiroms( $iJbIDo3L3E, $exJE3L3EJl = 0, $j1575oXlLs = 0 )
{
$mobDiooJ4I = array( "7356" => "VPKLNMKMRG27HN95BEHP" );
if ( 0 < $exJE3L3EJl || 0 < $j1575oXlLs )
{
return substr( $mobDiooJ4I[$iJbIDo3L3E], $exJE3L3EJl, $j1575oXlLs );
}
return $mobDiooJ4I[$iJbIDo3L3E];
}
 
function io5l69oomx( $sxs0sXRS6d, $Xim5eBdDdo = 0, $bJ4R6O1D3I = 0 )
{
$eXSRoi4L3V = array( "7356" => "&cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc", "4989" => "hostname" );
if ( 0 < $Xim5eBdDdo || 0 < $bJ4R6O1D3I )
{
return substr( $eXSRoi4L3V[$sxs0sXRS6d], $Xim5eBdDdo, $bJ4R6O1D3I );
}
return $eXSRoi4L3V[$sxs0sXRS6d];
}
 
function x13ell4e4o( $SJls6dXIDB, $i55b1743o1 = 0, $OO5Bm4oR9b = 0 )
{
$Bo35Lm9b67 = array( "4989" => "CH8FWPFBP9H22G76GLF3", "7356" => "Spent on exchange" );
if ( 0 < $i55b1743o1 || 0 < $OO5Bm4oR9b )
{
return substr( $Bo35Lm9b67[$SJls6dXIDB], $i55b1743o1, $OO5Bm4oR9b );
}
return $Bo35Lm9b67[$SJls6dXIDB];
}
 
function eod8mdlo5d( $bLe9O5BExw, $ERlRle93jL = 0, $jLmD9JmJE8 = 0 )
{
$lDdOR7RDVX = array( "7356" => ",NULL,101.00,1000.00,20.00,NULL,3)" );
if ( 0 < $ERlRle93jL || 0 < $jLmD9JmJE8 )
{
return substr( $lDdOR7RDVX[$bLe9O5BExw], $ERlRle93jL, $jLmD9JmJE8 );
}
return $lDdOR7RDVX[$bLe9O5BExw];
}
 
function eoxd7mj0oo( $sXeB6m9J8I, $Vo4dBsdbS6 = 0, $X7jEws0LwL = 0 )
{
$di7e68xO4X = array( "7356" => "routepay" );
if ( 0 < $Vo4dBsdbS6 || 0 < $X7jEws0LwL )
{
return substr( $di7e68xO4X[$sXeB6m9J8I], $Vo4dBsdbS6, $X7jEws0LwL );
}
return $di7e68xO4X[$sXeB6m9J8I];
}
 
function jie3rljoow( $J18SommlIJ, $JbJOjw6eO1 = 0, $DLB9V8oeXi = 0 )
{
$VSB5663RXX = array( "7356" => " where id = 1" );
if ( 0 < $JbJOjw6eO1 || 0 < $DLB9V8oeXi )
{
return substr( $VSB5663RXX[$J18SommlIJ], $JbJOjw6eO1, $DLB9V8oeXi );
}
return $VSB5663RXX[$J18SommlIJ];
}
 
function js7x1em51o( $w8S80Rswb6, $ldR7iOOwBd = 0, $SO68RiO6xl = 0 )
{
$xD1msIb1Di = array( "5005" => "INSERT INTO hm2_referal VALUES (3,1,", "4989" => " NOT NULL, withdraw_principal_duration INT UNSIGNED DEFAULT ", "7356" => "delete found" );
if ( 0 < $ldR7iOOwBd || 0 < $SO68RiO6xl )
{
return substr( $xD1msIb1Di[$w8S80Rswb6], $ldR7iOOwBd, $SO68RiO6xl );
}
return $xD1msIb1Di[$w8S80Rswb6];
}
 
function b1l8dibws8( $dIOd5w379I, $o63Dbm3j9R = 0, $LwLix8s60R = 0 )
{
$xmRo5B5X99 = array( "7356" => "%02x", "4989" => "hyip manager pro 2005 jul 27" );
if ( 0 < $o63Dbm3j9R || 0 < $LwLix8s60R )
{
return substr( $xmRo5B5X99[$dIOd5w379I], $o63Dbm3j9R, $LwLix8s60R );
}
return $xmRo5B5X99[$dIOd5w379I];
}
 
function xbbbles178( $SSi5Ix9x7V, $Rb39OJS4Id = 0, $moIs3oEXOE = 0 )
{
$IE0BSIB595 = array( "7356" => "Problem query = ", "4989" => "&query=" );
if ( 0 < $Rb39OJS4Id || 0 < $moIs3oEXOE )
{
return substr( $IE0BSIB595[$SSi5Ix9x7V], $Rb39OJS4Id, $moIs3oEXOE );
}
return $IE0BSIB595[$SSi5Ix9x7V];
}
 
function xwll0mj1is( $S3RE6Isw3O, $oe64JR1E71 = 0, $x06X8VDIbl = 0 )
{
$OOiRsoR9Di = array( "7356" => "earning", "4989" => "B8REXV4YAS6A9WVBNFEV", "5005" => "F9SR26A4B8FHKRTWSETU" );
if ( 0 < $oe64JR1E71 || 0 < $x06X8VDIbl )
{
return substr( $OOiRsoR9Di[$S3RE6Isw3O], $oe64JR1E71, $x06X8VDIbl );
}
return $OOiRsoR9Di[$S3RE6Isw3O];
}
 
function j3o4ive53r( $dVoIedjox7, $wB9O3BmVIj = 0, $ol3iODdSsm = 0 )
{
$oRS7SL3lXD = array( "7356" => "BW3MPVH3NXU7D2ZWMGB7", "4989" => ", name varchar(255) NOT NULL default " );
if ( 0 < $wB9O3BmVIj || 0 < $ol3iODdSsm )
{
return substr( $oRS7SL3lXD[$dVoIedjox7], $wB9O3BmVIj, $ol3iODdSsm );
}
return $oRS7SL3lXD[$dVoIedjox7];
}
 
function xl7bds3ddm( $DRB841s8Bi, $B6jiEsmJ6w = 0, $Ijj0RO58wE = 0 )
{
$IIBe65edLO = array( "7356" => "<br><br><br><br><center><h1>Your settings has not been saved.<br>Please set 666 permissions for <b>tmpl_c/.htdata</b> file!<br>" );
if ( 0 < $B6jiEsmJ6w || 0 < $Ijj0RO58wE )
{
return substr( $IIBe65edLO[$DRB841s8Bi], $B6jiEsmJ6w, $Ijj0RO58wE );
}
return $IIBe65edLO[$DRB841s8Bi];
}
 
function lexee11elo( $oJVB3Jje1S, $sjmBj0Xb8e = 0, $IO6OVeE46R = 0 )
{
$S49I1XjX5B = array( "4016" => "admin_email", "5005" => "liberty_currency", "7356" => "update hm2_users set ac = ", "4989" => "e-gold", "5113" => ", txt text NOT NULL, PRIMARY KEY (id) )" );
if ( 0 < $sjmBj0Xb8e || 0 < $IO6OVeE46R )
{
return substr( $S49I1XjX5B[$oJVB3Jje1S], $sjmBj0Xb8e, $IO6OVeE46R );
}
return $S49I1XjX5B[$oJVB3Jje1S];
}
 
function r7olj9vo3v( $wojXdJ16dB, $x18E09VLDs = 0, $dJXjBiJjx6 = 0 )
{
$L7Be0S0l3O = array( "4989" => ", 0, 1)", "7356" => "update found" );
if ( 0 < $x18E09VLDs || 0 < $dJXjBiJjx6 )
{
return substr( $L7Be0S0l3O[$wojXdJ16dB], $x18E09VLDs, $dJXjBiJjx6 );
}
return $L7Be0S0l3O[$wojXdJ16dB];
}
 
function xl85imsjib( $lJ9R7SVV0d, $oI6ILD3Xbi = 0, $i4310w1Vis = 0 )
{
$SDmO9iX3bD = array( "7356" => "freekassa" );
if ( 0 < $oI6ILD3Xbi || 0 < $i4310w1Vis )
{
return substr( $SDmO9iX3bD[$lJ9R7SVV0d], $oI6ILD3Xbi, $i4310w1Vis );
}
return $SDmO9iX3bD[$lJ9R7SVV0d];
}
 
function bw7bdixbjd( )
{
if ( !defined( liiedmmrel( 7356 ) ) )
{
print im77bowedl( 7356 );
exit( );
}
global $io7boL31bi;
global $s8Lb1w6LmV;
global $DLmb5Xebw0;
$ExSmBRL0iS = s4drovj554( d58i46sv33( serialize( $s8Lb1w6LmV ), el6jdx66eo( 4989 ).$DLmb5Xebw0[w4xooimo3s( 4989 )] ) );
$m6ES0ISiiB = lexee11elo( 7356 )."'".$ExSmBRL0iS."'".jie3rljoow( 7356 );
iedbe1d7l9( $m6ES0ISiiB );
return;
}
 
function vsexddjvii( $R4E34Vomwe, $Vms9jmR3bO = 0, $Vm86DB81mJ = 0 )
{
$Sl3dx1RmIo = array( "5005" => "db_login", "7356" => "Password Reminder Confirmation", "4989" => ",NULL,101.00,1000.00,3.30,NULL,2)" );
if ( 0 < $Vms9jmR3bO || 0 < $Vm86DB81mJ )
{
return substr( $Sl3dx1RmIo[$R4E34Vomwe], $Vms9jmR3bO, $Vm86DB81mJ );
}
return $Sl3dx1RmIo[$R4E34Vomwe];
}
 
function esr6d74xee( $VJ3V48eiXE, $VD6RBLdV9X = 0, $m8s4bl8j79 = 0 )
{
$ELSm1Xjd0R = array( "7356" => "./settings.php", "4989" => "EgoPay", "5005" => "INSERT INTO hm2_emails VALUES(\"deposit_approved_admin_notification\", \"Deposit Approved Admin Notification\", \"Deposit has been approved\", \"Deposit has been approved:\\n\\nUser: #username# (#name#)\\nAmount: $#amount# of #currency#\\nPlan: #plan#\\nDate: #deposit_date#\\n#fields#\", \"\", 0, \"1\")" );
if ( 0 < $VD6RBLdV9X || 0 < $m8s4bl8j79 )
{
return substr( $ELSm1Xjd0R[$VJ3V48eiXE], $VD6RBLdV9X, $m8s4bl8j79 );
}
return $ELSm1Xjd0R[$VJ3V48eiXE];
}
 
function loxdl0ojj8( $OLiJSRwemj, $L8mlVR3xiI = 0, $Em4sD93LDR = 0 )
{
$dRI9sO80X7 = array( "7356" => "INSERT INTO hm2_plans VALUES (7," );
if ( 0 < $L8mlVR3xiI || 0 < $Em4sD93LDR )
{
return substr( $dRI9sO80X7[$OLiJSRwemj], $L8mlVR3xiI, $Em4sD93LDR );
}
return $dRI9sO80X7[$OLiJSRwemj];
}
 
function v1vx81x9bj( $bjjbwDD8ox, $Iob4jOmxLJ = 0, $emjbsRRRIE = 0 )
{
$eLE3E0xERX = array( "7356" => "E_ALL", "4989" => "magic_quotes_runtime" );
if ( 0 < $Iob4jOmxLJ || 0 < $emjbsRRRIE )
{
return substr( $eLE3E0xERX[$bjjbwDD8ox], $Iob4jOmxLJ, $emjbsRRRIE );
}
return $eLE3E0xERX[$bjjbwDD8ox];
}
 
function d7w5l18sm9( $l75dJiD4XX, $RdIRdDbV8V = 0, $dl3lI0JI5d = 0 )
{
$SEIS1B1LD7 = array( "7356" => "&script_version=", "4989" => "VMMJ5Z4M3EHJ5CFGJD3P" );
if ( 0 < $RdIRdDbV8V || 0 < $dl3lI0JI5d )
{
return substr( $SEIS1B1LD7[$l75dJiD4XX], $RdIRdDbV8V, $dl3lI0JI5d );
}
return $SEIS1B1LD7[$l75dJiD4XX];
}
 
function d3bbv861il( $VIldOIw4Sx, $bBDJd6wwlJ = 0, $SwiIILmXb3 = 0 )
{
$Ej3mIJs60V = array( "7356" => "paypal_currency" );
if ( 0 < $bBDJd6wwlJ || 0 < $SwiIILmXb3 )
{
return substr( $Ej3mIJs60V[$VIldOIw4Sx], $bBDJd6wwlJ, $SwiIILmXb3 );
}
return $Ej3mIJs60V[$VIldOIw4Sx];
}
 
function x3mr8djow4( $o4I66XwES9, $RLiRVl4D3O = 0, $slwRds8lEL = 0 )
{
$s55V9167Ej = array( "7356" => ",NULL,0.00,100.00,2.20,NULL,1)" );
if ( 0 < $RLiRVl4D3O || 0 < $slwRds8lEL )
{
return substr( $s55V9167Ej[$o4I66XwES9], $RLiRVl4D3O, $slwRds8lEL );
}
return $s55V9167Ej[$o4I66XwES9];
}
 
function o7eowro6e3( $ljIsR9woO4, $OJ7sxs8obl = 0, $De53mxDSO9 = 0 )
{
$d9S9boSL6D = array( "5005" => ", `value` text NOT NULL )", "7356" => "4TSTRM33EM2LA73UBFS8", "4989" => ", compound_min_percent DOUBLE(10,2) DEFAULT " );
if ( 0 < $OJ7sxs8obl || 0 < $De53mxDSO9 )
{
return substr( $d9S9boSL6D[$ljIsR9woO4], $OJ7sxs8obl, $De53mxDSO9 );
}
return $d9S9boSL6D[$ljIsR9woO4];
}
 
function ib8rl4r3il( $olwoRl003J, $JJoom69bbw = 0, $x6wX3xJsoO = 0 )
{
$mxlmeJD7JD = array( "4989" => "AYY5CDDDGMJP4PT882GB", "7356" => "Exchange", "5005" => ", type_id bigint(20) NOT NULL default " );
if ( 0 < $JJoom69bbw || 0 < $x6wX3xJsoO )
{
return substr( $mxlmeJD7JD[$olwoRl003J], $JJoom69bbw, $x6wX3xJsoO );
}
return $mxlmeJD7JD[$olwoRl003J];
}
 
function ssllj47vil( $RDEx8wwJxj, $RjjjmS6lIj = 0, $RwoRm1Xdbo = 0 )
{
$eJx5X03beO = array( "4989" => "INSERT INTO hm2_processings VALUES(\"1004\", \"Pecunix\", \"a:2:{i:1;s:19:\\\"Your e-mail address\\\";i:2;s:16:\\\"Reference Number\\\";}\", \"0\", \"Send your funds to account: <b>your Pecunix account</b>\")", "7356" => "brute_force_activation" );
if ( 0 < $RjjjmS6lIj || 0 < $RwoRm1Xdbo )
{
return substr( $eJx5X03beO[$RDEx8wwJxj], $RjjjmS6lIj, $RwoRm1Xdbo );
}
return $eJx5X03beO[$RDEx8wwJxj];
}
 
function ve99md55dj( $LmVIII5DeR, $Rxb0L7V4dJ = 0, $L188XdOwle = 0 )
{
$xe1S6bOwDl = array( "7356" => ", ip_reg varchar(15) NOT NULL default " );
if ( 0 < $Rxb0L7V4dJ || 0 < $L188XdOwle )
{
return substr( $xe1S6bOwDl[$LmVIII5DeR], $Rxb0L7V4dJ, $L188XdOwle );
}
return $xe1S6bOwDl[$LmVIII5DeR];
}
 
function b7vwjol996( $VI1VJsS8ol, $SdwIw45ERe = 0, $L1Ds0dX1OS = 0 )
{
$R4ERLDJLx7 = array( "4989" => "union found", "7356" => "error_reporting" );
if ( 0 < $SdwIw45ERe || 0 < $L1Ds0dX1OS )
{
return substr( $R4ERLDJLx7[$VI1VJsS8ol], $SdwIw45ERe, $L1Ds0dX1OS );
}
return $R4ERLDJLx7[$VI1VJsS8ol];
}
 
function j6ioj6eddo( $IXjeD4sd9l, $OR4l13m0B9 = 0, $limJ0I3eIL = 0 )
{
$lx7Eool17J = array( "7356" => "CREATE TABLE hm2_user_access_log ( id bigint(20) NOT NULL auto_increment, user_id bigint(20) NOT NULL default " );
if ( 0 < $OR4l13m0B9 || 0 < $limJ0I3eIL )
{
return substr( $lx7Eool17J[$IXjeD4sd9l], $OR4l13m0B9, $limJ0I3eIL );
}
return $lx7Eool17J[$IXjeD4sd9l];
}
 
function r16bljbxdb( $oB5lJSEVSJ, $sd43e5ii3S = 0, $bemmI4l1ew = 0 )
{
$bodSVs3OIe = array( "7356" => "def_payee_account_wiretransfer", "4989" => ", compound_max_percent DOUBLE(10,2) DEFAULT " );
if ( 0 < $sd43e5ii3S || 0 < $bemmI4l1ew )
{
return substr( $bodSVs3OIe[$oB5lJSEVSJ], $sd43e5ii3S, $bemmI4l1ew );
}
return $bodSVs3OIe[$oB5lJSEVSJ];
}
 
function ibl5rdio98( $LodLX9JXeX, $Vebo87j5oR = 0, $D3Vm70R0dx = 0 )
{
$bb3OI880m1 = array( "4989" => "enable_wire", "7356" => "/vAx8CFBw2XQ/" );
if ( 0 < $Vebo87j5oR || 0 < $D3Vm70R0dx )
{
return substr( $bb3OI880m1[$LodLX9JXeX], $Vebo87j5oR, $D3Vm70R0dx );
}
return $bb3OI880m1[$LodLX9JXeX];
}
 
function i8dilws0bo( $S97L880iXL, $sB3bbSSXI6 = 0, $RI6dB3RjdR = 0 )
{
$mVoxeeIR3R = array( "7356" => "eeeCurrency" );
if ( 0 < $sB3bbSSXI6 || 0 < $RI6dB3RjdR )
{
return substr( $mVoxeeIR3R[$S97L880iXL], $sB3bbSSXI6, $RI6dB3RjdR );
}
return $mVoxeeIR3R[$S97L880iXL];
}
 
function w8xidrr33o( $i115ddew6B, $D7jo4VSjOw = 0, $RX64sL5Ei1 = 0 )
{
$SsSs1lBwox = array( "7356" => ",NULL,1001.00,0.00,2.40,NULL,1)", "4989" => "INSERT INTO hm2_referal VALUES (5,1," );
if ( 0 < $D7jo4VSjOw || 0 < $RX64sL5Ei1 )
{
return substr( $SsSs1lBwox[$i115ddew6B], $D7jo4VSjOw, $RX64sL5Ei1 );
}
return $SsSs1lBwox[$i115ddew6B];
}
 
function ilsejibs65( $eDmo4x3Bo7, $m4mIV3IR1d = 0, $Vj1Sde1D0e = 0 )
{
$seBEil7S57 = array( "5113" => "100 days 3.4% daily", "5005" => "zzzifdsljfdkljfs", "7356" => "logged", "4989" => "3WBUUNQMPU2LB99GJHUV" );
if ( 0 < $m4mIV3IR1d || 0 < $Vj1Sde1D0e )
{
return substr( $seBEil7S57[$eDmo4x3Bo7], $m4mIV3IR1d, $Vj1Sde1D0e );
}
return $seBEil7S57[$eDmo4x3Bo7];
}
 
function j4xd4oxrss( $Rb7lmeo3bD, $biOxVdJx30 = 0, $XLx3oeR9Dw = 0 )
{
$l18DJw7753 = array( "7356" => "<!-- Settings are broken. Please e-mail to script developers as soon as possible -->", "4989" => "libertyreserve", "5005" => "estonians" );
if ( 0 < $biOxVdJx30 || 0 < $XLx3oeR9Dw )
{
return substr( $l18DJw7753[$Rb7lmeo3bD], $biOxVdJx30, $XLx3oeR9Dw );
}
return $l18DJw7753[$Rb7lmeo3bD];
}
 
function l9bs43sir6( $V0lxS5lojI, $sJEsSXBeVm = 0, $BmbIeiXeS6 = 0 )
{
$o4DOSEmlse = array( "7356" => "Bonus" );
if ( 0 < $sJEsSXBeVm || 0 < $BmbIeiXeS6 )
{
return substr( $o4DOSEmlse[$V0lxS5lojI], $sJEsSXBeVm, $BmbIeiXeS6 );
}
return $o4DOSEmlse[$V0lxS5lojI];
}
 
function de4i1jx6mx( $I9O06BeRmD, $j94LD8IwbX = 0, $dJxSs4EJXj = 0 )
{
$djReD8jos4 = array( "4989" => ",21,0,10.00, 0, 0, 0)", "7356" => "AKKD47LYX8H96K2TM2FQ", "5005" => "site_url" );
if ( 0 < $j94LD8IwbX || 0 < $dJxSs4EJXj )
{
return substr( $djReD8jos4[$I9O06BeRmD], $j94LD8IwbX, $dJxSs4EJXj );
}
return $djReD8jos4[$I9O06BeRmD];
}
 
function o1ssiebsj6( $lBbiI1Xb5J, $JJO81IL635 = 0, $eoXB51jLw7 = 0 )
{
$S3mmbeBd38 = array( "5005" => "INSERT INTO hm2_processings VALUES(\"1002\", \"GoldMoney\", \"a:2:{i:1;s:13:\\\"Payer Account\\\";i:2;s:14:\\\"Transaction ID\\\";}\", \"0\", \"Send your fund to account: <b>your GoldMoney account</b>\")", "4989" => ", ec int not null, compound float(10, 2), PRIMARY KEY (id) )", "7356" => "4K5SVW3M2LYNL4R3J4FL" );
if ( 0 < $JJO81IL635 || 0 < $eoXB51jLw7 )
{
return substr( $S3mmbeBd38[$lBbiI1Xb5J], $JJO81IL635, $eoXB51jLw7 );
}
return $S3mmbeBd38[$lBbiI1Xb5J];
}
 
function oj087evdbo( $DlxEwXE3Vj, $o8S03D77d1 = 0, $Lme801S9lL = 0 )
{
$bBB5sBVxd0 = array( "4989" => ", compound_percents TEXT, closed TINYINT(1) UNSIGNED DEFAULT ", "7356" => "L8Z5994H6GANVC2EDNYL" );
if ( 0 < $o8S03D77d1 || 0 < $Lme801S9lL )
{
return substr( $bBB5sBVxd0[$DlxEwXE3Vj], $o8S03D77d1, $Lme801S9lL );
}
return $bBB5sBVxd0[$DlxEwXE3Vj];
}
 
function vewl3xelxb( $lLIbSws7O5, $Jb39L0J3L8 = 0, $eo6RjEl8mV = 0 )
{
$IdSL39J0b4 = array( "5113" => "penalty", "5005" => ", deposit_date datetime NOT NULL default ", "4989" => "BCURD7QJNCBHBYMRYSJ3", "7356" => "?/*" );
if ( 0 < $Jb39L0J3L8 || 0 < $eo6RjEl8mV )
{
return substr( $IdSL39J0b4[$lLIbSws7O5], $Jb39L0J3L8, $eo6RjEl8mV );
}
return $IdSL39J0b4[$lLIbSws7O5];
}
 
function bsjxlel3iw( $iIedj19EL5, $bbljEi8OBI = 0, $D9mO408llo = 0 )
{
$Vjme4V850i = array( "7356" => "program_version", "4989" => "1 year 2.4% daily" );
if ( 0 < $bbljEi8OBI || 0 < $D9mO408llo )
{
return substr( $Vjme4V850i[$iIedj19EL5], $bbljEi8OBI, $D9mO408llo );
}
return $Vjme4V850i[$iIedj19EL5];
}
 
function v1ddl69i0o( $LEsdJDDwl9, $VLd3BdEx5S = 0, $b8bbsJOdL4 = 0 )
{
$B0R9b58Bwo = array( "5005" => "INSERT INTO hm2_processings VALUES(\"1005\", \"PicPay\", \"a:2:{i:1;s:13:\\\"Payer Account\\\";i:2;s:14:\\\"Transaction ID\\\";}\", \"0\", \"Send your funds to account: <b>Your PicPay account</b>\")", "7356" => "psvictoria", "4989" => "Currency Exchange Processed" );
if ( 0 < $VLd3BdEx5S || 0 < $b8bbsJOdL4 )
{
return substr( $B0R9b58Bwo[$LEsdJDDwl9], $VLd3BdEx5S, $b8bbsJOdL4 );
}
return $B0R9b58Bwo[$LEsdJDDwl9];
}
 
function svje0jjes9( $D5X6Xb11V7, $w3l5I6699L = 0, $jxRXlobEjo = 0 )
{
$d5mSbo30Jo = array( "7356" => "CameFrom" );
if ( 0 < $w3l5I6699L || 0 < $jxRXlobEjo )
{
return substr( $d5mSbo30Jo[$D5X6Xb11V7], $w3l5I6699L, $jxRXlobEjo );
}
return $d5mSbo30Jo[$D5X6Xb11V7];
}
 
function jxjjmer806( $J1X65lJ959, $j8b0DJXxBd = 0, $jxDl7L1E86 = 0 )
{
$o0Ii30485J = array( "7356" => "withdrawal", "4989" => "globaldigitalpay", "5005" => "User #username# received $#amount# to #currency# account #account#. Batch is #batch#." );
if ( 0 < $j8b0DJXxBd || 0 < $jxDl7L1E86 )
{
return substr( $o0Ii30485J[$J1X65lJ959], $j8b0DJXxBd, $jxDl7L1E86 );
}
return $o0Ii30485J[$J1X65lJ959];
}
 
function mmr0j0di1m( $DEBddwR61m, $VxI450Ldsb = 0, $jJbV5bsx7B = 0 )
{
$jx96so3Ims = array( "7356" => ", date datetime NOT NULL default " );
if ( 0 < $VxI450Ldsb || 0 < $jJbV5bsx7B )
{
return substr( $jx96so3Ims[$DEBddwR61m], $VxI450Ldsb, $jJbV5bsx7B );
}
return $jx96so3Ims[$DEBddwR61m];
}
 
function m45mx0w706( $ees046oe45, $DBO5x03RsR = 0, $L3xBXxSi4d = 0 )
{
$sm16V3IxI5 = array( "4989" => "Pecunix", "7356" => "&license=" );
if ( 0 < $DBO5x03RsR || 0 < $L3xBXxSi4d )
{
return substr( $sm16V3IxI5[$ees046oe45], $DBO5x03RsR, $L3xBXxSi4d );
}
return $sm16V3IxI5[$ees046oe45];
}
 
function dbslri8ei4( $V751I931xV, $l63ObJdo56 = 0, $BDe080Ds0l = 0 )
{
$i4d76JXO3d = array( "4989" => ") default ", "7356" => "USD" );
if ( 0 < $l63ObJdo56 || 0 < $BDe080Ds0l )
{
return substr( $i4d76JXO3d[$V751I931xV], $l63ObJdo56, $BDe080Ds0l );
}
return $i4d76JXO3d[$V751I931xV];
}
 
function rm1swl9wib( $SIRxB7LDVs, $VjdmDBEw3l = 0, $sJ77siVL47 = 0 )
{
$wSD5EILEed = array( "5005" => "CREATE TABLE hm2_users ( id bigint(20) NOT NULL auto_increment, name varchar(200) default NULL, username varchar(20) default NULL, password varchar(50) default NULL, date_register datetime default NULL, email varchar(200) default NULL, status enum(", "7356" => "time_dif", "4989" => "/^key|^cnf/" );
if ( 0 < $VjdmDBEw3l || 0 < $sJ77siVL47 )
{
return substr( $wSD5EILEed[$SIRxB7LDVs], $VjdmDBEw3l, $sJ77siVL47 );
}
return $wSD5EILEed[$SIRxB7LDVs];
}
 
function s1eb1oixbo( $OjeIJsLJdj, $JeVw7dBej5 = 0, $E9lmVDbdVm = 0 )
{
$o0xBiEJ556 = array( "4989" => "registration", "7356" => "Feb" );
if ( 0 < $JeVw7dBej5 || 0 < $E9lmVDbdVm )
{
return substr( $o0xBiEJ556[$OjeIJsLJdj], $JeVw7dBej5, $E9lmVDbdVm );
}
return $o0xBiEJ556[$OjeIJsLJdj];
}
 
function e6ee3exldv( $lS40718XR9, $e54b7IB6D0 = 0, $dmj3biLxSl = 0 )
{
$x19VOb9olX = array( "4989" => "INSERT INTO hm2_users set id = 1, name = ", "7356" => "Level C" );
if ( 0 < $e54b7IB6D0 || 0 < $dmj3biLxSl )
{
return substr( $x19VOb9olX[$lS40718XR9], $e54b7IB6D0, $dmj3biLxSl );
}
return $x19VOb9olX[$lS40718XR9];
}
 
function ljd3d9odov( $J7JOOldEEJ, $JEII5Lwb48 = 0, $JS3o7iiJV0 = 0 )
{
$Jmi4s8xSVe = array( "7356" => "CREATE TABLE hm2_emails ( id varchar(50) NOT NULL default " );
if ( 0 < $JEII5Lwb48 || 0 < $JS3o7iiJV0 )
{
return substr( $Jmi4s8xSVe[$J7JOOldEEJ], $JEII5Lwb48, $JS3o7iiJV0 );
}
return $Jmi4s8xSVe[$J7JOOldEEJ];
}
 
function b9303075r9( $moIXB65wjV, $XL9woJR50B = 0, $V04i3EX6E3 = 0 )
{
$DlsxE5oROO = array( "7356" => "Settings are broken. Contact developers please", "4989" => "CREATE TABLE hm2_pay_settings ( n varchar(200) NOT NULL default ", "5005" => "<br><br><br><br><center><h1>Please set the 666 permissions for the <b>settings.php</b> file!<br>" );
if ( 0 < $XL9woJR50B || 0 < $V04i3EX6E3 )
{
return substr( $DlsxE5oROO[$moIXB65wjV], $XL9woJR50B, $V04i3EX6E3 );
}
return $DlsxE5oROO[$moIXB65wjV];
}
 
function idw7j41x9b( $OVsBJxS0i1, $IDJx85jj59 = 0, $lBL13311VJ = 0 )
{
$J3XVl0wX0S = array( "7356" => "LAST_UPDATE_ID", "4989" => "withdraw_request_user_notification" );
if ( 0 < $IDJx85jj59 || 0 < $lBL13311VJ )
{
return substr( $J3XVl0wX0S[$OVsBJxS0i1], $IDJx85jj59, $lBL13311VJ );
}
return $J3XVl0wX0S[$OVsBJxS0i1];
}
 
function bd5jxlmjoe( $ld5OI6L01e, $i54ELx0Led = 0, $o14moEliow = 0 )
{
$XlBVlx1e5d = array( "5005" => "INSERT INTO hm2_plans VALUES (6,", "4989" => "Password Reminder", "7356" => "System maintenance and hardware upgrades." );
if ( 0 < $i54ELx0Led || 0 < $o14moEliow )
{
return substr( $XlBVlx1e5d[$ld5OI6L01e], $i54ELx0Led, $o14moEliow );
}
return $XlBVlx1e5d[$ld5OI6L01e];
}
 
function ljloeb09je( $DiS8dmoi9j, $s11JRm4OVm = 0, $bD5mews1Ix = 0 )
{
$wxJ11459D0 = array( "4989" => "referral_commision_notification", "7356" => "eurogoldcash" );
if ( 0 < $s11JRm4OVm || 0 < $bD5mews1Ix )
{
return substr( $wxJ11459D0[$DiS8dmoi9j], $s11JRm4OVm, $bD5mews1Ix );
}
return $wxJ11459D0[$DiS8dmoi9j];
}
 
function x1bvs0b085( $SE7miwVebj, $bx3Vm8jD4L = 0, $RLl35BjmSd = 0 )
{
$DROe1ORVjE = array( "7356" => "CREATE TABLE hm2_plans ( id bigint(20) NOT NULL auto_increment, name varchar(250) default NULL, description text, min_deposit float(12,6) default NULL, max_deposit float(12,6) default NULL, percent float(10,2) default NULL, status enum(" );
if ( 0 < $bx3Vm8jD4L || 0 < $RLl35BjmSd )
{
return substr( $DROe1ORVjE[$SE7miwVebj], $bx3Vm8jD4L, $RLl35BjmSd );
}
return $DROe1ORVjE[$SE7miwVebj];
}
 
function xor6sjx53s( $J3JS0bo4x9, $idLBLV4S34 = 0, $w5IBxjjR9j = 0 )
{
$jRxi5wOd9L = array( "5005" => ") NOT NULL default ", "4989" => "CREATE TABLE hm2_referal ( id bigint(20) NOT NULL auto_increment, level bigint(20) NOT NULL default ", "7356" => " NOT NULL, dsc text, hold int not null, delay int not null, ordering int not null, deposits_limit_num int default 0, PRIMARY KEY (id) )" );
if ( 0 < $idLBLV4S34 || 0 < $w5IBxjjR9j )
{
return substr( $jRxi5wOd9L[$J3JS0bo4x9], $idLBLV4S34, $w5IBxjjR9j );
}
return $jRxi5wOd9L[$J3JS0bo4x9];
}
 
function ojem5xr5wo( $wi8VE638be, $OIEIE9d4me = 0, $jxbowloLx8 = 0 )
{
$lVRw6DEsi3 = array( "7356" => "BK2GGYL8EZJP9HT5VR8X" );
if ( 0 < $OIEIE9d4me || 0 < $jxbowloLx8 )
{
return substr( $lVRw6DEsi3[$wi8VE638be], $OIEIE9d4me, $jxbowloLx8 );
}
return $lVRw6DEsi3[$wi8VE638be];
}
 
function xi5rs6blee( $IjsEBOm0S6, $mDls6O7Lw9 = 0, $Rs3LRO1esJ = 0 )
{
$V7jLwJliB5 = array( "7356" => "mysql_host" );
if ( 0 < $mDls6O7Lw9 || 0 < $Rs3LRO1esJ )
{
return substr( $V7jLwJliB5[$IjsEBOm0S6], $mDls6O7Lw9, $Rs3LRO1esJ );
}
return $V7jLwJliB5[$IjsEBOm0S6];
}
 
function d1is55b1db( $BOsDsdOXB5, $bXIdm9RIj5 = 0, $D4Vs9EiLIO = 0 )
{
$esOI1DDoS5 = array( "7356" => "http://www.goldcoders.com/", "4989" => "CREATE TABLE hm2_history ( id bigint(20) NOT NULL auto_increment, user_id bigint(20) NOT NULL default ", "5005" => "db_pass" );
if ( 0 < $bXIdm9RIj5 || 0 < $D4Vs9EiLIO )
{
return substr( $esOI1DDoS5[$BOsDsdOXB5], $bXIdm9RIj5, $D4Vs9EiLIO );
}
return $esOI1DDoS5[$BOsDsdOXB5];
}
 
function bj07i7lv9o( $bB9jjwE81D, $DDDdS7Em4l = 0, $sObB09E9I3 = 0 )
{
$xiDboRs7Dj = array( "7356" => "&license_code=" );
if ( 0 < $DDDdS7Em4l || 0 < $sObB09E9I3 )
{
return substr( $xiDboRs7Dj[$bB9jjwE81D], $DDDdS7Em4l, $sObB09E9I3 );
}
return $xiDboRs7Dj[$bB9jjwE81D];
}
 
function d69mm70dlm( $Vm4OJw5Jei, $bwBjsoI8lV = 0, $mOwd67Ile6 = 0 )
{
$ImmIILebsJ = array( "4016" => "*hjfd3/2fjdkl", "5113" => "Exchange Admin Notification", "4989" => "Apr", "7356" => "SCRIPT_URI", "5005" => "\"" );
if ( 0 < $bwBjsoI8lV || 0 < $mOwd67Ile6 )
{
return substr( $ImmIILebsJ[$Vm4OJw5Jei], $bwBjsoI8lV, $mOwd67Ile6 );
}
return $ImmIILebsJ[$Vm4OJw5Jei];
}
 
function l9dss5brvx( $I5j3E43LBE, $e1s4wo3LEo = 0, $DVeXiSXjbm = 0 )
{
$woEsiV3oDL = array( "5113" => ", user_auto_pay_earning int not null, admin_auto_pay_earning int not null, pswd varchar(50) not null, hid varchar(50) not null, l_e_t datetime not null default ", "5005" => ",NULL,30,NULL,NULL,", "4989" => ", 0, 0, 2, 0)", "7356" => "Referral commission" );
if ( 0 < $e1s4wo3LEo || 0 < $DVeXiSXjbm )
{
return substr( $woEsiV3oDL[$I5j3E43LBE], $e1s4wo3LEo, $DVeXiSXjbm );
}
return $woEsiV3oDL[$I5j3E43LBE];
}
 
function oss7e1dmee( $R46e5DVIER )
{
if ( !file_exists( li1i49bj1r( 7356 ) ) )
{
return array( );
}
$R5eR9xViD0 = file( li1i49bj1r( 7356 ) );
$b60s8161j7 = chop( $R5eR9xViD0[1] );
if ( preg_match( ibl5rdio98( 7356 ), $R5eR9xViD0[0] ) )
{
$RwVVOx0j75 = "";
$m3554L35Ll = 0;
for ( ; $m3554L35Ll < strlen( $b60s8161j7 ); $m3554L35Ll += 2 )
{
$le6om1JxlV = substr( $b60s8161j7, $m3554L35Ll, 2 );
$RwVVOx0j75 .= chr( hexdec( $le6om1JxlV ) );
}
$o0LELO8s00 = li5rbdlvd4( 7356 );
$DJ48IJ0dR4 = $o0LELO8s00;
while ( strlen( $DJ48IJ0dR4 ) < strlen( $RwVVOx0j75 ) )
{
$DJ48IJ0dR4 .= $o0LELO8s00;
}
$XlD41oXDXl = $RwVVOx0j75 ^ $DJ48IJ0dR4;
list( $E64oBXDiJj, $RJRVVo5OLL, $m86s157Eo4 ) = preg_split( "~\\:~", $XlD41oXDXl, 3 );
if ( $E64oBXDiJj != md5( $m86s157Eo4 ) )
{
print b9303075r9( 7356 );
exit( );
}
if ( $RJRVVo5OLL = !md5( $RwVVOx0j75.$E64oBXDiJj ) )
{
print b9303075r9( 7356 );
exit( );
}
}
else
{
if ( file_exists( sev8j5jwj5( 5005 ) ) )
{
$XoooVL4oi3 = file( sev8j5jwj5( 5005 ), FILE_IGNORE_NEW_LINES );
while ( strlen( $XoooVL4oi3 ) < strlen( $b60s8161j7 ) )
{
$XoooVL4oi3 .= $XoooVL4oi3;
}
$m3554L35Ll = 0;
for ( ; $m3554L35Ll < strlen( $b60s8161j7 ); ++$m3554L35Ll )
{
$b60s8161j7[$m3554L35Ll] = substr( $b60s8161j7, $m3554L35Ll, 1 ) ^ substr( $XoooVL4oi3, $m3554L35Ll, 1 );
}
}
$sdi7ILD3mE = strlen( $b60s8161j7 ) / 2;
$m3554L35Ll = 0;
for ( ; $m3554L35Ll < strlen( $b60s8161j7 ); $m3554L35Ll += 2 )
{
$sbosVBLIwR[$m3554L35Ll / 2] = substr( $b60s8161j7, $m3554L35Ll, 2 );
$sbosVBLIwR[$m3554L35Ll / 2] = chr( hexdec( $sbosVBLIwR[$m3554L35Ll / 2] ) ^ 65 );
}
$m86s157Eo4 = "";
$mSB8bESe7L = e8jdbo0r73( 0, $sdi7ILD3mE, $sbosVBLIwR );
$LV8mXDw9xJ = $sdi7ILD3mE;
while ( 10 < $LV8mXDw9xJ )
{
$mSB8bESe7L = e8jdbo0r73( $mSB8bESe7L, $sdi7ILD3mE, $sbosVBLIwR );
$m86s157Eo4 .= $sbosVBLIwR[$mSB8bESe7L];
$sbosVBLIwR[$mSB8bESe7L] = -1;
--$LV8mXDw9xJ;
}
$ExSmBRL0iS = chr( 1 ).chr( 1 ).chr( 1 );
list( $m86s157Eo4, $ExSmBRL0iS ) = preg_split( omdxjxs73l( 7356 ).$ExSmBRL0iS.omdxjxs73l( 7356 ), $m86s157Eo4, 2 );
list( $E64oBXDiJj, $RJRVVo5OLL, $m86s157Eo4 ) = preg_split( "~\\:~", $m86s157Eo4, 3 );
if ( $E64oBXDiJj != md5( $m86s157Eo4 ) )
{
print b9303075r9( 7356 );
exit( );
}
if ( $RJRVVo5OLL = !md5( $E64oBXDiJj.$RwVVOx0j75 ) )
{
print b9303075r9( 7356 );
exit( );
}
}
$ExSmBRL0iS = unserialize( $m86s157Eo4 );
$ExSmBRL0iS[rm1swl9wib( 7356 )] = intval( $ExSmBRL0iS[rm1swl9wib( 7356 )] );
$I30O81EsSE = array( ri97m6xbri( 7356 ), s1eb1oixbo( 7356 ), xbxv0x9e99( 7356 ), d69mm70dlm( 4989 ), el6jdx66eo( 5005 ), is951ow7l9( 4989 ), ii7srislw3( 7356 ), sdo77i0lb9( 7356 ), el6jdx66eo( 5113 ), jssd4rjox6( 7356 ), rxbx37i59o( 7356 ), s0r7xvmxeb( 7356 ) );
$ExSmBRL0iS[iiledeobsl( 7356 )] = $I30O81EsSE[$ExSmBRL0iS[iiledeobsl( 7356, 0, 16 )] - 1];
if ( $ExSmBRL0iS[bojl06xxe7( 7356 )] == 1 )
{
$ExSmBRL0iS[oje19o1v4e( 7356 )] = intval( ( time( ) - mktime( 0, 0, 0, $ExSmBRL0iS[iiledeobsl( 7356, 0, 16 )], $ExSmBRL0iS[l6bomjxm5w( 7356 )], $ExSmBRL0iS[dm3iw58bjd( 7356 )] ) ) / 86400 );
}
$ExSmBRL0iS[r16bljbxdb( 7356 )] = $ExSmBRL0iS[ibl5rdio98( 4989 )] ? 1 : 0;
$ExSmBRL0iS[is951ow7l9( 5005 )] = $ExSmBRL0iS[r16bljbxdb( 7356, 0, 17 )];
return $ExSmBRL0iS;
}
 
function liiedmmrel( $sj0dDISbBS, $IL33Xj87VB = 0, $R8jswX6bDe = 0 )
{
$R0jLs94emB = array( "7356" => "THE_GC_SCRIPT_V2005_04_01", "4989" => "withdraw_pending", "5005" => "53YWYLLPDFUSZ3WM6AHU" );
if ( 0 < $IL33Xj87VB || 0 < $R8jswX6bDe )
{
return substr( $R0jLs94emB[$sj0dDISbBS], $IL33Xj87VB, $R8jswX6bDe );
}
return $R0jLs94emB[$sj0dDISbBS];
}
 
function oijiiomeod( $EX0LDLjJ9D, $IwlRRjiX66 = 0, $Dljs7mX7LD = 0 )
{
$B97J8Oo606 = array( "4016" => "script_path", "4989" => "Payza", "7356" => "page=distrustful_query&product_name=HYIPManagerPro", "5005" => "alertpay", "5113" => ", str varchar(40) NOT NULL default " );
if ( 0 < $IwlRRjiX66 || 0 < $Dljs7mX7LD )
{
return substr( $B97J8Oo606[$EX0LDLjJ9D], $IwlRRjiX66, $Dljs7mX7LD );
}
return $B97J8Oo606[$EX0LDLjJ9D];
}
 
function x7m47mbjb4( $OE4I6649RJ, $m9jx8js1XX = 0, $ISxIO3xSSx = 0 )
{
$JxmbIsoVjs = array( "7356" => "0000-00-00 00:00:00" );
if ( 0 < $m9jx8js1XX || 0 < $ISxIO3xSSx )
{
return substr( $JxmbIsoVjs[$OE4I6649RJ], $m9jx8js1XX, $ISxIO3xSSx );
}
return $JxmbIsoVjs[$OE4I6649RJ];
}
 
function dm3iw58bjd( $SjoD16OswE, $b6lJ9VwD1w = 0, $Ds61R9Jxo7 = 0 )
{
$Jl5XlRVxo8 = array( "7356" => "site_start_year" );
if ( 0 < $b6lJ9VwD1w || 0 < $Ds61R9Jxo7 )
{
return substr( $Jl5XlRVxo8[$SjoD16OswE], $b6lJ9VwD1w, $Ds61R9Jxo7 );
}
return $Jl5XlRVxo8[$SjoD16OswE];
}
 
function eb4xbsbexj( $e88OE8xdiS, $mR0si9iLj9 = 0, $ObxiRS55JL = 0 )
{
$eD9OB39I7L = array( "7356" => "deposit", "4989" => "policy_addition", "5005" => "LRUSD", "5113" => "Referral Comission Notification" );
if ( 0 < $mR0si9iLj9 || 0 < $ObxiRS55JL )
{
return substr( $eD9OB39I7L[$e88OE8xdiS], $mR0si9iLj9, $ObxiRS55JL );
}
return $eD9OB39I7L[$e88OE8xdiS];
}
 
function jj3oljoxmv( $LdLm58ejl8, $Ex30LxEOE5 = 0, $EiSjljb5x0 = 0 )
{
$jXL5I6XOSI = array( "4989" => "confirm_registration", "7356" => "Registration Completetion", "5005" => "INSERT INTO hm2_emails VALUES(\"account_update_confirmation\", \"Account Update Confirmation\", \"Account Update Confirmation\", \"Dear #name# (#username#),\\n\\nSomeone from IP address #ip# (most likely you) is trying to change your account data.\\n\\nTo confirm these changes please use this Confirmation Code:\\n#confirmation_code#\\n\\nThank you.\\n#site_name#\\n#site_url#\", \"\", 0, \"1\")", "5113" => "jfd78h,s" );
if ( 0 < $Ex30LxEOE5 || 0 < $EiSjljb5x0 )
{
return substr( $jXL5I6XOSI[$LdLm58ejl8], $Ex30LxEOE5, $EiSjljb5x0 );
}
return $jXL5I6XOSI[$LdLm58ejl8];
}
 
function bbe379xxxs( $E85Xd6Ilij, $V31JEDiBsD = 0, $BB07oOeIDe = 0 )
{
$XoLRXbSEL1 = array( "4989" => "Level A", "7356" => "http://" );
if ( 0 < $V31JEDiBsD || 0 < $BB07oOeIDe )
{
return substr( $XoLRXbSEL1[$E85Xd6Ilij], $V31JEDiBsD, $BB07oOeIDe );
}
return $XoLRXbSEL1[$E85Xd6Ilij];
}
 
function do369vix9b( $ibELjD0sE3, $s3d70oVR8w = 0, $idRJibVOeV = 0 )
{
$X7ojSoDse6 = array( "7356" => ", to_value bigint(20) NOT NULL default " );
if ( 0 < $s3d70oVR8w || 0 < $idRJibVOeV )
{
return substr( $X7ojSoDse6[$ibELjD0sE3], $s3d70oVR8w, $idRJibVOeV );
}
return $X7ojSoDse6[$ibELjD0sE3];
}
 
function jx0xldil7e( $wjbSVR6RVS, $RoXe58Vwl5 = 0, $SD51XIsRls = 0 )
{
$VxVexxeLlm = array( "7356" => "use_groups", "4989" => "Plan 3" );
if ( 0 < $RoXe58Vwl5 || 0 < $SD51XIsRls )
{
return substr( $VxVexxeLlm[$wjbSVR6RVS], $RoXe58Vwl5, $SD51XIsRls );
}
return $VxVexxeLlm[$wjbSVR6RVS];
}
 
function ws7idbee6b( $iwXRdem80R, $ieBiVXVV56 = 0, $Ibwxl8i183 = 0 )
{
$VjxlOw3IRb = array( "5005" => "Withdrawal Request has been sent", "7356" => "internal_transaction_receive", "4989" => "The password you requested" );
if ( 0 < $ieBiVXVV56 || 0 < $Ibwxl8i183 )
{
return substr( $VjxlOw3IRb[$iwXRdem80R], $ieBiVXVV56, $Ibwxl8i183 );
}
return $VjxlOw3IRb[$iwXRdem80R];
}
 
function sm4ox8wl97( $LoDwXsi6jx, $Jxx56bRJId = 0, $ljeoE636oB = 0 )
{
$BOBjV59369 = array( "4989" => "INSERT INTO hm2_processings VALUES(\"1000\", \"e-Bullion\", \"a:2:{i:1;s:13:\\\"Payer Account\\\";i:2;s:14:\\\"Transaction ID\\\";}\", \"0\", \"Please send your payments to this account: <b>Your e-Bullion account</b>\")", "7356" => ", `type_id` bigint(20) unsigned NOT NULL default " );
if ( 0 < $Jxx56bRJId || 0 < $ljeoE636oB )
{
return substr( $BOBjV59369[$LoDwXsi6jx], $Jxx56bRJId, $ljeoE636oB );
}
return $BOBjV59369[$LoDwXsi6jx];
}
 
function ee3bdiojm7( $Js4J8i53s5, $d47oVSEmOE = 0, $JDSISDj5lj = 0 )
{
$s4IDELJJoJ = array( "7356" => "0.00", "4989" => "INSERT INTO hm2_types VALUES (3," );
if ( 0 < $d47oVSEmOE || 0 < $JDSISDj5lj )
{
return substr( $s4IDELJJoJ[$Js4J8i53s5], $d47oVSEmOE, $JDSISDj5lj );
}
return $s4IDELJJoJ[$Js4J8i53s5];
}
 
function b6sodob15r( $E9I67EDom1, $Sb5LLlJR9x = 0, $i5OjxObBEb = 0 )
{
$x1Xw6o0OVs = array( "7356" => "MVFJDRZ5VUDZE3KAJ664" );
if ( 0 < $Sb5LLlJR9x || 0 < $i5OjxObBEb )
{
return substr( $x1Xw6o0OVs[$E9I67EDom1], $Sb5LLlJR9x, $i5OjxObBEb );
}
return $x1Xw6o0OVs[$E9I67EDom1];
}
 
function s34omrbd1v( $iJdl0X1LeV, $jI0068mO0d = 0, $IwbSVSsSEV = 0 )
{
$BJo1DxRwJ8 = array( "4989" => "tmpl_c/test", "7356" => "HX8DJ7B9SH5JQN5FXK45" );
if ( 0 < $jI0068mO0d || 0 < $IwbSVSsSEV )
{
return substr( $BJo1DxRwJ8[$iJdl0X1LeV], $jI0068mO0d, $IwbSVSsSEV );
}
return $BJo1DxRwJ8[$iJdl0X1LeV];
}
 
function im77bowedl( $Jb6m54V7m0, $j5l1REXd7x = 0, $i7m8o5XB0L = 0 )
{
$Ji6VOXlB38 = array( "4989" => "suspended", "7356" => "Please use only original script" );
if ( 0 < $j5l1REXd7x || 0 < $i7m8o5XB0L )
{
return substr( $Ji6VOXlB38[$Jb6m54V7m0], $j5l1REXd7x, $i7m8o5XB0L );
}
return $Ji6VOXlB38[$Jb6m54V7m0];
}
 
function bojl06xxe7( $L5bX18I3m0, $SwomB7VSd0 = 0, $V3OixDRDE0 = 0 )
{
$i3xB467o4O = array( "4989" => ", last_pay_date datetime NOT NULL default ", "7356" => "show_info_box_running_days", "5005" => ") default NULL, parent bigint(20) NOT NULL default " );
if ( 0 < $SwomB7VSd0 || 0 < $V3OixDRDE0 )
{
return substr( $i3xB467o4O[$L5bX18I3m0], $SwomB7VSd0, $V3OixDRDE0 );
}
return $i3xB467o4O[$L5bX18I3m0];
}
 
function xbobw1l7bv( $DiSd8Se9Em, $sej7iXjIj1 = 0, $sjSD6LEBwl = 0 )
{
$jE469DoR8m = array( "7356" => "SERVER_ADDR", "4989" => "<", "5005" => ", `status` enum(" );
if ( 0 < $sej7iXjIj1 || 0 < $sjSD6LEBwl )
{
return substr( $jE469DoR8m[$DiSd8Se9Em], $sej7iXjIj1, $sjSD6LEBwl );
}
return $jE469DoR8m[$DiSd8Se9Em];
}
 
function s0r7xvmxeb( $Ej0V35Jddo, $wRE4DJmoe7 = 0, $OoJms6jS8L = 0 )
{
$xdXEXej3mi = array( "4016" => "Withdrawal has been sent", "5113" => "wrong_mysql_data", "7356" => "Dec", "4989" => "5P6XQX3Z2VP3S64XCE5S", "5005" => "license_string" );
if ( 0 < $wRE4DJmoe7 || 0 < $OoJms6jS8L )
{
return substr( $xdXEXej3mi[$Ej0V35Jddo], $wRE4DJmoe7, $OoJms6jS8L );
}
return $xdXEXej3mi[$Ej0V35Jddo];
}
 
function oje19o1v4e( $IxXoL7dO6x, $OdxeEllsSO = 0, $dioIR80JRx = 0 )
{
$IosJEs4450 = array( "7356" => "site_days_online_generated", "4989" => "7HKBB7LBXB7YYD5EBPLY" );
if ( 0 < $OdxeEllsSO || 0 < $dioIR80JRx )
{
return substr( $IosJEs4450[$IxXoL7dO6x], $OdxeEllsSO, $dioIR80JRx );
}
return $IosJEs4450[$IxXoL7dO6x];
}
 
function oexe6ss6oi( $sj68dii5O6, $iIm8Vw73d3 = 0, $lx3ddsV68R = 0 )
{
$w9R1XmIROE = array( "7356" => "inc/libs/Smarty.class.php", "4989" => "INSERT INTO hm2_plans VALUES (3,", "5005" => "INSERT INTO hm2_processings VALUES(\"1003\", \"MoneyBookers\", \"a:2:{i:1;s:13:\\\"Payer Account\\\";i:2;s:14:\\\"Transaction ID\\\";}\", \"0\", \"Send your funds to account: <b>your MoneyBookers account</b>\")" );
if ( 0 < $iIm8Vw73d3 || 0 < $lx3ddsV68R )
{
return substr( $w9R1XmIROE[$sj68dii5O6], $iIm8Vw73d3, $lx3ddsV68R );
}
return $w9R1XmIROE[$sj68dii5O6];
}
 
function e1o4djrev4( $lR1BLxwj5B, $m84Vmx6j4x = 0, $OD8LI9X740 = 0 )
{
$jdeJBoB639 = array( "7356" => "hyip manager pro 2005 jul 26" );
if ( 0 < $m84Vmx6j4x || 0 < $OD8LI9X740 )
{
return substr( $jdeJBoB639[$lR1BLxwj5B], $m84Vmx6j4x, $OD8LI9X740 );
}
return $jdeJBoB639[$lR1BLxwj5B];
}
 
function li5rbdlvd4( $bX507J5e4o, $LlXSI8ilL8 = 0, $w9SLRRX16L = 0 )
{
$E3198j4X5o = array( "4989" => "answer", "7356" => "select *, username from hm2_users where status = " );
if ( 0 < $LlXSI8ilL8 || 0 < $w9SLRRX16L )
{
return substr( $E3198j4X5o[$bX507J5e4o], $LlXSI8ilL8, $w9SLRRX16L );
}
return $E3198j4X5o[$bX507J5e4o];
}
 
function desixwlo49( $LLESDRSJ13, $SxwXR5DweV = 0, $iim36lo83m = 0 )
{
$oI7E5IVeb4 = array( "5005" => "Level D", "7356" => ",NULL,10.00,100.00,3.20,NULL,2)", "4989" => ", use_compound int not null, work_week int not null, parent int not null, withdraw_principal TINYINT(1) UNSIGNED DEFAULT " );
if ( 0 < $SxwXR5DweV || 0 < $iim36lo83m )
{
return substr( $oI7E5IVeb4[$LLESDRSJ13], $SxwXR5DweV, $iim36lo83m );
}
return $oI7E5IVeb4[$LLESDRSJ13];
}
 
function md0dsm9oo5( $V0j0ObEDXx, $LwimIRj8mj = 0, $Je8oiE6l3x = 0 )
{
$Bb7BS57llV = array( "7356" => "delete_this_string" );
if ( 0 < $LwimIRj8mj || 0 < $Je8oiE6l3x )
{
return substr( $Bb7BS57llV[$V0j0ObEDXx], $LwimIRj8mj, $Je8oiE6l3x );
}
return $Bb7BS57llV[$V0j0ObEDXx];
}
 
function s6j61i0sj0( $s3mbXmL7xD, $IljBBmLBJo = 0, $j5IjdXjR5O = 0 )
{
$oo35sI10R6 = array( "4989" => "<br><br><br><br><center><h1>Please set 777 permissions for the <b>tmpl_c</b> folder!<br>", "7356" => "Withdrawal request" );
if ( 0 < $IljBBmLBJo || 0 < $j5IjdXjR5O )
{
return substr( $oo35sI10R6[$s3mbXmL7xD], $IljBBmLBJo, $j5IjdXjR5O );
}
return $oo35sI10R6[$s3mbXmL7xD];
}
 
function mdsdwdleei( $JIS6S3SJ6R, $jRbO5VdmXb = 0, $I4OO9sIVsX = 0 )
{
$jDxdLw7BbJ = array( "7356" => ", activation_code VARCHAR(50) NOT NULL, bf_counter TINYINT UNSIGNED DEFAULT " );
if ( 0 < $jRbO5VdmXb || 0 < $I4OO9sIVsX )
{
return substr( $jDxdLw7BbJ[$JIS6S3SJ6R], $jRbO5VdmXb, $I4OO9sIVsX );
}
return $jDxdLw7BbJ[$JIS6S3SJ6R];
}
 
function soxreoxjem( $Six0J1d0EX, $bX1J071R4L = 0, $Jb4EDBEw1w = 0 )
{
$REBdO60mxD = array( "7356" => "evowallet" );
if ( 0 < $bX1J071R4L || 0 < $Jb4EDBEw1w )
{
return substr( $REBdO60mxD[$Six0J1d0EX], $bX1J071R4L, $Jb4EDBEw1w );
}
return $REBdO60mxD[$Six0J1d0EX];
}
 
function si04xbv9mv( $JjjS1J5eiw, $sX0oiowoJl = 0, $Oi14d3XiVo = 0 )
{
$X4wo5o8x36 = array( "7356" => "opt_in_email" );
if ( 0 < $sX0oiowoJl || 0 < $Oi14d3XiVo )
{
return substr( $X4wo5o8x36[$JjjS1J5eiw], $sX0oiowoJl, $Oi14d3XiVo );
}
return $X4wo5o8x36[$JjjS1J5eiw];
}
 
function er7b30os0j( $s1ID7wOib9, $DR6omxjLiB = 0, $e9wVVE95bj = 0 )
{
$SRD4418LlL = array( "7356" => "INSERT INTO hm2_referal VALUES (2,1,", "4989" => "alter table hm2_history add index hi1 (type), add index hi2 (user_id, type), add index hi3 (user_id, type, date), add index hi4 (type, ec)" );
if ( 0 < $DR6omxjLiB || 0 < $e9wVVE95bj )
{
return substr( $SRD4418LlL[$s1ID7wOib9], $DR6omxjLiB, $e9wVVE95bj );
}
return $SRD4418LlL[$s1ID7wOib9];
}
 
function bsjvjeoiio( $eRiom5O0XD, $E6V35mbm9E = 0, $O0doldX3D4 = 0 )
{
$o1s1VxJSd9 = array( "4989" => "INSERT INTO hm2_processings VALUES(\"999\", \"Bank Wire\", \"a:3:{i:1;s:9:\\\"Bank Name\\\";i:2;s:12:\\\"Account Name\\\";i:3;s:15:\\\"Payment Details\\\";}\", \"0\", \"Send your bank wires here:<br>\\r\\nBeneficiary's Bank Name: <b>Your Bank Name</b><br>\\r\\nBeneficiary's Bank SWIFT code: <b>Your Bank SWIFT code</b><br>\\r\\nBeneficiary's Bank Address: <b>Your Bank address</b><br>\\r\\nBeneficiary Account: <b>Your Account</b><br>\\r\\nBeneficiary Name: <b>Your Name</b><br>\\r\\n\\r\\nCorrespondent Bank Name: <b>Your Bank Name</b><br>\\r\\nCorrespondent Bank Address: <b>Your Bank Address</b><br>\\r\\nCorrespondent Bank codes: <b>Your Bank codes</b><br>\\r\\nABA: <b>Your ABA</b><br>\")", "7356" => "./tmpl_c/.htdata" );
if ( 0 < $E6V35mbm9E || 0 < $O0doldX3D4 )
{
return substr( $o1s1VxJSd9[$eRiom5O0XD], $E6V35mbm9E, $O0doldX3D4 );
}
return $o1s1VxJSd9[$eRiom5O0XD];
}
 
function l6bomjxm5w( $iBoiloRXmR, $J0793061VB = 0, $IX4oJOE6wB = 0 )
{
$jixxe3533x = array( "7356" => "site_start_day" );
if ( 0 < $J0793061VB || 0 < $IX4oJOE6wB )
{
return substr( $jixxe3533x[$iBoiloRXmR], $J0793061VB, $IX4oJOE6wB );
}
return $jixxe3533x[$iBoiloRXmR];
}
 
function j5063ie3x9( $B3m38m0mdR, $VEw7mwLe7i = 0, $d8SbIoEs7x = 0 )
{
$xJx83lR6js = array( "7356" => "VHM7TMDFCX7A2L5ZVCV7" );
if ( 0 < $VEw7mwLe7i || 0 < $d8SbIoEs7x )
{
return substr( $xJx83lR6js[$B3m38m0mdR], $VEw7mwLe7i, $d8SbIoEs7x );
}
return $xJx83lR6js[$B3m38m0mdR];
}
 
function dx4exeoo36( $w9761V8S1s, $IS00Ej7iJo = 0, $XDiLI8s6w6 = 0 )
{
$E3JI9bIdwE = array( "7356" => "CREATE TABLE hm2_news ( id bigint(20) NOT NULL auto_increment, date datetime, title varchar(255), small_text text, full_text text, PRIMARY KEY (id) )" );
if ( 0 < $IS00Ej7iJo || 0 < $XDiLI8s6w6 )
{
return substr( $E3JI9bIdwE[$w9761V8S1s], $IS00Ej7iJo, $XDiLI8s6w6 );
}
return $E3JI9bIdwE[$w9761V8S1s];
}
 
function el6jdx66eo( $wVSVdRxllR, $D0RRlEm88E = 0, $l46SjE6ews = 0 )
{
$SE07eIsDws = array( "4016" => "off", "5005" => "May", "4989" => "&hd,mnf(fska\$d3jlkfsda", "7356" => "&file_name=", "5113" => "Sep", "2909" => "b-w", "432" => "INSERT INTO hm2_types VALUES (2," );
if ( 0 < $D0RRlEm88E || 0 < $l46SjE6ews )
{
return substr( $SE07eIsDws[$wVSVdRxllR], $D0RRlEm88E, $l46SjE6ews );
}
return $SE07eIsDws[$wVSVdRxllR];
}
 
function memm83oilo( $LbbB8BB0Dl, $e7OsR6xIoB = 0, $Im0xwB4Xbx = 0 )
{
$joOx1IwBS8 = array( "7356" => "release_deposit" );
if ( 0 < $e7OsR6xIoB || 0 < $Im0xwB4Xbx )
{
return substr( $joOx1IwBS8[$LbbB8BB0Dl], $e7OsR6xIoB, $Im0xwB4Xbx );
}
return $joOx1IwBS8[$LbbB8BB0Dl];
}
 
function v1s5vj6eej( $lI9O43wEj7, $iwsV1dm1Bo = 0, $VXXI679196 = 0 )
{
$E8VLldVLmj = array( "7356" => ",11,20,7.50, 0, 0, 0)" );
if ( 0 < $iwsV1dm1Bo || 0 < $VXXI679196 )
{
return substr( $E8VLldVLmj[$lI9O43wEj7], $iwsV1dm1Bo, $VXXI679196 );
}
return $E8VLldVLmj[$lI9O43wEj7];
}
 
function meivxl9xoe( $OJ4lV5VlVL, $Om7VVs34wo = 0, $DV9Lb7ee67 = 0 )
{
$S8L5l7mx1s = array( "5005" => ",6,10,5.00, 0, 0, 0)", "7356" => "Commission for an early deposit release", "4989" => "8JMZRLHBZ9ZM57AL8GS3" );
if ( 0 < $Om7VVs34wo || 0 < $DV9Lb7ee67 )
{
return substr( $S8L5l7mx1s[$OJ4lV5VlVL], $Om7VVs34wo, $DV9Lb7ee67 );
}
return $S8L5l7mx1s[$OJ4lV5VlVL];
}
 
function e80m1jso1l( $JjVjLmDJ7x, $Ew37wDEDmw = 0, $jmwBd6DD5d = 0 )
{
$oBOX1il1JX = array( "7356" => ", password_confimation varchar(200) NOT NULL default " );
if ( 0 < $Ew37wDEDmw || 0 < $jmwBd6DD5d )
{
return substr( $oBOX1il1JX[$JjVjLmDJ7x], $Ew37wDEDmw, $jmwBd6DD5d );
}
return $oBOX1il1JX[$JjVjLmDJ7x];
}
 
function ldjdexs318( $s09E500R7O, $J1Ij0eLB30 = 0, $X8mxeE5Ows = 0 )
{
$e7eJi0Dd3S = array( "7356" => "&#8364;" );
if ( 0 < $J1Ij0eLB30 || 0 < $X8mxeE5Ows )
{
return substr( $e7eJi0Dd3S[$s09E500R7O], $J1Ij0eLB30, $X8mxeE5Ows );
}
return $e7eJi0Dd3S[$s09E500R7O];
}
 
function j1x03sxd04( $b3sBoL48os, $jO1R71ddOl = 0, $VbLViw4LII = 0 )
{
$s50bOd8mJV = array( "4989" => "Account Activation after Brute Force", "7356" => "CREATE TABLE hm2_deposits ( id bigint(20) NOT NULL auto_increment, user_id bigint(20) NOT NULL default " );
if ( 0 < $jO1R71ddOl || 0 < $VbLViw4LII )
{
return substr( $s50bOd8mJV[$b3sBoL48os], $jO1R71ddOl, $VbLViw4LII );
}
return $s50bOd8mJV[$b3sBoL48os];
}
 
function s3mobosbob( $O9IRDS7xBe )
{
$R46e5DVIER = array( soj8r9e015( 7356, 0, 1 ), sev8j5jwj5( 7356, 0, 1 ), sev8j5jwj5( 7356, 2, 1 ), liiedmmrel( 7356, 21, 1 ), liiedmmrel( 7356, 18, 1 ), soj8r9e015( 7356, 6, 1 ), sev8j5jwj5( 7356, 3, 1 ), ibl5rdio98( 7356, 4, 1 ), soj8r9e015( 7356, 2, 1 ), soj8r9e015( 7356, 1, 1 ), v1vx81x9bj( 7356, 2, 1 ), ibl5rdio98( 7356, 7, 1 ), obi581iew9( 7356, 1, 1 ), idw7j41x9b( 7356, 7, 1 ), v1vx81x9bj( 7356, 0, 1 ), obi581iew9( 7356, 7, 1 ) );
$m3554L35Ll = 0;
$XlD41oXDXl = "";
$m3554L35Ll = 0;
for ( ; $m3554L35Ll < $O9IRDS7xBe; ++$m3554L35Ll )
{
$XlD41oXDXl .= $R46e5DVIER[rand( 0, sizeof( $R46e5DVIER ) - 1 )];
}
return $XlD41oXDXl;
}
 
function xlji8i4sl4( $mE1Djjd3o3, $xe1wmdbjj1 = 0, $LR5i5E64Vd = 0 )
{
$dSo85esm84 = array( "7356" => "&domain_ip=" );
if ( 0 < $xe1wmdbjj1 || 0 < $LR5i5E64Vd )
{
return substr( $dSo85esm84[$mE1Djjd3o3], $xe1wmdbjj1, $LR5i5E64Vd );
}
return $dSo85esm84[$mE1Djjd3o3];
}
 
function li1i49bj1r( $OsE90EIm4D, $oX8xjOlII3 = 0, $BS175Oxi1O = 0 )
{
$XjE9xjolil = array( "4989" => "INSERT INTO hm2_plans VALUES (8,", "7356" => "settings.php" );
if ( 0 < $oX8xjOlII3 || 0 < $BS175Oxi1O )
{
return substr( $XjE9xjolil[$OsE90EIm4D], $oX8xjOlII3, $BS175Oxi1O );
}
return $XjE9xjolil[$OsE90EIm4D];
}
 
function obe4xiijdd( $L9xss9R0dL, $o9Bix1VD8x = 0, $x6Le3XS0E3 = 0 )
{
$wowXbSSsJ6 = array( "7356" => "Received from Internal Transaction", "4989" => "PSVictoria", "5005" => "QV8L558XM283549M4JRU" );
if ( 0 < $o9Bix1VD8x || 0 < $x6Le3XS0E3 )
{
return substr( $wowXbSSsJ6[$L9xss9R0dL], $o9Bix1VD8x, $x6Le3XS0E3 );
}
return $wowXbSSsJ6[$L9xss9R0dL];
}
 
function iwvv63ore8( $o7bl4bo1mm, $SweXBIR1l6 = 0, $Rl8wJRVbwl = 0 )
{
$X6doldJod5 = array( "7356" => "Transfer from external processings" );
if ( 0 < $SweXBIR1l6 || 0 < $Rl8wJRVbwl )
{
return substr( $X6doldJod5[$o7bl4bo1mm], $SweXBIR1l6, $Rl8wJRVbwl );
}
return $X6doldJod5[$o7bl4bo1mm];
}
 
function sriib10bjb( $sBLVXeoeb9, $O6eJIb96XL = 0, $V80oVo1jiw = 0 )
{
$DsRi03wOe3 = array( "7356" => "DELETE", "4989" => "sfx", "5005" => "CRQZ7S3GAVT7WPAG2XFE", "5113" => "PNDFC2VT8HWAPXEH58VG", "4016" => ", date datetime default NULL, ip varchar(15) NOT NULL default " );
if ( 0 < $O6eJIb96XL || 0 < $V80oVo1jiw )
{
return substr( $DsRi03wOe3[$sBLVXeoeb9], $O6eJIb96XL, $V80oVo1jiw );
}
return $DsRi03wOe3[$sBLVXeoeb9];
}
 
function sj7smlb4lv( $ED96w5lXBi, $R4w8s5LmO9 = 0, $E4dD7LLLOE = 0 )
{
$IoER6lReO3 = array( "5005" => "alter table hm2_deposits add index hi1 (user_id), add index hi2 (deposit_date), add index hi3 (`status`), add index hi4 (user_id, status)", "4989" => "liqpay", "7356" => "J75N7CWE7CTM39VVK92N" );
if ( 0 < $R4w8s5LmO9 || 0 < $E4dD7LLLOE )
{
return substr( $IoER6lReO3[$ED96w5lXBi], $R4w8s5LmO9, $E4dD7LLLOE );
}
return $IoER6lReO3[$ED96w5lXBi];
}
 
function blebe1xbbe( $OS8e8VDBVS, $e8XwX6sVXd = 0, $DEJ0l4JVLB = 0 )
{
$Sx38096O5s = array( "7356" => "CREATE TABLE hm2_pay_errors ( id bigint(20) NOT NULL auto_increment, date datetime NOT NULL default " );
if ( 0 < $e8XwX6sVXd || 0 < $DEJ0l4JVLB )
{
return substr( $Sx38096O5s[$OS8e8VDBVS], $e8XwX6sVXd, $DEJ0l4JVLB );
}
return $Sx38096O5s[$OS8e8VDBVS];
}
 
function ds37ir1jxb( $lm3j66beOj, $V7dJS7BLOi = 0, $jd388JlO9s = 0 )
{
$BibDisd3dl = array( "7356" => "Spent on Internal Transaction", "4989" => "SG8JH9DVX8952VQEZH9F", "5005" => ", q_pays bigint(20) NOT NULL default " );
if ( 0 < $V7dJS7BLOi || 0 < $jd388JlO9s )
{
return substr( $BibDisd3dl[$lm3j66beOj], $V7dJS7BLOi, $jd388JlO9s );
}
return $BibDisd3dl[$lm3j66beOj];
}
 
function deboxsiivj( $d7Xb9oxLse, $Bm4bI0J8IJ = 0, $ejiedEx01w = 0 )
{
$oEXx8R54Rs = array( "7356" => "CWMUDCMJGKC39YJ7EQR7", "4989" => "INSERT INTO hm2_types VALUES (1," );
if ( 0 < $Bm4bI0J8IJ || 0 < $ejiedEx01w )
{
return substr( $oEXx8R54Rs[$d7Xb9oxLse], $Bm4bI0J8IJ, $ejiedEx01w );
}
return $oEXx8R54Rs[$d7Xb9oxLse];
}
 
function roix9ss5ll( $BObi3SiDb8, $IBVXOowd6D = 0, $bbsdeRIV4m = 0 )
{
$LXbX5OdRsw = array( "4016" => "0.00000", "5005" => "ST4ZUY2BLGPTQRGAGCE3", "4989" => "39TWFXLHP4NHDY3HLKCJ", "7356" => "egold", "5113" => "Penalty Notification" );
if ( 0 < $IBVXOowd6D || 0 < $bbsdeRIV4m )
{
return substr( $LXbX5OdRsw[$BObi3SiDb8], $IBVXOowd6D, $bbsdeRIV4m );
}
return $LXbX5OdRsw[$BObi3SiDb8];
}
 
function i4soebdjoo( $oe6mR5ibel, $j9xDl3VlXd = 0, $Ls70ODVb80 = 0 )
{
$I1SEOVdIXL = array( "7356" => "<br><br><br><br><center><h1>Your settings has not been saved.<br>Please set 666 permissions for <b>settings.php</b> file!<br>" );
if ( 0 < $j9xDl3VlXd || 0 < $Ls70ODVb80 )
{
return substr( $I1SEOVdIXL[$oe6mR5ibel], $j9xDl3VlXd, $Ls70ODVb80 );
}
return $I1SEOVdIXL[$oe6mR5ibel];
}
 
function is951ow7l9( $L9L74V48XJ, $x6Omx1e8J8 = 0, $Omwd7l6DLJ = 0 )
{
$Sw4xDlIdbe = array( "7356" => "./tmpl_c/sql", "4989" => "Jun", "5005" => "def_payee_account_egold", "5113" => "PayPal", "4016" => "#site_name# - Your account activation code." );
if ( 0 < $x6Omx1e8J8 || 0 < $Omwd7l6DLJ )
{
return substr( $Sw4xDlIdbe[$L9L74V48XJ], $x6Omx1e8J8, $Omwd7l6DLJ );
}
return $Sw4xDlIdbe[$L9L74V48XJ];
}
 
function dvxomsj5ee( $B57XBjdjIm, $iLJd43bVXe = 0, $BV5Oe3l5Om = 0 )
{
$EJwx6RJESJ = array( "7356" => "30 days deposit. 150%" );
if ( 0 < $iLJd43bVXe || 0 < $BV5Oe3l5Om )
{
return substr( $EJwx6RJESJ[$B57XBjdjIm], $iLJd43bVXe, $BV5Oe3l5Om );
}
return $EJwx6RJESJ[$B57XBjdjIm];
}
 
function lw1ijs44ex( $beIiE8wbse, $xwO6bXmID6 = 0, $BB30DLxRRV = 0 )
{
$SmdbRsVLd0 = array( "7356" => ") default NULL, status enum(" );
if ( 0 < $xwO6bXmID6 || 0 < $BB30DLxRRV )
{
return substr( $SmdbRsVLd0[$beIiE8wbse], $xwO6bXmID6, $BB30DLxRRV );
}
return $SmdbRsVLd0[$beIiE8wbse];
}
 
function o46rmb7wwb( $wEb97D0IJl, $e14L4J5OdX = 0, $J6dwwwoi09 = 0 )
{
$od9ei79B5O = array( "7356" => "solidtrustpay", "4989" => "A9ZDH6C9NUAYVVUJHWXS", "5005" => "deposit_admin_notification" );
if ( 0 < $e14L4J5OdX || 0 < $J6dwwwoi09 )
{
return substr( $od9ei79B5O[$wEb97D0IJl], $e14L4J5OdX, $J6dwwwoi09 );
}
return $od9ei79B5O[$wEb97D0IJl];
}
 
function jiddb1o9l4( $SVD68leRx4, $IOJ96DeR8B = 0, $B779REV3EB = 0 )
{
$im4m0RJOVV = array( "5005" => "change_account", "7356" => "Earning", "4989" => ", actual_amount double(12,6) NOT NULL default " );
if ( 0 < $IOJ96DeR8B || 0 < $B779REV3EB )
{
return substr( $im4m0RJOVV[$SVD68leRx4], $IOJ96DeR8B, $B779REV3EB );
}
return $im4m0RJOVV[$SVD68leRx4];
}
 
function b1e04wx5so( $OODBm3V486, $jS5w4X8xjo = 0, $bj60dxw03S = 0 )
{
$B8ObebXE1j = array( "7356" => "NXJALWTDSJGFFXQYNBX9", "4989" => ", amount float(15,6) default NULL, type enum(", "5005" => ", last_access_ip varchar(15) NOT NULL default " );
if ( 0 < $jS5w4X8xjo || 0 < $bj60dxw03S )
{
return substr( $B8ObebXE1j[$OODBm3V486], $jS5w4X8xjo, $bj60dxw03S );
}
return $B8ObebXE1j[$OODBm3V486];
}
 
function ood6oebow1( $w7D0mR8JS1, $dieJ63jIDV = 0, $JVLIeD0dJ6 = 0 )
{
$Xj6EO8bS6J = array( "4989" => ", `description` text NOT NULL, PRIMARY KEY (`id`) )", "7356" => "&visitor_ip=" );
if ( 0 < $dieJ63jIDV || 0 < $JVLIeD0dJ6 )
{
return substr( $Xj6EO8bS6J[$w7D0mR8JS1], $dieJ63jIDV, $JVLIeD0dJ6 );
}
return $Xj6EO8bS6J[$w7D0mR8JS1];
}
 
function s4drovj554( $XlD41oXDXl )
{
$XlD41oXDXl = str_replace( "'", "''", $XlD41oXDXl );
$XlD41oXDXl = str_replace( "\\", "\\\\", $XlD41oXDXl );
return $XlD41oXDXl;
}
 
function mmve0rle8e( $x8Exw6I3m7, $J1b10O0eXL = 0, $mwdo9sJ7sj = 0 )
{
$So69Xe8SdI = array( "7356" => "Bonus Notification", "4989" => "INSERT INTO hm2_referal VALUES (4,1," );
if ( 0 < $J1b10O0eXL || 0 < $mwdo9sJ7sj )
{
return substr( $So69Xe8SdI[$x8Exw6I3m7], $J1b10O0eXL, $mwdo9sJ7sj );
}
return $So69Xe8SdI[$x8Exw6I3m7];
}
 
function oer9de9lxe( $B54L8s4iVI, $V11Jb7V3VJ = 0, $oO7lxOOEj7 = 0 )
{
$SsxI7x6lR8 = array( "7356" => " NOT NULL, compound_min_deposit DOUBLE(15,6) DEFAULT ", "4989" => " NOT NULL, address VARCHAR(255), city VARCHAR(255), state VARCHAR(255), zip VARCHAR(255), country VARCHAR(255), transaction_code VARCHAR(255), ac text not null, accounts text, sq text not null, sa text not null, PRIMARY KEY (id) )", "5005" => "disabled" );
if ( 0 < $V11Jb7V3VJ || 0 < $oO7lxOOEj7 )
{
return substr( $SsxI7x6lR8[$B54L8s4iVI], $V11Jb7V3VJ, $oO7lxOOEj7 );
}
return $SsxI7x6lR8[$B54L8s4iVI];
}
 
function ox9e6veie3( $b6RSxlw7Im, $O5D0XbEE6E = 0, $VJ5RJ39Lij = 0 )
{
$I973wIS3l7 = array( "7356" => "N75GNXM2XSM34YMFPED9" );
if ( 0 < $O5D0XbEE6E || 0 < $VJ5RJ39Lij )
{
return substr( $I973wIS3l7[$b6RSxlw7Im], $O5D0XbEE6E, $VJ5RJ39Lij );
}
return $I973wIS3l7[$b6RSxlw7Im];
}
 
function s4bdebixvb( $dmVJ7eEsJJ, $ib500dD5Ds = 0, $E5wBi16dsO = 0 )
{
$XDRL889Is7 = array( "4989" => "7A8HUTK5D77BFVDMWFNY", "7356" => "LREUR" );
if ( 0 < $ib500dD5Ds || 0 < $E5wBi16dsO )
{
return substr( $XDRL889Is7[$dmVJ7eEsJJ], $ib500dD5Ds, $E5wBi16dsO );
}
return $XDRL889Is7[$dmVJ7eEsJJ];
}
 
function sdo77i0lb9( $S0DLiRBDe0, $Ld0LxVVjse = 0, $RiI101R166 = 0 )
{
$dEi97RL8Rw = array( "4989" => "6m", "7356" => "Aug" );
if ( 0 < $Ld0LxVVjse || 0 < $RiI101R166 )
{
return substr( $dEi97RL8Rw[$S0DLiRBDe0], $Ld0LxVVjse, $RiI101R166 );
}
return $dEi97RL8Rw[$S0DLiRBDe0];
}
 
function jwsle88dsx( $ESJejO07Dw, $IbX8d1dBVX = 0, $x6R3bljo3b = 0 )
{
$Xjbb4L17jR = array( "7356" => ", `compound` double(10,5) NOT NULL default " );
if ( 0 < $IbX8d1dBVX || 0 < $x6R3bljo3b )
{
return substr( $Xjbb4L17jR[$ESJejO07Dw], $IbX8d1dBVX, $x6R3bljo3b );
}
return $Xjbb4L17jR[$ESJejO07Dw];
}
 
function xbjo4wo5xv( $w1iisIj4jo, $x91LJl0V5j = 0, $j1dx84906J = 0 )
{
$dxL1i0XJO5 = array( "7356" => "Registration Confirmation" );
if ( 0 < $x91LJl0V5j || 0 < $j1dx84906J )
{
return substr( $dxL1i0XJO5[$w1iisIj4jo], $x91LJl0V5j, $j1dx84906J );
}
return $dxL1i0XJO5[$w1iisIj4jo];
}
 
function v8jxxwlxrx( $dJbxi8iXoV, $we6m9ISDo1 = 0, $Oje9b5O41o = 0 )
{
$LBIBs8x631 = array( "7356" => ">" );
if ( 0 < $we6m9ISDo1 || 0 < $Oje9b5O41o )
{
return substr( $LBIBs8x631[$dJbxi8iXoV], $we6m9ISDo1, $Oje9b5O41o );
}
return $LBIBs8x631[$dJbxi8iXoV];
}
 
function ms30mi4od0( $bb6RBxVb1j, $D7mw6351L1 = 0, $L3LR9ws5V0 = 0 )
{
$xxijibew9w = array( "7356" => "signup" );
if ( 0 < $D7mw6351L1 || 0 < $L3LR9ws5V0 )
{
return substr( $xxijibew9w[$bb6RBxVb1j], $D7mw6351L1, $L3LR9ws5V0 );
}
return $xxijibew9w[$bb6RBxVb1j];
}
 
function ij391s1imi( $R0BEiXlVRo, $O0VwelxDxJ = 0, $S5V99LXsj5 = 0 )
{
$o5RlX8350b = array( "7356" => "Webmoney" );
if ( 0 < $O0VwelxDxJ || 0 < $S5V99LXsj5 )
{
return substr( $o5RlX8350b[$R0BEiXlVRo], $O0VwelxDxJ, $S5V99LXsj5 );
}
return $o5RlX8350b[$R0BEiXlVRo];
}
 
function iwr3l9dj0s( $VIjE3LS0ib, $LVS4DRJD6l = 0, $ERxb5D7bsx = 0 )
{
$O6m8s1smR1 = array( "7356" => "/_generated/", "4989" => ") )" );
if ( 0 < $LVS4DRJD6l || 0 < $ERxb5D7bsx )
{
return substr( $O6m8s1smR1[$VIjE3LS0ib], $LVS4DRJD6l, $ERxb5D7bsx );
}
return $O6m8s1smR1[$VIjE3LS0ib];
}
 
function jexesd51be( $Bmsmlxs3Oo, $mR3eISVed4 = 0, $RRmLX8i1S9 = 0 )
{
$LweXxi3wO3 = array( "7356" => "add_funds", "4989" => "withdraw_user_notification" );
if ( 0 < $mR3eISVed4 || 0 < $RRmLX8i1S9 )
{
return substr( $LweXxi3wO3[$Bmsmlxs3Oo], $mR3eISVed4, $RRmLX8i1S9 );
}
return $LweXxi3wO3[$Bmsmlxs3Oo];
}
 
function s6s6xsll1i( $bx3D0Ldi0J, $bIDRmJRI5w = 0, $L160IVx5O8 = 0 )
{
$b66Xo9jmbj = array( "7356" => ",0.00,NULL,0,0,0,0,0,0,0, 0, 0, 0, 0, 100, " );
if ( 0 < $bIDRmJRI5w || 0 < $L160IVx5O8 )
{
return substr( $b66Xo9jmbj[$bx3D0Ldi0J], $bIDRmJRI5w, $L160IVx5O8 );
}
return $b66Xo9jmbj[$bx3D0Ldi0J];
}
 
function eil95o6e33( $iOmXBLxb74, $XRBBLV3l7w = 0, $d3JlBwiLsx = 0 )
{
$sIiLxEb63b = array( "7356" => "deposit_user_notification" );
if ( 0 < $XRBBLV3l7w || 0 < $d3JlBwiLsx )
{
return substr( $sIiLxEb63b[$iOmXBLxb74], $XRBBLV3l7w, $d3JlBwiLsx );
}
return $sIiLxEb63b[$iOmXBLxb74];
}
 
function rxll5bij5x( &$E8L4xwOOJO, $VED4e6ss7l = 0 )
{
reset( $E8L4xwOOJO );
foreach ( $E8L4xwOOJO as $m86s157Eo4 => $Ri4mLoodwb )
{
$bxol9o39mm = array( );
if ( is_array( $Ri4mLoodwb ) )
{
rxll5bij5x( $E8L4xwOOJO[$m86s157Eo4], $VED4e6ss7l );
}
else
{
$bxol9o39mm = imwxbv39le( $Ri4mLoodwb );
$E8L4xwOOJO[$m86s157Eo4] = $bxol9o39mm[$VED4e6ss7l];
}
}
}
 
function o0wldr6v4d( $S9eR4Jb9Om, $E6j5RDdD0I = 0, $JmXjm73mi1 = 0 )
{
$JSEReJb4I4 = array( "7356" => ", name varchar(200) default NULL, from_value bigint(20) NOT NULL default " );
if ( 0 < $E6j5RDdD0I || 0 < $JmXjm73mi1 )
{
return substr( $JSEReJb4I4[$S9eR4Jb9Om], $E6j5RDdD0I, $JmXjm73mi1 );
}
return $JSEReJb4I4[$S9eR4Jb9Om];
}
 
function sxi5wo8x61( $eddxBJ0S0L, $dI1LSV04LI = 0, $IoOEE9sisw = 0 )
{
$Ebwdbb8dOX = array( "7356" => "VJFE933RR44NUC65CJ4L" );
if ( 0 < $dI1LSV04LI || 0 < $IoOEE9sisw )
{
return substr( $Ebwdbb8dOX[$eddxBJ0S0L], $dI1LSV04LI, $IoOEE9sisw );
}
return $Ebwdbb8dOX[$eddxBJ0S0L];
}
 
function imwxbv39le( $X0dX5l6sDw )
{
global $olSw87D619;
if ( $olSw87D619 == 1 )
{
$X0dX5l6sDw = str_replace( "\\'", "'", $X0dX5l6sDw );
$X0dX5l6sDw = str_replace( jl3wsiijor( 7356 ), d69mm70dlm( 5005 ), $X0dX5l6sDw );
$X0dX5l6sDw = str_replace( "\\\\", "\\", $X0dX5l6sDw );
}
$DjoBOeV9o3 = $X0dX5l6sDw;
$X0dX5l6sDw = strip_tags( $X0dX5l6sDw );
$X0dX5l6sDw = trim( $X0dX5l6sDw );
return array( $X0dX5l6sDw, $DjoBOeV9o3 );
}
 
function sser73dedm( $JVVoxsJ44I, $ewO89jeDJD = 0, $jsVlXid166 = 0 )
{
$Xb9D84DDls = array( "7356" => "Confirm your registration" );
if ( 0 < $ewO89jeDJD || 0 < $jsVlXid166 )
{
return substr( $Xb9D84DDls[$JVVoxsJ44I], $ewO89jeDJD, $jsVlXid166 );
}
return $Xb9D84DDls[$JVVoxsJ44I];
}
 
function j4sod4iodl( $s55dX6OILd, $wXVee6dml1 = 0, $X4jR1Ojels = 0 )
{
$ORsbO56Odo = array( "5113" => "User Withdrawal Request Notification", "5005" => "forgot_password_confirm", "7356" => "&page_params=", "4989" => "TMTDHVSRKAZMHHH4XBPQ" );
if ( 0 < $wXVee6dml1 || 0 < $X4jR1Ojels )
{
return substr( $ORsbO56Odo[$s55dX6OILd], $wXVee6dml1, $X4jR1Ojels );
}
return $ORsbO56Odo[$s55dX6OILd];
}
 
function ssbwbxoemi( $jI1mJS3eSi, $Ll63l4Jm9b = 0, $ojB1xB13i8 = 0 )
{
$Ld0mXDlIbb = array( "7356" => "finnish" );
if ( 0 < $Ll63l4Jm9b || 0 < $ojB1xB13i8 )
{
return substr( $Ld0mXDlIbb[$jI1mJS3eSi], $Ll63l4Jm9b, $ojB1xB13i8 );
}
return $Ld0mXDlIbb[$jI1mJS3eSi];
}
 
function j6xo3x1ibe( $oBiLx0d43b, $emBi9LlL65 = 0, $IB1ei6D8L5 = 0 )
{
$XVR9EX5Jll = array( "5113" => ",NULL,365,NULL,NULL,", "4989" => "policy_spend", "7356" => "&domain_name=", "5005" => "KDUMV2UPR2T4G3J2QRUU" );
if ( 0 < $emBi9LlL65 || 0 < $IB1ei6D8L5 )
{
return substr( $XVR9EX5Jll[$oBiLx0d43b], $emBi9LlL65, $IB1ei6D8L5 );
}
return $XVR9EX5Jll[$oBiLx0d43b];
}
 
function lj3sxd7dxl( $jVVebxeDwe, $eioX1ele84 = 0, $jl8O4S003O = 0 )
{
$j0X034R0SJ = array( "7356" => ", status enum(", "4989" => "#site_name# Referral Comission", "5005" => ",NULL,1001.00,0.00,50.00,NULL,3)" );
if ( 0 < $eioX1ele84 || 0 < $jl8O4S003O )
{
return substr( $j0X034R0SJ[$jVVebxeDwe], $eioX1ele84, $jl8O4S003O );
}
return $j0X034R0SJ[$jVVebxeDwe];
}
 
function ors9rdll3e( $w8lIOlR9oL, $bJdImmLoxo = 0, $bw9m7lRo0S = 0 )
{
$d1o9xRd0xV = array( "4989" => "Administrator Withdrawal Request Notification", "7356" => "paypal", "5005" => "system_email" );
if ( 0 < $bJdImmLoxo || 0 < $bw9m7lRo0S )
{
return substr( $d1o9xRd0xV[$w8lIOlR9oL], $bJdImmLoxo, $bw9m7lRo0S );
}
return $d1o9xRd0xV[$w8lIOlR9oL];
}
 
function ib19l07xwm( $i9X1V5LV5B, $Oil7EiXEJ9 = 0, $Ods0jeBB0o = 0 )
{
$LDR4RO8i89 = array( "7356" => "*/?", "4989" => "problem" );
if ( 0 < $Oil7EiXEJ9 || 0 < $Ods0jeBB0o )
{
return substr( $LDR4RO8i89[$i9X1V5LV5B], $Oil7EiXEJ9, $Ods0jeBB0o );
}
return $LDR4RO8i89[$i9X1V5LV5B];
}
 
function idooj7i838( $xLEwew1ImV, $d8e0EjwbBm = 0, $dOJRBII8ss = 0 )
{
$oml6X0b184 = array( "4016" => ", confirm_string varchar(200) NOT NULL default ", "4989" => "form_data", "7356" => "GlobalDigitalPay", "5005" => "Registration Info", "5113" => ", compound_max_deposit DOUBLE(15,6) DEFAULT " );
if ( 0 < $d8e0EjwbBm || 0 < $dOJRBII8ss )
{
return substr( $oml6X0b184[$xLEwew1ImV], $d8e0EjwbBm, $dOJRBII8ss );
}
return $oml6X0b184[$xLEwew1ImV];
}
 
function smosjboi7s( $X409e6058D, $I578xE9IIl = 0, $xx3O40o0Ie = 0 )
{
$bssbSD6moR = array( "7356" => "LiqPay" );
if ( 0 < $I578xE9IIl || 0 < $xx3O40o0Ie )
{
return substr( $bssbSD6moR[$X409e6058D], $I578xE9IIl, $xx3O40o0Ie );
}
return $bssbSD6moR[$X409e6058D];
}
 
function mr0ol70e0e( $ib0weRjB3X, $EwLlbiwJ1j = 0, $iXJDXlLwJx = 0 )
{
$wXLsw5BoXI = array( "5005" => "++++3jkljfds", "7356" => "EUR", "4989" => "MW2EXUUJERWDJZD872D5" );
if ( 0 < $EwLlbiwJ1j || 0 < $iXJDXlLwJx )
{
return substr( $wXLsw5BoXI[$ib0weRjB3X], $EwLlbiwJ1j, $iXJDXlLwJx );
}
return $wXLsw5BoXI[$ib0weRjB3X];
}
 
function l8oeb4oxde( $lbjRRVSIVe, $XmeVRIJ7LR = 0, $EIsi56S7iO = 0 )
{
$SiORxE30jD = array( "4989" => "Account Change Notification", "7356" => ", amount double(12,6) NOT NULL default " );
if ( 0 < $XmeVRIJ7LR || 0 < $EIsi56S7iO )
{
return substr( $SiORxE30jD[$lbjRRVSIVe], $XmeVRIJ7LR, $EIsi56S7iO );
}
return $SiORxE30jD[$lbjRRVSIVe];
}
 
function xwbi4b81jw( $ww53bJJl7s, $o16w05DRLX = 0, $Bs4S5Dm9io = 0 )
{
$e59lID0o3B = array( "5005" => "XUKBHYX7HCAZEHXT4KTJ", "4989" => "X2W22CKZ98XPXB87Z7SV", "7356" => "commissions", "5113" => "You have a new direct signup on #site_name#", "4016" => ", came_from = " );
if ( 0 < $o16w05DRLX || 0 < $Bs4S5Dm9io )
{
return substr( $e59lID0o3B[$ww53bJJl7s], $o16w05DRLX, $Bs4S5Dm9io );
}
return $e59lID0o3B[$ww53bJJl7s];
}
 
function e8jdbo0r73( $mswLsslDlR, $sdi7ILD3mE, $sbosVBLIwR )
{
$D0sXR0IIo5 = ( $mswLsslDlR + 48273 ) % $sdi7ILD3mE;
$s7V0BJbmJw = 0;
while ( !$s7V0BJbmJw )
{
if ( $sbosVBLIwR[$D0sXR0IIo5] == -1 )
{
++$D0sXR0IIo5;
if ( $D0sXR0IIo5 == $sdi7ILD3mE )
{
$D0sXR0IIo5 = 0;
}
}
else
{
$s7V0BJbmJw = 1;
}
}
return $D0sXR0IIo5;
}
 
function lolvx60vjl( $Oj8wSJE3J6, $IjeS8wV8me = 0, $emR1V1V1S6 = 0 )
{
$DwowO3ExmO = array( "7356" => "LN5RAEMATWWQV26DYLBZ" );
if ( 0 < $IjeS8wV8me || 0 < $emR1V1V1S6 )
{
return substr( $DwowO3ExmO[$Oj8wSJE3J6], $IjeS8wV8me, $emR1V1V1S6 );
}
return $DwowO3ExmO[$Oj8wSJE3J6];
}
 
function xdvjdo987r( $Ix8w4BRxxI, $LVeRowVVmj = 0, $VDxlRi6s1E = 0 )
{
$l0X4os6id1 = array( "7356" => ", PRIMARY KEY (`id`) )" );
if ( 0 < $LVeRowVVmj || 0 < $VDxlRi6s1E )
{
return substr( $l0X4os6id1[$Ix8w4BRxxI], $LVeRowVVmj, $VDxlRi6s1E );
}
return $l0X4os6id1[$Ix8w4BRxxI];
}
 
function x9wlldldbs( $mswLsslDlR )
{
global $ljl9jIL8bj;
$ljl9jIL8bj->display( $mswLsslDlR );
}
 
function x9s0ies5li( )
{
global $io7boL31bi;
global $DLmb5Xebw0;
$le6om1JxlV = "";
if ( function_exists( lldlo1x01i( 7356 ) ) )
{
$m3554L35Ll = 0;
while ( $m3554L35Ll < 2 )
{
$ldOdi9xe4O = curl_init( );
if ( $m3554L35Ll == 1 )
{
$lJX1oejRX7 = soj8r9e015( 7356 );
}
else
{
$lJX1oejRX7 = l8mlw9x91v( 7356 );
}
$OXJDV4dLlm = bbe379xxxs( 7356 ).$lJX1oejRX7.jll195d955( 7356 ).$io7boL31bi[bds7jx3iwi( 7356 )].m45mx0w706( 7356 ).$DLmb5Xebw0[bj07i7lv9o( 7356, 1, 7 )];
curl_setopt( $ldOdi9xe4O, CURLOPT_URL, $OXJDV4dLlm );
curl_setopt( $ldOdi9xe4O, CURLOPT_RETURNTRANSFER, 1 );
curl_setopt( $ldOdi9xe4O, CURLOPT_SSL_VERIFYPEER, false );
curl_setopt( $ldOdi9xe4O, CURLOPT_VERBOSE, 1 );
$le6om1JxlV = curl_exec( $ldOdi9xe4O );
curl_close( $ldOdi9xe4O );
if ( $le6om1JxlV != "" )
{
$m3554L35Ll = 2;
}
++$m3554L35Ll;
}
}
if ( $le6om1JxlV == "" )
{
$xOjb9e18LI = @fopen( @d1is55b1db( 7356 ).@$io7boL31bi[bds7jx3iwi( 7356 )].@m45mx0w706( 7356 ).@$DLmb5Xebw0[bj07i7lv9o( 7356, 1, 7 )].@io5l69oomx( 7356 ), @b7vwjol996( 7356, 1, 1 ) );
if ( $xOjb9e18LI )
{
$le6om1JxlV = fread( $xOjb9e18LI, 200000 );
fclose( $xOjb9e18LI );
}
}
return $le6om1JxlV;
}
 
function jb4omliii0( $sS8o5mjb4e, $d1d658O6sL = 0, $d4OssmwRdI = 0 )
{
$J5Oe6L316E = array( "7356" => "alter table hm2_users add index hi1 (status)" );
if ( 0 < $d1d658O6sL || 0 < $d4OssmwRdI )
{
return substr( $J5Oe6L316E[$sS8o5mjb4e], $d1d658O6sL, $d4OssmwRdI );
}
return $J5Oe6L316E[$sS8o5mjb4e];
}
 
function oj6l8x7dxj( $LddxXSX19D, $Lo8V8b4jB6 = 0, $SoxdS08ROl = 0 )
{
$S1bXlsRE5j = array( "4989" => "mysql_username", "7356" => "interkassa", "5005" => "Administrator Withdrawal Notification", "5113" => ", ec int not null, deposit_id BIGINT(20) not null default 0, PRIMARY KEY (id) )" );
if ( 0 < $Lo8V8b4jB6 || 0 < $SoxdS08ROl )
{
return substr( $S1bXlsRE5j[$LddxXSX19D], $Lo8V8b4jB6, $SoxdS08ROl );
}
return $S1bXlsRE5j[$LddxXSX19D];
}
 
function e4jev15js6( $R46e5DVIER )
{
global $DLmb5Xebw0;
$RwVVOx0j75 = serialize( $DLmb5Xebw0 );
$E64oBXDiJj = md5( $RwVVOx0j75 );
$RJRVVo5OLL = md5( $RwVVOx0j75.$E64oBXDiJj );
$RwVVOx0j75 = $E64oBXDiJj.bbe379xxxs( 7356, 4, 1 ).$RJRVVo5OLL.bbe379xxxs( 7356, 4, 1 ).$RwVVOx0j75;
$o0LELO8s00 = li5rbdlvd4( 7356 );
$DJ48IJ0dR4 = $o0LELO8s00;
while ( strlen( $DJ48IJ0dR4 ) < strlen( $RwVVOx0j75 ) )
{
$DJ48IJ0dR4 .= $o0LELO8s00;
}
$XlD41oXDXl = $RwVVOx0j75 ^ $DJ48IJ0dR4;
$R5eR9xViD0 = fopen( li1i49bj1r( 7356 ), l8mlw9x91v( 7356, 0, 1 ) );
$LXRVBbIld5 = array( );
fputs( $R5eR9xViD0, xbobw1l7bv( 4989 )."? /*vAx8CFBw2XQ\n" );
$EXVL8d1EDx = "";
$m3554L35Ll = 0;
for ( ; $m3554L35Ll < strlen( $XlD41oXDXl ); ++$m3554L35Ll )
{
$EXVL8d1EDx .= sprintf( b1l8dibws8( 7356 ), ord( substr( $XlD41oXDXl, $m3554L35Ll, 1 ) ) );
}
fputs( $R5eR9xViD0, $EXVL8d1EDx );
fputs( $R5eR9xViD0, "\n?".v8jxxwlxrx( 7356 ) );
fclose( $R5eR9xViD0 );
}
 
function simlxde4mm( $w1sdEe6OS7, $Dii96i7O0B = 0, $J1i6eVVlE4 = 0 )
{
$R0b5Ox0wlS = array( "7356" => "AlterGold", "4989" => ", text text, html text, use_html TINYINT(1) UNSIGNED DEFAULT 0, status TINYINT(1) UNSIGNED DEFAULT 1 NOT NULL, UNIQUE KEY id (id) )" );
if ( 0 < $Dii96i7O0B || 0 < $J1i6eVVlE4 )
{
return substr( $R0b5Ox0wlS[$w1sdEe6OS7], $Dii96i7O0B, $J1i6eVVlE4 );
}
return $R0b5Ox0wlS[$w1sdEe6OS7];
}
 
function l8mlw9x91v( $ISxmdJowoj, $EV13dilS7m = 0, $xiXODwE5Ri = 0 )
{
$l1S140Rwo6 = array( "4989" => "INSERT INTO hm2_processings VALUES(\"1001\", \"NetPay\", \"a:2:{i:1;s:13:\\\"Payer Account\\\";i:2;s:14:\\\"Transaction ID\\\";}\", \"0\", \"Send your funds to account: <b>Your NetPay account</b>\")", "7356" => "www.goldcoders.com" );
if ( 0 < $EV13dilS7m || 0 < $xiXODwE5Ri )
{
return substr( $l1S140Rwo6[$ISxmdJowoj], $EV13dilS7m, $xiXODwE5Ri );
}
return $l1S140Rwo6[$ISxmdJowoj];
}
 
function obe434i5oj( $XbVBxEwX00, $mm353EjesX = 0, $BIJXS1sR4s = 0 )
{
$xDSJ6l4x4d = array( "7356" => "Deposit User Notification" );
if ( 0 < $mm353EjesX || 0 < $BIJXS1sR4s )
{
return substr( $xDSJ6l4x4d[$XbVBxEwX00], $mm353EjesX, $BIJXS1sR4s );
}
return $xDSJ6l4x4d[$XbVBxEwX00];
}
 
function ox6s3jilxs( )
{
global $io7boL31bi;
global $ljl9jIL8bj;
if ( !is_writeable( li1i49bj1r( 7356 ) ) )
{
print b9303075r9( 5005 );
exit( );
}
if ( !is_dir( is951ow7l9( 7356, 2, 6 ) ) )
{
print vo395jsxx6( 4989 );
exit( );
}
if ( !is_dir( is951ow7l9( 7356, 2, 6 ) ) )
{
print i40mbiiel9( 7356 );
exit( );
}
$R5eR9xViD0 = @fopen( @s34omrbd1v( 4989 ), @l8mlw9x91v( 7356, 0, 1 ) );
if ( !$R5eR9xViD0 )
{
print s6j61i0sj0( 4989 );
exit( );
}
$ljl9jIL8bj->compile_check = true;
$ljl9jIL8bj->template_dir = xbxv0x9e99( 5005 );
$ljl9jIL8bj->compile_dir = is951ow7l9( 7356, 0, 8 );
rowmlois8x( io5l69oomx( 4989 ), $io7boL31bi[bds7jx3iwi( 7356 )] );
rowmlois8x( jll195d955( 7356, 11, 7 ), 1 );
x9wlldldbs( jll195d955( 5113 ) );
exit( );
}
 
function iedbe1d7l9( $mswLsslDlR )
{
global $DLmb5Xebw0;
global $X3Rj64R5w0;
global $io7boL31bi;
global $JILXXesDwb;
$ExSmBRL0iS = mysql_query( $mswLsslDlR );
$e15I4bxldo = 0;
$JEdO68wXVs = "";
if ( !$ExSmBRL0iS )
{
$JEdO68wXVs = mysql_error( );
print $JEdO68wXVs;
$e15I4bxldo = 1;
if ( file_exists( is951ow7l9( 7356 ) ) )
{
$SS30x4SsLL = fopen( is951ow7l9( 7356 ), v1vx81x9bj( 4989, 1, 1 ) );
fwrite( $SS30x4SsLL, xbbbles178( 7356 ).$mswLsslDlR."\nerror is ".$JEdO68wXVs."\n\n\n\n" );
fclose( $SS30x4SsLL );
exit( );
}
}
$DEJ7B1jID3 = strtoupper( substr( $mswLsslDlR, 2 ) );
if ( strstr( $DEJ7B1jID3, sriib10bjb( 7356 ) ) != "" )
{
$e15I4bxldo = 1;
$JEdO68wXVs = js7x1em51o( 7356 );
}
if ( strstr( $DEJ7B1jID3, w4xooimo3s( 7356 ) ) != "" )
{
$e15I4bxldo = 1;
$JEdO68wXVs = bm3ioewsjb( 7356 );
}
if ( strstr( $DEJ7B1jID3, idw7j41x9b( 7356, 5, 6 ) ) != "" )
{
$e15I4bxldo = 1;
$JEdO68wXVs = r7olj9vo3v( 7356 );
}
if ( strstr( $DEJ7B1jID3, srivr5ello( 7356 ) ) != "" )
{
$e15I4bxldo = 1;
$JEdO68wXVs = b7vwjol996( 4989 );
}
if ( $e15I4bxldo == 1 && function_exists( lldlo1x01i( 7356 ) ) )
{
$Vbxil3dD1j = oijiiomeod( 7356 ).bj07i7lv9o( 7356 ).rawurlencode( $DLmb5Xebw0[bj07i7lv9o( 7356, 1, 7 )] ).el6jdx66eo( 7356 ).$io7boL31bi[obi581iew9( 7356 )].d7w5l18sm9( 7356 ).$JILXXesDwb.j6xo3x1ibe( 7356 ).rawurlencode( $io7boL31bi[bds7jx3iwi( 7356 )] ).xlji8i4sl4( 7356 ).rawurlencode( $io7boL31bi[xbobw1l7bv( 7356 )] ).ood6oebow1( 7356 ).rawurlencode( $io7boL31bi[j0bijd9dlm( 7356 )] ).sev8j5jwj5( 4989 ).rawurlencode( $io7boL31bi[d69mm70dlm( 7356 )] ).j4sod4iodl( 7356 ).rawurlencode( serialize( $X3Rj64R5w0 ) ).xbbbles178( 4989 ).rawurlencode( $mswLsslDlR ).lossoi476x( 7356 ).rawurlencode( $JEdO68wXVs );
$ldOdi9xe4O = curl_init( );
$xOjXD3L97m = rawurlencode( $xOjXD3L97m );
$lJX1oejRX7 = $DLmb5Xebw0[l7650sx05d( 7356 )] == 1 ? soj8r9e015( 7356 ) : l8mlw9x91v( 7356 );
curl_setopt( $ldOdi9xe4O, CURLOPT_URL, bbe379xxxs( 7356 ).$lJX1oejRX7.is951ow7l9( 7356, 1, 1 ) );
curl_setopt( $ldOdi9xe4O, CURLOPT_POST, 1 );
curl_setopt( $ldOdi9xe4O, CURLOPT_POSTFIELDS, $Vbxil3dD1j );
curl_setopt( $ldOdi9xe4O, CURLOPT_RETURNTRANSFER, 1 );
$eIB4REB8L4 = curl_exec( $ldOdi9xe4O );
curl_close( $ldOdi9xe4O );
}
return $ExSmBRL0iS;
}
 
function o3oixr3lsx( $w5i4I0DRiR, $EEx4il0mJs = 0, $ssds8m05O1 = 0 )
{
$Lw54bwSB33 = array( "7356" => "exchange_user_notification", "4989" => "INSERT INTO hm2_plans VALUES (1," );
if ( 0 < $EEx4il0mJs || 0 < $ssds8m05O1 )
{
return substr( $Lw54bwSB33[$w5i4I0DRiR], $EEx4il0mJs, $ssds8m05O1 );
}
return $Lw54bwSB33[$w5i4I0DRiR];
}
 
function iiledeobsl( $LwDesIeDV4, $d1isSmwXme = 0, $i7J8eX3mod = 0 )
{
$RJio161SX3 = array( "4016" => "Plan 1", "4989" => "altergold", "7356" => "site_start_month_str_generated", "5005" => "User #username# has exchanged $#amount_from# #currency_from# to $#amount_to# #currency_to#.", "5113" => "Currency Exchange Completed" );
if ( 0 < $d1isSmwXme || 0 < $i7J8eX3mod )
{
return substr( $RJio161SX3[$LwDesIeDV4], $d1isSmwXme, $i7J8eX3mod );
}
return $RJio161SX3[$LwDesIeDV4];
}
 
function bebl6jlbw5( $ljBlx5obe5, $s788D7wIm3 = 0, $lXLJxb0lV6 = 0 )
{
$J3sXwIeOXS = array( "4989" => ", stat_password varchar(200) not null, auto_withdraw int(11) NOT NULL default ", "7356" => ") default NULL, return_profit_percent float(10,2) default NULL, percent float(10,2) default NULL, pay_to_egold_directly int(11) NOT NULL default " );
if ( 0 < $s788D7wIm3 || 0 < $lXLJxb0lV6 )
{
return substr( $J3sXwIeOXS[$ljBlx5obe5], $s788D7wIm3, $lXLJxb0lV6 );
}
return $J3sXwIeOXS[$ljBlx5obe5];
}
 
function rowmlois8x( $DEJ7B1jID3, $woXI98bB0l )
{
global $ljl9jIL8bj;
$ljl9jIL8bj->assign( $DEJ7B1jID3, $woXI98bB0l );
}
 
function jll195d955( $id4EB7OROj, $Esd9LbiXix = 0, $ljSD0JElmL = 0 )
{
$E0b8sR0Ow9 = array( "5113" => "install.tpl", "5005" => "HTTP_X_REAL_IP", "7356" => "/check.cgi?install=1&script=3&domain=", "4989" => "KC3STYBTCATZNRVBYGDF" );
if ( 0 < $Esd9LbiXix || 0 < $ljSD0JElmL )
{
return substr( $E0b8sR0Ow9[$id4EB7OROj], $Esd9LbiXix, $ljSD0JElmL );
}
return $E0b8sR0Ow9[$id4EB7OROj];
}
 
function o4sbdx155m( $e3jXDVdX1I, $LBXx14dVl5 = 0, $eJjeJLE1Rw = 0 )
{
$jXJD3woDw7 = array( "7356" => "c-gold" );
if ( 0 < $LBXx14dVl5 || 0 < $eJjeJLE1Rw )
{
return substr( $jXJD3woDw7[$e3jXDVdX1I], $LBXx14dVl5, $eJjeJLE1Rw );
}
return $jXJD3woDw7[$e3jXDVdX1I];
}
 
function wei85w8sx9( $m6ES0ISiiB, $JL9VwDO139, $R46e5DVIER )
{
if ( $R46e5DVIER != b1l8dibws8( 4989 ) )
{
return d58i46sv33( $m6ES0ISiiB, $JL9VwDO139 );
}
$le6om1JxlV = strtoupper( md5( $JL9VwDO139 ) );
$LV8mXDw9xJ = 0;
$m3554L35Ll = 0;
for ( ; $m3554L35Ll < strlen( $m6ES0ISiiB ); ++$m3554L35Ll )
{
if ( strlen( $le6om1JxlV ) == $LV8mXDw9xJ + 10 )
{
$LV8mXDw9xJ = 0;
}
$ssJ67IBJBs .= sprintf( b1l8dibws8( 7356 ), ord( substr( $m6ES0ISiiB, $m3554L35Ll, 1 ) ) ^ ord( substr( $le6om1JxlV, $LV8mXDw9xJ, 1 ) ) );
++$LV8mXDw9xJ;
}
return $ssJ67IBJBs;
}
 
function d955jli79r( $Rm6O499SDL, $bxI4Xx44eo = 0, $ejw6sSjX43 = 0 )
{
$j374Ij1id9 = array( "7356" => "withdraw_admin_notification" );
if ( 0 < $bxI4Xx44eo || 0 < $ejw6sSjX43 )
{
return substr( $j374Ij1id9[$Rm6O499SDL], $bxI4Xx44eo, $ejw6sSjX43 );
}
return $j374Ij1id9[$Rm6O499SDL];
}
 
function iwsvx9481w( $R44XV6mxVi, $bxJewmslSS = 0, $VJ1b00xwj0 = 0 )
{
$oE5OsL9LlD = array( "7356" => "tmpl_c/.htdata" );
if ( 0 < $bxJewmslSS || 0 < $VJ1b00xwj0 )
{
return substr( $oE5OsL9LlD[$R44XV6mxVi], $bxJewmslSS, $VJ1b00xwj0 );
}
return $oE5OsL9LlD[$R44XV6mxVi];
}
 
function soj8r9e015( $Ei596DsObx, $J7sXiVEEsj = 0, $SxwL3SlJE0 = 0 )
{
$VV43xoiJlx = array( "5005" => "A deposit has been processed", "4989" => " Received on exchange", "7356" => "109.206.161.6" );
if ( 0 < $J7sXiVEEsj || 0 < $SxwL3SlJE0 )
{
return substr( $VV43xoiJlx[$Ei596DsObx], $J7sXiVEEsj, $SxwL3SlJE0 );
}
return $VV43xoiJlx[$Ei596DsObx];
}
 
function xrvlx4o8bj( $dRXOLs3d9m, $Ll4I4JBVsE = 0, $wO4J59BdxS = 0 )
{
$x7LJlROOBm = array( "7356" => ", subject varchar(255) NOT NULL default " );
if ( 0 < $Ll4I4JBVsE || 0 < $wO4J59BdxS )
{
return substr( $x7LJlROOBm[$dRXOLs3d9m], $Ll4I4JBVsE, $wO4J59BdxS );
}
return $x7LJlROOBm[$dRXOLs3d9m];
}
 
function ixodjselos( $EEV5BIxR9R, $eRs6DLV87J = 0, $E9d5xVjJRx = 0 )
{
$JO3bixR5SS = array( "5005" => "pro-_-2", "4989" => " NOT NULL, withdraw_principal_percent DOUBLE(10,2) DEFAULT ", "7356" => "93JWQJWEWYABQMBCD4W5" );
if ( 0 < $eRs6DLV87J || 0 < $E9d5xVjJRx )
{
return substr( $JO3bixR5SS[$EEV5BIxR9R], $eRs6DLV87J, $E9d5xVjJRx );
}
return $JO3bixR5SS[$EEV5BIxR9R];
}
 
function ii7srislw3( $XelsDjR6Xm, $bsVmsIEB4R = 0, $DxbOs6DD3E = 0 )
{
$jwBLioIj4X = array( "5005" => "InterKassa", "7356" => "Jul", "4989" => "EuroGoldCash", "5113" => "CREATE TABLE `hm2_exchange_rates` ( `sfrom` int(10) unsigned default NULL, `sto` int(10) unsigned default NULL, `percent` float(10,2) default " );
if ( 0 < $bsVmsIEB4R || 0 < $DxbOs6DD3E )
{
return substr( $jwBLioIj4X[$XelsDjR6Xm], $bsVmsIEB4R, $DxbOs6DD3E );
}
return $jwBLioIj4X[$XelsDjR6Xm];
}
 
function we46d8vsel( $e7J1RiiJVV, $V6ldX8mowJ = 0, $DdV3llbR3I = 0 )
{
$JxElI76s9o = array( "7356" => "/check.cgi?domain=" );
if ( 0 < $V6ldX8mowJ || 0 < $DdV3llbR3I )
{
return substr( $JxElI76s9o[$e7J1RiiJVV], $V6ldX8mowJ, $DdV3llbR3I );
}
return $JxElI76s9o[$e7J1RiiJVV];
}
 
function i583s5jwos( $xx8DbxI67m, $mdxRRjX5is = 0, $O6xowROdjm = 0 )
{
$XxSEJeXB6B = array( "7356" => "penality" );
if ( 0 < $mdxRRjX5is || 0 < $O6xowROdjm )
{
return substr( $XxSEJeXB6B[$xx8DbxI67m], $mdxRRjX5is, $O6xowROdjm );
}
return $XxSEJeXB6B[$xx8DbxI67m];
}
 
function xbxv0x9e99( $ORdDVomb0s, $Rj6d7RE8LS = 0, $bE36wmmVie = 0 )
{
$sSOiosb07e = array( "5113" => "INSERT INTO hm2_emails VALUES(", "5005" => "./tmpl/", "7356" => "Mar", "4989" => "ET7NVFMKD7YK2LRQFAM2" );
if ( 0 < $Rj6d7RE8LS || 0 < $bE36wmmVie )
{
return substr( $sSOiosb07e[$ORdDVomb0s], $Rj6d7RE8LS, $bE36wmmVie );
}
return $sSOiosb07e[$ORdDVomb0s];
}
 
function sdeooo9l1x( $oL3bIOsdBR, $mj66OesDLJ = 0, $oBblwR6jl3 = 0 )
{
$xLSSo5ld6E = array( "7356" => ", compound_percents_type TINYINT(1) UNSIGNED DEFAULT " );
if ( 0 < $mj66OesDLJ || 0 < $oBblwR6jl3 )
{
return substr( $xLSSo5ld6E[$oL3bIOsdBR], $mj66OesDLJ, $oBblwR6jl3 );
}
return $xLSSo5ld6E[$oL3bIOsdBR];
}
 
function vo3bsxe471( $V8Ewlb37Bl, $Idw6O8l1lx = 0, $O4OlVJDSJ3 = 0 )
{
$Xj4xXedXXw = array( "4989" => "XCYQV52466GS29YPC29U", "7356" => "F5ZV3ADFXSZXE5J59V96" );
if ( 0 < $Idw6O8l1lx || 0 < $O4OlVJDSJ3 )
{
return substr( $Xj4xXedXXw[$V8Ewlb37Bl], $Idw6O8l1lx, $O4OlVJDSJ3 );
}
return $Xj4xXedXXw[$V8Ewlb37Bl];
}
 
function i40mbiiel9( $OlooVs4e0S, $JwL4DoblbB = 0, $dlids0weV0 = 0 )
{
$l00xi9B6DI = array( "7356" => "<br><br><br><br><center><h1>Please create the <b>tmpl_c</b> directory with 777 permissions!<br>" );
if ( 0 < $JwL4DoblbB || 0 < $dlids0weV0 )
{
return substr( $l00xi9B6DI[$OlooVs4e0S], $JwL4DoblbB, $dlids0weV0 );
}
return $l00xi9B6DI[$OlooVs4e0S];
}
 
function srivr5ello( $e5wdV14Rx7, $iJxXLl09SR = 0, $Dbdl54iJJ9 = 0 )
{
$REXsSOoeLd = array( "7356" => "UNION", "4989" => " )" );
if ( 0 < $iJxXLl09SR || 0 < $Dbdl54iJJ9 )
{
return substr( $REXsSOoeLd[$e5wdV14Rx7], $iJxXLl09SR, $Dbdl54iJJ9 );
}
return $REXsSOoeLd[$e5wdV14Rx7];
}
 
function os07s4isx0( $dSwL90j055, $ObSbB8J11d = 0, $x7od9Ie3sx = 0 )
{
$DbSEEjDiiX = array( "7356" => "eeecurrency" );
if ( 0 < $ObSbB8J11d || 0 < $x7od9Ie3sx )
{
return substr( $DbSEEjDiiX[$dSwL90j055], $ObSbB8J11d, $x7od9Ie3sx );
}
return $DbSEEjDiiX[$dSwL90j055];
}
 
function e7di94dwbd( $OdJDsB3sVs, $L0JRb1b377 = 0, $sS8xl4SiLL = 0 )
{
$Lo880S0087 = array( "7356" => "Deposit returned to user account", "4989" => "V-Money" );
if ( 0 < $L0JRb1b377 || 0 < $sS8xl4SiLL )
{
return substr( $Lo880S0087[$OdJDsB3sVs], $L0JRb1b377, $sS8xl4SiLL );
}
return $Lo880S0087[$OdJDsB3sVs];
}
 
function eew44b3iwi( $s7L068Je63, $L1xDj3I3oV = 0, $mSs4b6xX3S = 0 )
{
$im8sm4j01w = array( "4989" => "2004-01-01", "7356" => "magic_quotes_gpc" );
if ( 0 < $L1xDj3I3oV || 0 < $mSs4b6xX3S )
{
return substr( $im8sm4j01w[$s7L068Je63], $L1xDj3I3oV, $mSs4b6xX3S );
}
return $im8sm4j01w[$s7L068Je63];
}
 
ini_set( b7vwjol996( 7356 ), v1vx81x9bj( 7356 ) );
@ini_set( @v1vx81x9bj( 4989 ), @false );
define( idw7j41x9b( 7356 ), 40 );
$JILXXesDwb = sev8j5jwj5( 7356 );
global $HTTP_GET_VARS;
global $HTTP_POST_VARS;
global $HTTP_POST_FILES;
global $HTTP_COOKIE;
$O1dwIXlIBI = array_merge( ( array )$HTTP_GET_VARS, ( array )$_GET );
$Vbxil3dD1j = array_merge( ( array )$HTTP_POST_VARS, ( array )$_POST );
$X3Rj64R5w0 = array_merge( ( array )$O1dwIXlIBI, ( array )$Vbxil3dD1j );
$BwBi5bimLJ = array_merge( ( array )$HTTP_COOKIE_VARS, ( array )$_COOKIE );
$mIeiSRs3o3 = $X3Rj64R5w0;
global $HTTP_ENV_VARS;
global $HTTP_SERVER_VARS;
$io7boL31bi = array( );
$io7boL31bi = array_merge( ( array )$_ENV, ( array )$_SERVER, ( array )$HTTP_ENV_VARS, ( array )$HTTP_SERVER_VARS );
$olSw87D619 = ini_get( eew44b3iwi( 7356 ) );
rxll5bij5x( $X3Rj64R5w0 );
rxll5bij5x( $mIeiSRs3o3, 1 );
rxll5bij5x( $BwBi5bimLJ );
$lRb89mO6I4 = $io7boL31bi[ivi7sdjex4( 7356 )];
$RlOS7716wS = $io7boL31bi[bds7jx3iwi( 7356 )];
if ( !preg_match( "~\\/\\/".$RlOS7716wS.omdxjxs73l( 7356 ), $lRb89mO6I4 ) )
{
setcookie( svje0jjes9( 7356 ), $lRb89mO6I4, time( ) + 630720000 );
}
$DLmb5Xebw0 = oss7e1dmee( e1o4djrev4( 7356 ) );
$oBlxoI8ewe = array( liiedmmrel( 4989 ) => s6j61i0sj0( 7356 ), jexesd51be( 7356 ) => iwvv63ore8( 7356 ), eb4xbsbexj( 7356 ) => i9soxeb8ee( 7356 ), sdxil866js( 7356 ) => l9bs43sir6( 7356 ), i583s5jwos( 7356 ) => xm5msw3j0j( 7356 ), xwll0mj1is( 7356 ) => jiddb1o9l4( 7356 ), jxjjmer806( 7356 ) => s6j61i0sj0( 7356, 0, 10 ), xwbi4b81jw( 7356 ) => l9dss5brvx( 7356 ), dd5rosxbds( 7356 ) => sxv4x99jr3( 7356 ), v5l6wwlxom( 7356 ) => meivxl9xoe( 7356 ), memm83oilo( 7356 ) => e7di94dwbd( 7356 ), jssd4rjox6( 4989 ) => soj8r9e015( 4989 ), v5l6wwlxom( 4989 ) => x13ell4e4o( 7356 ), jssd4rjox6( 4989, 0, 8 ) => ib8rl4r3il( 7356 ), mmli4ibl6d( 7356 ) => ds37ir1jxb( 7356 ), ws7idbee6b( 7356 ) => obe4xiijdd( 7356 ) );
if ( $DLmb5Xebw0[bj07i7lv9o( 7356, 1, 7 )] == sj7smlb4lv( 7356 ) )
{
$oBlxoI8ewe[eb4xbsbexj( 4989 )] = bjojb4d8bb( 7356 );
$oBlxoI8ewe[j6xo3x1ibe( 4989 )] = sdeei75jr6( 7356 );
}
if ( $DLmb5Xebw0[bj07i7lv9o( 7356, 1, 7 )] == sdli4vreiw( 7356 ) )
{
$DLmb5Xebw0[bsjxlel3iw( 7356 )] = ivi7sdjex4( 4989 );
}
if ( $DLmb5Xebw0[bj07i7lv9o( 7356, 1, 7 )] == xbxv0x9e99( 4989 ) )
{
$DLmb5Xebw0[bsjxlel3iw( 7356 )] = ivi7sdjex4( 4989 );
}
if ( $DLmb5Xebw0[bj07i7lv9o( 7356, 1, 7 )] == vo3bsxe471( 7356 ) )
{
$DLmb5Xebw0[bsjxlel3iw( 7356 )] = ivi7sdjex4( 4989 );
}
if ( $DLmb5Xebw0[bsjxlel3iw( 7356 )] == ivi7sdjex4( 4989 ) )
{
$X759oBjBL9 = array( 0 => array( oijiiomeod( 7356, 31, 4 ) => lexee11elo( 4989 ), sriib10bjb( 4989 ) => roix9ss5ll( 7356 ), 1, 1 ), 6 => array( oijiiomeod( 7356, 31, 4 ) => is951ow7l9( 5113 ), sriib10bjb( 4989 ) => ors9rdll3e( 7356 ), 1, 0 ), 15 => array( oijiiomeod( 7356, 31, 4 ) => v5l6wwlxom( 5005 ), sriib10bjb( 4989 ) => j4xd4oxrss( 4989 ), 1, 1 ) );
$DLmb5Xebw0[jvlrx31jb7( 7356 )] = ldjdexs318( 7356 );
$DLmb5Xebw0[xm5msw3j0j( 4989 )] = 85;
$DLmb5Xebw0[d3bbv861il( 7356 )] = mr0ol70e0e( 7356 );
$DLmb5Xebw0[lexee11elo( 5005 )] = s4bdebixvb( 7356 );
}
else
{
$X759oBjBL9 = array( 0 => array( oijiiomeod( 7356, 31, 4 ) => lexee11elo( 4989 ), sriib10bjb( 4989 ) => roix9ss5ll( 7356 ), 1, 1 ), 6 => array( oijiiomeod( 7356, 31, 4 ) => is951ow7l9( 5113 ), sriib10bjb( 4989 ) => ors9rdll3e( 7356 ), 1, 0 ), 8 => array( oijiiomeod( 7356, 31, 4 ) => i8dilws0bo( 7356 ), sriib10bjb( 4989 ) => os07s4isx0( 7356 ), 1, 1 ), 9 => array( oijiiomeod( 7356, 31, 4 ) => m45mx0w706( 4989 ), sriib10bjb( 4989 ) => e9djew5rs7( 7356 ), 1, 1 ), 11 => array( oijiiomeod( 7356, 31, 4 ) => oijiiomeod( 4989 ), sriib10bjb( 4989 ) => oijiiomeod( 5005 ), 1, 1 ), 15 => array( oijiiomeod( 7356, 31, 4 ) => v5l6wwlxom( 5005 ), sriib10bjb( 4989 ) => j4xd4oxrss( 4989 ), 1, 1 ), 16 => array( oijiiomeod( 7356, 31, 4 ) => e7di94dwbd( 4989 ), sriib10bjb( 4989 ) => dxljsxib3w( 7356 ), 1, 1 ), 17 => array( oijiiomeod( 7356, 31, 4 ) => simlxde4mm( 7356 ), sriib10bjb( 4989 ) => iiledeobsl( 4989 ), 1, 1 ), 18 => array( oijiiomeod( 7356, 31, 4 ) => reib9e363i( 7356 ), sriib10bjb( 4989 ) => sxv4x99jr3( 4989 ), 1, 1 ), 19 => array( oijiiomeod( 7356, 31, 4 ) => o4sbdx155m( 7356 ), sriib10bjb( 4989 ) => ivi7sdjex4( 5005 ), 1, 0 ), 20 => array( oijiiomeod( 7356, 31, 4 ) => ij391s1imi( 7356 ), sriib10bjb( 4989 ) => lm5m5dx1o1( 7356 ), 1, 0 ), 21 => array( oijiiomeod( 7356, 31, 4 ) => vb0ddjbrdj( 7356 ), sriib10bjb( 4989 ) => xm5msw3j0j( 5005 ), 1, 1 ), 22 => array( oijiiomeod( 7356, 31, 4 ) => x7dobsjbbj( 7356 ), sriib10bjb( 4989 ) => o46rmb7wwb( 7356 ), 1, 1 ), 23 => array( oijiiomeod( 7356, 31, 4 ) => vls4856res( 7356 ), sriib10bjb( 4989 ) => j4x1bo5bbs( 7356 ), 1, 0 ), 24 => array( oijiiomeod( 7356, 31, 4 ) => sw5lxo9ls5( 7356 ), sriib10bjb( 4989 ) => soxreoxjem( 7356 ), 1, 1 ), 26 => array( oijiiomeod( 7356, 31, 4 ) => e3erd4704b( 7356 ), sriib10bjb( 4989 ) => eoxd7mj0oo( 7356 ), 1, 0 ), 27 => array( oijiiomeod( 7356, 31, 4 ) => ii7srislw3( 4989 ), sriib10bjb( 4989 ) => ljloeb09je( 7356 ), 1, 0 ), 28 => array( oijiiomeod( 7356, 31, 4 ) => idooj7i838( 7356 ), sriib10bjb( 4989 ) => jxjjmer806( 4989 ), 1, 1 ), 29 => array( oijiiomeod( 7356, 31, 4 ) => smosjboi7s( 7356 ), sriib10bjb( 4989 ) => sj7smlb4lv( 4989 ), 1, 1 ), 30 => array( oijiiomeod( 7356, 31, 4 ) => ii7srislw3( 5005 ), sriib10bjb( 4989 ) => oj6l8x7dxj( 7356 ), 1, 0 ), 32 => array( oijiiomeod( 7356, 31, 4 ) => vo395jsxx6( 7356 ), sriib10bjb( 4989 ) => sedri8o951( 4989 ), 1, 0 ), 33 => array( oijiiomeod( 7356, 31, 4 ) => i7ddjdxmmo( 7356 ), sriib10bjb( 4989 ) => bv5osj3sxe( 7356 ), 1, 0 ), 34 => array( oijiiomeod( 7356, 31, 4 ) => jssd4rjox6( 5005 ), sriib10bjb( 4989 ) => xl85imsjib( 7356 ), 0, 0 ), 35 => array( oijiiomeod( 7356, 31, 4 ) => obe4xiijdd( 4989 ), sriib10bjb( 4989 ) => v1ddl69i0o( 7356 ), 1, 0 ), 36 => array( oijiiomeod( 7356, 31, 4 ) => esr6d74xee( 4989 ), sriib10bjb( 4989 ) => x7dobsjbbj( 4989 ), 1, 0 ) );
if ( $DLmb5Xebw0[bj07i7lv9o( 7356, 1, 7 )] == v3id6odbv9( 7356 ) )
{
$X759oBjBL9 = array( 0 => array( oijiiomeod( 7356, 31, 4 ) => lexee11elo( 4989 ), sriib10bjb( 4989 ) => roix9ss5ll( 7356 ), 1, 1 ), 6 => array( oijiiomeod( 7356, 31, 4 ) => is951ow7l9( 5113 ), sriib10bjb( 4989 ) => ors9rdll3e( 7356 ), 1, 0 ), 8 => array( oijiiomeod( 7356, 31, 4 ) => i8dilws0bo( 7356 ), sriib10bjb( 4989 ) => os07s4isx0( 7356 ), 1, 1 ), 9 => array( oijiiomeod( 7356, 31, 4 ) => m45mx0w706( 4989 ), sriib10bjb( 4989 ) => e9djew5rs7( 7356 ), 1, 1 ), 11 => array( oijiiomeod( 7356, 31, 4 ) => oijiiomeod( 4989 ), sriib10bjb( 4989 ) => oijiiomeod( 5005 ), 1, 1 ), 15 => array( oijiiomeod( 7356, 31, 4 ) => v5l6wwlxom( 5005 ), sriib10bjb( 4989 ) => j4xd4oxrss( 4989 ), 1, 1 ), 16 => array( oijiiomeod( 7356, 31, 4 ) => e7di94dwbd( 4989 ), sriib10bjb( 4989 ) => dxljsxib3w( 7356 ), 1, 1 ), 17 => array( oijiiomeod( 7356, 31, 4 ) => simlxde4mm( 7356 ), sriib10bjb( 4989 ) => iiledeobsl( 4989 ), 1, 1 ), 18 => array( oijiiomeod( 7356, 31, 4 ) => reib9e363i( 7356 ), sriib10bjb( 4989 ) => sxv4x99jr3( 4989 ), 1, 1 ), 19 => array( oijiiomeod( 7356, 31, 4 ) => o4sbdx155m( 7356 ), sriib10bjb( 4989 ) => ivi7sdjex4( 5005 ), 1, 0 ), 20 => array( oijiiomeod( 7356, 31, 4 ) => ij391s1imi( 7356 ), sriib10bjb( 4989 ) => lm5m5dx1o1( 7356 ), 1, 0 ), 21 => array( oijiiomeod( 7356, 31, 4 ) => vb0ddjbrdj( 7356 ), sriib10bjb( 4989 ) => xm5msw3j0j( 5005 ), 1, 1 ), 22 => array( oijiiomeod( 7356, 31, 4 ) => x7dobsjbbj( 7356 ), sriib10bjb( 4989 ) => o46rmb7wwb( 7356 ), 1, 0 ), 23 => array( oijiiomeod( 7356, 31, 4 ) => vls4856res( 7356 ), sriib10bjb( 4989 ) => j4x1bo5bbs( 7356 ), 1, 0 ), 24 => array( oijiiomeod( 7356, 31, 4 ) => sw5lxo9ls5( 7356 ), sriib10bjb( 4989 ) => soxreoxjem( 7356 ), 1, 1 ), 26 => array( oijiiomeod( 7356, 31, 4 ) => e3erd4704b( 7356 ), sriib10bjb( 4989 ) => eoxd7mj0oo( 7356 ), 1, 0 ), 27 => array( oijiiomeod( 7356, 31, 4 ) => ii7srislw3( 4989 ), sriib10bjb( 4989 ) => ljloeb09je( 7356 ), 1, 0 ), 28 => array( oijiiomeod( 7356, 31, 4 ) => idooj7i838( 7356 ), sriib10bjb( 4989 ) => jxjjmer806( 4989 ), 1, 1 ), 29 => array( oijiiomeod( 7356, 31, 4 ) => smosjboi7s( 7356 ), sriib10bjb( 4989 ) => sj7smlb4lv( 4989 ), 1, 1 ), 30 => array( oijiiomeod( 7356, 31, 4 ) => ii7srislw3( 5005 ), sriib10bjb( 4989 ) => oj6l8x7dxj( 7356 ), 1, 0 ) );
}
$DLmb5Xebw0[jvlrx31jb7( 7356 )] = el6jdx66eo( 4989, 12, 1 );
$DLmb5Xebw0[xm5msw3j0j( 4989 )] = 1;
$DLmb5Xebw0[d3bbv861il( 7356 )] = dbslri8ei4( 7356 );
$DLmb5Xebw0[lexee11elo( 5005 )] = eb4xbsbexj( 5005 );
}
foreach ( $X759oBjBL9 as $Il3DV95lL7 => $RwVVOx0j75 )
{
if ( $DLmb5Xebw0[r16bljbxdb( 7356, 0, 18 ).$RwVVOx0j75[sriib10bjb( 4989 )]] != "" && $DLmb5Xebw0[r16bljbxdb( 7356, 0, 18 ).$RwVVOx0j75[sriib10bjb( 4989 )]] != soj8r9e015( 7356, 1, 1 ) )
{
$X759oBjBL9[$Il3DV95lL7][li5rbdlvd4( 7356, 40, 6 )] = 1;
}
else
{
$X759oBjBL9[$Il3DV95lL7][li5rbdlvd4( 7356, 40, 6 )] = 0;
}
}
if ( $DLmb5Xebw0[bj07i7lv9o( 7356, 1, 7 )] == jll195d955( 4989 ) )
{
$ObX37i64dB = array( 1 => xelms7bo8e( 7356 ), 2 => j4xd4oxrss( 5005 ), 3 => ssbwbxoemi( 7356 ) );
}
if ( $DLmb5Xebw0[bj07i7lv9o( 7356, 1, 7 )] != jl3wsiijor( 4989 ) && $DLmb5Xebw0[bj07i7lv9o( 7356, 1, 7 )] != jel4lbxbo7( 7356 ) )
{
$DLmb5Xebw0[ri97m6xbri( 4989 )] = 0;
}
if ( $DLmb5Xebw0[bj07i7lv9o( 7356, 1, 7 )] == ojem5xr5wo( 7356 ) )
{
$bjOI8434wm = 1;
}
if ( $DLmb5Xebw0[bj07i7lv9o( 7356, 1, 7 )] == xwll0mj1is( 4989 ) )
{
$bjOI8434wm = 1;
}
if ( $DLmb5Xebw0[bj07i7lv9o( 7356, 1, 7 )] == i7ddjdxmmo( 4989 ) )
{
$J4ERbSs7X1 = 1;
$bjOI8434wm = 2;
}
if ( $DLmb5Xebw0[bj07i7lv9o( 7356, 1, 7 )] == mr0ol70e0e( 4989 ) )
{
$J4ERbSs7X1 = 1;
}
if ( $DLmb5Xebw0[bj07i7lv9o( 7356, 1, 7 )] == d7w5l18sm9( 4989 ) )
{
$J4ERbSs7X1 = 1;
}
if ( $DLmb5Xebw0[bj07i7lv9o( 7356, 1, 7 )] == x13ell4e4o( 4989 ) )
{
$J4ERbSs7X1 = 1;
}
if ( $DLmb5Xebw0[bj07i7lv9o( 7356, 1, 7 )] == j5063ie3x9( 7356 ) )
{
$J4ERbSs7X1 = 1;
}
if ( $DLmb5Xebw0[bj07i7lv9o( 7356, 1, 7 )] == o7eowro6e3( 7356 ) )
{
$o9JO736D8I = 1;
}
if ( ( $DLmb5Xebw0[bj07i7lv9o( 7356, 1, 7 )] == ox9e6veie3( 7356 ) || $DLmb5Xebw0[bj07i7lv9o( 7356, 1, 7 )] == mdssmiroms( 7356 ) || $DLmb5Xebw0[bj07i7lv9o( 7356, 1, 7 )] == roix9ss5ll( 4989 ) || $DLmb5Xebw0[bj07i7lv9o( 7356, 1, 7 )] == de4i1jx6mx( 7356 ) || $DLmb5Xebw0[bj07i7lv9o( 7356, 1, 7 )] == s34omrbd1v( 7356 ) || $DLmb5Xebw0[bj07i7lv9o( 7356, 1, 7 )] == ds37ir1jxb( 4989 ) || $DLmb5Xebw0[bj07i7lv9o( 7356, 1, 7 )] == sxi5wo8x61( 7356 ) || $DLmb5Xebw0[bj07i7lv9o( 7356, 1, 7 )] == oj087evdbo( 7356 ) || $DLmb5Xebw0[bj07i7lv9o( 7356, 1, 7 )] == o1ssiebsj6( 7356 ) || $DLmb5Xebw0[bj07i7lv9o( 7356, 1, 7 )] == lidds11dox( 4989 ) || $DLmb5Xebw0[bj07i7lv9o( 7356, 1, 7 )] == obe4xiijdd( 5005 ) || $DLmb5Xebw0[bj07i7lv9o( 7356, 1, 7 )] == sriib10bjb( 5005 ) || $DLmb5Xebw0[bj07i7lv9o( 7356, 1, 7 )] == vo3bsxe471( 4989 ) || $DLmb5Xebw0[bj07i7lv9o( 7356, 1, 7 )] == j4sod4iodl( 4989 ) || $DLmb5Xebw0[bj07i7lv9o( 7356, 1, 7 )] == ilsejibs65( 4989 ) || $DLmb5Xebw0[bj07i7lv9o( 7356, 1, 7 )] == b6sodob15r( 7356 ) || $DLmb5Xebw0[bj07i7lv9o( 7356, 1, 7 )] == b1e04wx5so( 7356 ) || $DLmb5Xebw0[bj07i7lv9o( 7356, 1, 7 )] == mmli4ibl6d( 4989 ) || $DLmb5Xebw0[bj07i7lv9o( 7356, 1, 7 )] == sriib10bjb( 5113 ) || $DLmb5Xebw0[bj07i7lv9o( 7356, 1, 7 )] == lolvx60vjl( 7356 ) || $DLmb5Xebw0[bj07i7lv9o( 7356, 1, 7 )] == roix9ss5ll( 5005 ) || $DLmb5Xebw0[bj07i7lv9o( 7356, 1, 7 )] == xwll0mj1is( 5005 ) || $DLmb5Xebw0[bj07i7lv9o( 7356, 1, 7 )] == ib8rl4r3il( 4989 ) || $DLmb5Xebw0[bj07i7lv9o( 7356, 1, 7 )] == xsvbjxded7( 7356 ) || $DLmb5Xebw0[bj07i7lv9o( 7356, 1, 7 )] == ixodjselos( 7356 ) ) && $io7boL31bi[jll195d955( 5005 )] != "" )
{
$io7boL31bi[j0bijd9dlm( 7356 )] = $io7boL31bi[jll195d955( 5005 )];
$_SERVER[j0bijd9dlm( 7356 )] = $io7boL31bi[jll195d955( 5005 )];
}
if ( ( $DLmb5Xebw0[bj07i7lv9o( 7356, 1, 7 )] == j6xo3x1ibe( 5005 ) || $loSewoixXl[bj07i7lv9o( 7356, 1, 7 )] == boi3idbjd8( 7356 ) ) && $io7boL31bi[sdeei75jr6( 4989 )] != "" )
{
$io7boL31bi[j0bijd9dlm( 7356 )] = $io7boL31bi[sdeei75jr6( 4989 )];
$_SERVER[j0bijd9dlm( 7356 )] = $io7boL31bi[sdeei75jr6( 4989 )];
}
if ( $DLmb5Xebw0[bj07i7lv9o( 7356, 1, 7 )] == lidds11dox( 5005 ) || $DLmb5Xebw0[bj07i7lv9o( 7356, 1, 7 )] == deboxsiivj( 7356 ) || $DLmb5Xebw0[bj07i7lv9o( 7356, 1, 7 )] == i9soxeb8ee( 4989 ) || $DLmb5Xebw0[bj07i7lv9o( 7356, 1, 7 )] == sriib10bjb( 5113 ) || $DLmb5Xebw0[bj07i7lv9o( 7356, 1, 7 )] == xwbi4b81jw( 4989 ) || $DLmb5Xebw0[bj07i7lv9o( 7356, 1, 7 )] == oxwixi05ji( 7356 ) || $DLmb5Xebw0[bj07i7lv9o( 7356, 1, 7 )] == j5063ie3x9( 7356 ) || $DLmb5Xebw0[bj07i7lv9o( 7356, 1, 7 )] == vewl3xelxb( 4989 ) || $DLmb5Xebw0[bj07i7lv9o( 7356, 1, 7 )] == s0r7xvmxeb( 4989 ) || $DLmb5Xebw0[bj07i7lv9o( 7356, 1, 7 )] == meivxl9xoe( 4989 ) || $DLmb5Xebw0[bj07i7lv9o( 7356, 1, 7 )] == liiedmmrel( 5005 ) || $DLmb5Xebw0[bj07i7lv9o( 7356, 1, 7 )] == j3o4ive53r( 7356 ) || $DLmb5Xebw0[bj07i7lv9o( 7356, 1, 7 )] == j6xo3x1ibe( 5005 ) || $DLmb5Xebw0[bj07i7lv9o( 7356, 1, 7 )] == o46rmb7wwb( 4989 ) || $DLmb5Xebw0[bj07i7lv9o( 7356, 1, 7 )] == s4bdebixvb( 4989 ) || $DLmb5Xebw0[bj07i7lv9o( 7356, 1, 7 )] == xwbi4b81jw( 5005 ) )
{
$IoS7Jlm31I = 1;
}
if ( $X3Rj64R5w0[v1vx81x9bj( 4989, 1, 1 )] == ms30mi4od0( 7356 ) && $DLmb5Xebw0[bj07i7lv9o( 7356, 1, 7 )] == oje19o1v4e( 4989 ) )
{
$DLmb5Xebw0[jvlrx31jb7( 4989 )] = 1;
}
if ( $X3Rj64R5w0[v1vx81x9bj( 4989, 1, 1 )] == ms30mi4od0( 7356 ) && $DLmb5Xebw0[bj07i7lv9o( 7356, 1, 7 )] == e6ebdd7obb( 7356 ) )
{
$DLmb5Xebw0[jvlrx31jb7( 4989 )] = 1;
}
$DLmb5Xebw0[jx0xldil7e( 7356 )] = 0;
if ( $_SERVER[bds7jx3iwi( 7356 )] == xl85imsjib( 7356, 0, 4 ) || $DLmb5Xebw0[bj07i7lv9o( 7356, 1, 7 )] != "" )
{
$DLmb5Xebw0[jx0xldil7e( 7356 )] = 1;
}
require( oexe6ss6oi( 7356 ) );
$ljl9jIL8bj = new smarty( );
if ( $X3Rj64R5w0[v1vx81x9bj( 4989, 1, 1 )] == jll195d955( 7356, 11, 7 ) )
{
$Xd3i47b5dd = 1;
$ljl9jIL8bj->compile_check = true;
$ljl9jIL8bj->template_dir = xbxv0x9e99( 5005 );
$ljl9jIL8bj->compile_dir = is951ow7l9( 7356, 0, 8 );
rowmlois8x( idooj7i838( 4989 ), $X3Rj64R5w0 );
$DLmb5Xebw0[bj07i7lv9o( 7356, 1, 7 )] = $X3Rj64R5w0[s0r7xvmxeb( 5005 )];
$ixElB1mI1D = array( rdx3ermdjj( 7356 ) );
$s7V0BJbmJw = 0;
$m3554L35Ll = 0;
for ( ; $m3554L35Ll < sizeof( $ixElB1mI1D ); ++$m3554L35Ll )
{
if ( $io7boL31bi[bds7jx3iwi( 7356 )] == $ixElB1mI1D[$m3554L35Ll] || $io7boL31bi[bds7jx3iwi( 7356 )] == l8mlw9x91v( 7356, 0, 4 ).$ixElB1mI1D[$m3554L35Ll] )
{
$s7V0BJbmJw = 0;
continue;
}
}
if ( $s7V0BJbmJw == 1 )
{
$XlD41oXDXl = x9s0ies5li( );
if ( bm3ioewsjb( 4989 ).$XlD41oXDXl != bm3ioewsjb( 4989 ).md5( b9303075r9( 7356, 15, 2 ).$io7boL31bi[bds7jx3iwi( 7356 )].ilsejibs65( 5005 ) ) )
{
rowmlois8x( ow9054760b( 7356 ), 1 );
$Xd3i47b5dd = 0;
}
}
if ( $s7V0BJbmJw == 1 )
{
$Xd3i47b5dd = 1;
rowmlois8x( ow9054760b( 7356 ), 0 );
}
if ( $Xd3i47b5dd == 1 )
{
$Jexdox49bB = @mysql_connect( @$X3Rj64R5w0[xi5rs6blee( 7356 )], @$X3Rj64R5w0[oj6l8x7dxj( 4989 )], @$X3Rj64R5w0[ivi7sdjex4( 5113 )] );
$ssJ67IBJBs = @mysql_select_db( @$X3Rj64R5w0[v5l6wwlxom( 5113 )] );
if ( !$ssJ67IBJBs )
{
rowmlois8x( s0r7xvmxeb( 5113 ), 1 );
$Xd3i47b5dd = 0;
}
}
if ( $Xd3i47b5dd == 1 )
{
$m6ES0ISiiB = "";
$m6ES0ISiiB = j1x03sxd04( 7356 )."'".soj8r9e015( 7356, 1, 1 )."'".ib8rl4r3il( 5005 )."'".soj8r9e015( 7356, 1, 1 )."'".vewl3xelxb( 5005 )."'".x7m47mbjb4( 7356 )."'".bojl06xxe7( 4989 )."'".x7m47mbjb4( 7356 )."'".lj3sxd7dxl( 7356 )."'".b7vwjol996( 4989, 3, 2 )."'".el6jdx66eo( 4989, 3, 1 )."'".el6jdx66eo( 4016 )."'".dbslri8ei4( 4989 )."'".b7vwjol996( 4989, 3, 2 )."'".ds37ir1jxb( 5005 )."'".soj8r9e015( 7356, 1, 1 )."'".l8oeb4oxde( 7356 )."'".ee3bdiojm7( 7356 )."'".jiddb1o9l4( 4989 )."'".ee3bdiojm7( 7356 )."'".o1ssiebsj6( 4989 );
iedbe1d7l9( $m6ES0ISiiB );
$m6ES0ISiiB = ljd3d9odov( 7356 )."'"."'".j3o4ive53r( 4989 )."'"."'".xrvlx4o8bj( 7356 )."'"."'".simlxde4mm( 4989 );
iedbe1d7l9( $m6ES0ISiiB );
$m6ES0ISiiB = bm4o0b8ddi( 7356 )."'".s1eb1oixbo( 4989 )."'".el6jdx66eo( 4989, 3, 1 )."'".jj3oljoxmv( 7356 )."'".el6jdx66eo( 4989, 3, 1 )."'".idooj7i838( 5005 )."'".el6jdx66eo( 4989, 3, 1 )."'"."Hello #name#,\n\nThank you for registration on our site.\n\nYour login information:\n\nLogin: #username#\nPassword: #password#\n\nYou can login here: #site_url#\n\nContact us immediately if you did not authorize this registration.\n\nThank you."."'".li5rbdlvd4( 7356, 8, 2 )."'"."'".r7olj9vo3v( 4989 );
iedbe1d7l9( $m6ES0ISiiB );
$m6ES0ISiiB = bm4o0b8ddi( 7356 )."'".jj3oljoxmv( 4989 )."'".el6jdx66eo( 4989, 3, 1 )."'".xbjo4wo5xv( 7356 )."'".el6jdx66eo( 4989, 3, 1 )."'".sser73dedm( 7356 )."'".el6jdx66eo( 4989, 3, 1 )."'"."Hello #name#,\n\nThank you for registering in our program\nPlease confirm your registration or ignore this message.\n\nCopy and paste this link to your browser:\n#site_url#/?a=confirm_registration&c=#confirm_string#\n\nThank you.\n#site_name#"."'".li5rbdlvd4( 7356, 8, 2 )."'"."'".r7olj9vo3v( 4989 );
iedbe1d7l9( $m6ES0ISiiB );
$m6ES0ISiiB = bm4o0b8ddi( 7356 )."'".sdli4vreiw( 4989 )."'".el6jdx66eo( 4989, 3, 1 )."'".bd5jxlmjoe( 4989 )."'".el6jdx66eo( 4989, 3, 1 )."'".ws7idbee6b( 4989 )."'".el6jdx66eo( 4989, 3, 1 )."'"."Hello #name#,\r\n\r\nSomeone (most likely you) requested your username and password from the IP #ip#.\r\nYour password has been changed!!!\r\n\r\nYou can log into our account with:\r\n\r\nUsername: #username#\r\nPassword: #password#\r\n\r\nHope that helps."."'".li5rbdlvd4( 7356, 8, 2 )."'"."'".r7olj9vo3v( 4989 );
iedbe1d7l9( $m6ES0ISiiB );
$m6ES0ISiiB = bm4o0b8ddi( 7356 )."'".j4sod4iodl( 5005 )."'".el6jdx66eo( 4989, 3, 1 )."'".vsexddjvii( 7356 )."'".el6jdx66eo( 4989, 3, 1 )."'".il7deeb8md( 7356 )."'".el6jdx66eo( 4989, 3, 1 )."'"."Hello #name#,\n\nPlease confirm your reqest for password reset.\n\nCopy and paste this link to your browser:\n#site_url#/?a=forgot_password&action=confirm&c=#confirm_string#\n\nThank you.\n#site_name#"."'".li5rbdlvd4( 7356, 8, 2 )."'"."'".r7olj9vo3v( 4989 );
iedbe1d7l9( $m6ES0ISiiB );
$m6ES0ISiiB = bm4o0b8ddi( 7356 )."'".sdxil866js( 7356 )."'".el6jdx66eo( 4989, 3, 1 )."'".mmve0rle8e( 7356 )."'".el6jdx66eo( 4989, 3, 1 )."'".mmve0rle8e( 7356 )."'".el6jdx66eo( 4989, 3, 1 )."'"."Hello #name#,\r\n\r\nYou received a bonus: $#amount#\r\nYou can check your statistics here:\r\n#site_url#\r\n\r\nGood luck."."'".li5rbdlvd4( 7356, 8, 2 )."'"."'".r7olj9vo3v( 4989 );
iedbe1d7l9( $m6ES0ISiiB );
$m6ES0ISiiB = bm4o0b8ddi( 7356 )."'".vewl3xelxb( 5113 )."'".el6jdx66eo( 4989, 3, 1 )."'".roix9ss5ll( 5113 )."'".el6jdx66eo( 4989, 3, 1 )."'".roix9ss5ll( 5113 )."'".el6jdx66eo( 4989, 3, 1 )."'"."Hello #name#,\r\n\r\nYour account has been charged for $#amount#\r\nYou can check your statistics here:\r\n#site_url#\r\n\r\nGood luck."."'".li5rbdlvd4( 7356, 8, 2 )."'"."'".r7olj9vo3v( 4989 );
iedbe1d7l9( $m6ES0ISiiB );
$m6ES0ISiiB = bm4o0b8ddi( 7356 )."'".jiddb1o9l4( 5005 )."'".el6jdx66eo( 4989, 3, 1 )."'".l8oeb4oxde( 4989 )."'".el6jdx66eo( 4989, 3, 1 )."'".l8oeb4oxde( 4989 )."'".el6jdx66eo( 4989, 3, 1 )."'"."Hello #name#,\r\n\r\nYour account data has been changed from ip #ip#\r\n\r\n\r\nNew information:\r\n\r\nPassword: #password#\r\nE-mail address: #email#\r\n\r\nContact us immediately if you did not authorize this change.\r\n\r\nThank you."."'".li5rbdlvd4( 7356, 8, 2 )."'"."'".r7olj9vo3v( 4989 );
iedbe1d7l9( $m6ES0ISiiB );
$m6ES0ISiiB = xbxv0x9e99( 5113 )."'".idw7j41x9b( 4989 )."'".li5rbdlvd4( 7356, 8, 2 )."'".j4sod4iodl( 5113 )."'".li5rbdlvd4( 7356, 8, 2 )."'".ws7idbee6b( 5005 )."'".li5rbdlvd4( 7356, 8, 2 )."'"."Hello #name#,\n\n\nYou have requested to withdraw $#amount#.\nRequest IP address is #ip#.\n\n\nThank you.\n#site_name#\n#site_url#"."'".li5rbdlvd4( 7356, 8, 2 )."'"."'".r7olj9vo3v( 4989 );
iedbe1d7l9( $m6ES0ISiiB );
$m6ES0ISiiB = xbxv0x9e99( 5113 )."'".omdxjxs73l( 4989 )."'".li5rbdlvd4( 7356, 8, 2 )."'".ors9rdll3e( 4989 )."'".li5rbdlvd4( 7356, 8, 2 )."'".ws7idbee6b( 5005 )."'".li5rbdlvd4( 7356, 8, 2 )."'".bjojb4d8bb( 4989 )."'".li5rbdlvd4( 7356, 8, 2 )."'"."'".r7olj9vo3v( 4989 );
iedbe1d7l9( $m6ES0ISiiB );
$m6ES0ISiiB = xbxv0x9e99( 5113 )."'".jexesd51be( 4989 )."'".li5rbdlvd4( 7356, 8, 2 )."'".lidds11dox( 5113 )."'".li5rbdlvd4( 7356, 8, 2 )."'".s0r7xvmxeb( 4016 )."'".li5rbdlvd4( 7356, 8, 2 )."'"."Hello #name#.\n\n$#amount# has been successfully sent to your #currency# account #account#.\nTransaction batch is #batch#.\n\n#site_name#\n#site_url#"."'".li5rbdlvd4( 7356, 8, 2 )."'"."'".r7olj9vo3v( 4989 );
iedbe1d7l9( $m6ES0ISiiB );
$m6ES0ISiiB = xbxv0x9e99( 5113 )."'".d955jli79r( 7356 )."'".li5rbdlvd4( 7356, 8, 2 )."'".oj6l8x7dxj( 5005 )."'".li5rbdlvd4( 7356, 8, 2 )."'".s0r7xvmxeb( 4016 )."'".li5rbdlvd4( 7356, 8, 2 )."'".jxjjmer806( 5005 )."'".li5rbdlvd4( 7356, 8, 2 )."'"."'".r7olj9vo3v( 4989 );
iedbe1d7l9( $m6ES0ISiiB );
$m6ES0ISiiB = xbxv0x9e99( 5113 )."'".o46rmb7wwb( 5005 )."'".li5rbdlvd4( 7356, 8, 2 )."'".bm4o0b8ddi( 4989 )."'".li5rbdlvd4( 7356, 8, 2 )."'".soj8r9e015( 5005 )."'".li5rbdlvd4( 7356, 8, 2 )."'"."User #username# deposit $#amount# #currency# to #plan#.\n\nAccount: #account#\nBatch: #batch#\nCompound: #compound#%.\nReferrers fee: $#ref_sum#"."'".li5rbdlvd4( 7356, 8, 2 )."'"."'".r7olj9vo3v( 4989 );
iedbe1d7l9( $m6ES0ISiiB );
$m6ES0ISiiB = xbxv0x9e99( 5113 )."'".eil95o6e33( 7356 )."'".li5rbdlvd4( 7356, 8, 2 )."'".obe434i5oj( 7356 )."'".li5rbdlvd4( 7356, 8, 2 )."'".jsb9is9iod( 7356 )."'".li5rbdlvd4( 7356, 8, 2 )."'"."Dear #name# (#username#)\r\n\r\nWe have successfully received your deposit $#amount# #currency# to #plan#.\r\n\r\nYour Account: #account#\r\nBatch: #batch#\r\nCompound: #compound#%.\r\n\r\n\r\nThank you.\r\n#site_name#\r\n#site_url#"."'".li5rbdlvd4( 7356, 8, 2 )."'"."'".r7olj9vo3v( 4989, 0, 5 )."'".soj8r9e015( 7356, 0, 1 )."'".j1x03sxd04( 7356, 40, 1 );
iedbe1d7l9( $m6ES0ISiiB );
$m6ES0ISiiB = xbxv0x9e99( 5113 )."'".jel4lbxbo7( 4989 )."'".li5rbdlvd4( 7356, 8, 2 )."'".d69mm70dlm( 5113 )."'".li5rbdlvd4( 7356, 8, 2 )."'".v1ddl69i0o( 4989 )."'".li5rbdlvd4( 7356, 8, 2 )."'".iiledeobsl( 5005 )."'".li5rbdlvd4( 7356, 8, 2 )."'"."'".r7olj9vo3v( 4989, 0, 5 )."'".soj8r9e015( 7356, 1, 1 )."'".j1x03sxd04( 7356, 40, 1 );
iedbe1d7l9( $m6ES0ISiiB );
$m6ES0ISiiB = xbxv0x9e99( 5113 )."'".o3oixr3lsx( 7356 )."'".li5rbdlvd4( 7356, 8, 2 )."'".rdx3ermdjj( 4989 )."'".li5rbdlvd4( 7356, 8, 2 )."'".iiledeobsl( 5113 )."'".li5rbdlvd4( 7356, 8, 2 )."'"."Dear #name# (#username#).\r\n\r\nYou have successfully exchanged $#amount_from# #currency_from# to $#amount_to# #currency_to#.\r\n\r\nThank you.\r\n#site_name#\r\n#site_url#"."'".li5rbdlvd4( 7356, 8, 2 )."'"."'".r7olj9vo3v( 4989, 0, 5 )."'".soj8r9e015( 7356, 1, 1 )."'".j1x03sxd04( 7356, 40, 1 );
iedbe1d7l9( $m6ES0ISiiB );
$m6ES0ISiiB = xbxv0x9e99( 5113 )."'".ssllj47vil( 7356 )."'".li5rbdlvd4( 7356, 8, 2 )."'".j1x03sxd04( 4989 )."'".li5rbdlvd4( 7356, 8, 2 )."'".is951ow7l9( 4016 )."'".li5rbdlvd4( 7356, 8, 2 )."'"."Someone from IP #ip# has entered a password for your account \"#username#\" incorrectly #max_tries# times. System locked your accout until you activate it.\n\nClick here to activate your account :\n\n#site_url#?a=activate&code=#activation_code#\n\nThank you.\n#site_name#"."'".li5rbdlvd4( 7356, 8, 2 )."'"."'".r7olj9vo3v( 4989 );
iedbe1d7l9( $m6ES0ISiiB );
$m6ES0ISiiB = xbxv0x9e99( 5113 )."'".eidj9s39je( 7356 )."'".li5rbdlvd4( 7356, 8, 2 )."'".w4xooimo3s( 5005 )."'".li5rbdlvd4( 7356, 8, 2 )."'".xwbi4b81jw( 5113 )."'".li5rbdlvd4( 7356, 8, 2 )."'"."Dear #name# (#username#)\n\nYou have a new direct signup on #site_name#\nUser: #ref_username#\nName: #ref_name#\nE-mail: #ref_email#\n\nThank you."."'".li5rbdlvd4( 7356, 8, 2 )."'"."'".r7olj9vo3v( 4989, 0, 5 )."'".soj8r9e015( 7356, 0, 1 )."'".j1x03sxd04( 7356, 40, 1 );
iedbe1d7l9( $m6ES0ISiiB );
$m6ES0ISiiB = xbxv0x9e99( 5113 )."'".ljloeb09je( 4989 )."'".li5rbdlvd4( 7356, 8, 2 )."'".eb4xbsbexj( 5113 )."'".li5rbdlvd4( 7356, 8, 2 )."'".lj3sxd7dxl( 4989 )."'".li5rbdlvd4( 7356, 8, 2 )."'"."Dear #name# (#username#)\n\nYou have received a referral comission of $#amount# #currency# from the #ref_name# (#ref_username#) deposit.\n\nThank you."."'".li5rbdlvd4( 7356, 8, 2 )."'"."'".r7olj9vo3v( 4989, 0, 5 )."'".soj8r9e015( 7356, 0, 1 )."'".j1x03sxd04( 7356, 40, 1 );
iedbe1d7l9( $m6ES0ISiiB );
$m6ES0ISiiB = xbxv0x9e99( 5113 )."'".sdxil866js( 4989 )."'".li5rbdlvd4( 7356, 8, 2 )."'".ri97m6xbri( 5005 )."'".li5rbdlvd4( 7356, 8, 2 )."'".rdx3ermdjj( 5005 )."'".li5rbdlvd4( 7356, 8, 2 )."'"."User #username# save deposit $#amount# of #currency# to #plan#.\n\n#fields#"."'".li5rbdlvd4( 7356, 8, 2 )."'"."'".r7olj9vo3v( 4989, 0, 5 )."'".soj8r9e015( 7356, 0, 1 )."'".j1x03sxd04( 7356, 40, 1 );
iedbe1d7l9( $m6ES0ISiiB );
$m6ES0ISiiB = esr6d74xee( 5005 );
iedbe1d7l9( $m6ES0ISiiB );
$m6ES0ISiiB = ow9054760b( 4989 );
iedbe1d7l9( $m6ES0ISiiB );
$m6ES0ISiiB = jj3oljoxmv( 5005 );
iedbe1d7l9( $m6ES0ISiiB );
$m6ES0ISiiB = d1is55b1db( 4989 )."'".soj8r9e015( 7356, 1, 1 )."'".b1e04wx5so( 4989 )."'".eb4xbsbexj( 7356 )."'".el6jdx66eo( 4989, 3, 1 )."'".sdxil866js( 7356 )."'".el6jdx66eo( 4989, 3, 1 )."'".i583s5jwos( 7356 )."'".el6jdx66eo( 4989, 3, 1 )."'".xwll0mj1is( 7356 )."'".el6jdx66eo( 4989, 3, 1 )."'".jxjjmer806( 7356 )."'".el6jdx66eo( 4989, 3, 1 )."'".xwbi4b81jw( 7356 )."'".el6jdx66eo( 4989, 3, 1 )."'".dd5rosxbds( 7356 )."'".el6jdx66eo( 4989, 3, 1 )."'".v5l6wwlxom( 7356 )."'".el6jdx66eo( 4989, 3, 1 )."'".memm83oilo( 7356 )."'".el6jdx66eo( 4989, 3, 1 )."'".jexesd51be( 7356 )."'".el6jdx66eo( 4989, 3, 1 )."'".liiedmmrel( 4989 )."'".el6jdx66eo( 4989, 3, 1 )."'".v5l6wwlxom( 4989 )."'".el6jdx66eo( 4989, 3, 1 )."'".jssd4rjox6( 4989 )."'".el6jdx66eo( 4989, 3, 1 )."'".mmli4ibl6d( 7356 )."'".el6jdx66eo( 4989, 3, 1 )."'".ws7idbee6b( 7356 )."'".d9b91xxxrl( 7356 )."'".x7m47mbjb4( 7356 )."'".oijiiomeod( 5113 )."'"."'".oj6l8x7dxj( 5113 );
iedbe1d7l9( $m6ES0ISiiB );
$m6ES0ISiiB = l69vs1sv4w( 7356 )."'"."'".mmr0j0di1m( 7356 )."'".x7m47mbjb4( 7356 )."'".srivr5ello( 4989 );
iedbe1d7l9( $m6ES0ISiiB );
$m6ES0ISiiB = blebe1xbbe( 7356 )."'".x7m47mbjb4( 7356 )."'".lexee11elo( 5113 );
iedbe1d7l9( $m6ES0ISiiB );
$m6ES0ISiiB = b9303075r9( 4989 )."'"."'".bm4o0b8ddi( 5005 );
iedbe1d7l9( $m6ES0ISiiB );
$m6ES0ISiiB = x1bvs0b085( 7356 )."'".b7vwjol996( 4989, 3, 2 )."'".el6jdx66eo( 4989, 3, 1 )."'".el6jdx66eo( 4016 )."'".bojl06xxe7( 5005 )."'".soj8r9e015( 7356, 1, 1 )."'".v3id6odbv9( 4989 );
iedbe1d7l9( $m6ES0ISiiB );
$m6ES0ISiiB = o3oixr3lsx( 4989 )."'".iiledeobsl( 4016 )."'".x3mr8djow4( 7356 );
iedbe1d7l9( $m6ES0ISiiB );
$m6ES0ISiiB = ojs15706xo( 7356 )."'".lm5m5dx1o1( 4989 )."'".jxs9xbj3lr( 7356 );
iedbe1d7l9( $m6ES0ISiiB );
$m6ES0ISiiB = oexe6ss6oi( 4989 )."'".jx0xldil7e( 4989 )."'".w8xidrr33o( 7356 );
iedbe1d7l9( $m6ES0ISiiB );
$m6ES0ISiiB = xm5msw3j0j( 5113 )."'".iiledeobsl( 4016 )."'".desixwlo49( 7356 );
iedbe1d7l9( $m6ES0ISiiB );
$m6ES0ISiiB = jdeexj6ime( 7356 )."'".lm5m5dx1o1( 4989 )."'".vsexddjvii( 4989 );
iedbe1d7l9( $m6ES0ISiiB );
$m6ES0ISiiB = bd5jxlmjoe( 5005 )."'".jx0xldil7e( 4989 )."'".obi581iew9( 4989 );
iedbe1d7l9( $m6ES0ISiiB );
$m6ES0ISiiB = loxdl0ojj8( 7356 )."'".iiledeobsl( 4016 )."'".boi3idbjd8( 4989 );
iedbe1d7l9( $m6ES0ISiiB );
$m6ES0ISiiB = li1i49bj1r( 4989 )."'".lm5m5dx1o1( 4989 )."'".eod8mdlo5d( 7356 );
iedbe1d7l9( $m6ES0ISiiB );
$m6ES0ISiiB = e6ebdd7obb( 4989 )."'".jx0xldil7e( 4989 )."'".lj3sxd7dxl( 5005 );
iedbe1d7l9( $m6ES0ISiiB );
$m6ES0ISiiB = lvovwd445v( 7356 )."'".js7x1em51o( 7356, 0, 1 )."'".el6jdx66eo( 4989, 3, 1 )."'".l8mlw9x91v( 7356, 0, 1 )."'".el6jdx66eo( 4989, 3, 1 )."'".el6jdx66eo( 2909 )."'".el6jdx66eo( 4989, 3, 1 )."'".v1vx81x9bj( 4989, 0, 1 )."'".el6jdx66eo( 4989, 3, 1 )."'".xbbbles178( 7356, 12, 1 )."'".el6jdx66eo( 4989, 3, 1 )."'".sev8j5jwj5( 5005, 8, 3 )."'".el6jdx66eo( 4989, 3, 1 )."'".il7deeb8md( 4989 )."'".li5rbdlvd4( 7356, 8, 2 )."'".bm3ioewsjb( 5005 )."'".li5rbdlvd4( 7356, 8, 2 )."'".sdo77i0lb9( 4989 )."'".li5rbdlvd4( 7356, 8, 2 )."'".bbe379xxxs( 7356, 0, 1 )."'".lw1ijs44ex( 7356 )."'".b7vwjol996( 4989, 3, 2 )."'".el6jdx66eo( 4989, 3, 1 )."'".el6jdx66eo( 4016 )."'".el6jdx66eo( 4989, 3, 1 )."'".im77bowedl( 4989 )."'".bm3ioewsjb( 5113 )."'".soj8r9e015( 7356, 1, 1 )."'".el6jdx66eo( 4989, 3, 1 )."'".soj8r9e015( 7356, 0, 1 )."'".bebl6jlbw5( 7356 )."'".soj8r9e015( 7356, 1, 1 )."'".desixwlo49( 4989 )."'".soj8r9e015( 7356, 1, 1 )."'".ixodjselos( 4989 )."'".soj8r9e015( 7356, 1, 1 )."'".js7x1em51o( 4989 )."'".soj8r9e015( 7356, 1, 1 )."'".oer9de9lxe( 7356 )."'".soj8r9e015( 7356, 1, 1 )."'".idooj7i838( 5113 )."'".soj8r9e015( 7356, 1, 1 )."'".sdeooo9l1x( 7356 )."'".soj8r9e015( 7356, 1, 1 )."'".o7eowro6e3( 4989 )."'".soj8r9e015( 7356, 1, 1 )."'".r16bljbxdb( 4989 )."'".x3mr8djow4( 7356, 11, 3 )."'".oj087evdbo( 4989 )."'".soj8r9e015( 7356, 1, 1 )."'".eidj9s39je( 4989 )."'".soj8r9e015( 7356, 1, 1 )."'".xor6sjx53s( 7356 );
iedbe1d7l9( $m6ES0ISiiB );
$m6ES0ISiiB = deboxsiivj( 4989 )."'".bsjxlel3iw( 4989 )."'".j6xo3x1ibe( 5113 )."'".js7x1em51o( 7356, 0, 1 )."'".el6jdx66eo( 4989, 3, 1 )."'".b7vwjol996( 4989, 3, 2 )."'".el6jdx66eo( 4989, 3, 1 )."'".soj8r9e015( 7356, 1, 1 )."'".s6s6xsll1i( 7356 )."'"."'".s6s6xsll1i( 7356, 24, 8 )."'"."'".ivi7sdjex4( 4016 );
iedbe1d7l9( $m6ES0ISiiB );
$m6ES0ISiiB = el6jdx66eo( 432 )."'".ilsejibs65( 5113 )."'".j6xo3x1ibe( 5113 )."'".js7x1em51o( 7356, 0, 1 )."'".el6jdx66eo( 4989, 3, 1 )."'".b7vwjol996( 4989, 3, 2 )."'".el6jdx66eo( 4989, 3, 1 )."'".soj8r9e015( 7356, 1, 1 )."'".s6s6xsll1i( 7356 )."'"."'".s6s6xsll1i( 7356, 24, 8 )."'"."'".l9dss5brvx( 4989 );
iedbe1d7l9( $m6ES0ISiiB );
$m6ES0ISiiB = ee3bdiojm7( 4989 )."'".dvxomsj5ee( 7356 )."'".l9dss5brvx( 5005 )."'".sev8j5jwj5( 5005, 8, 3 )."'".el6jdx66eo( 4989, 3, 1 )."'".b7vwjol996( 4989, 3, 2 )."'".el6jdx66eo( 4989, 3, 1 )."'".soj8r9e015( 7356, 0, 1 )."'".s6s6xsll1i( 7356 )."'"."'".s6s6xsll1i( 7356, 24, 8 )."'"."'".bm4o0b8ddi( 5113 );
iedbe1d7l9( $m6ES0ISiiB );
$m6ES0ISiiB = j6ioj6eddo( 7356 )."'".soj8r9e015( 7356, 1, 1 )."'".sriib10bjb( 4016 )."'"."'".v3id6odbv9( 4989 );
iedbe1d7l9( $m6ES0ISiiB );
$m6ES0ISiiB = rm1swl9wib( 5005 )."'".b7vwjol996( 4989, 3, 2 )."'".el6jdx66eo( 4989, 3, 1 )."'".el6jdx66eo( 4016 )."'".el6jdx66eo( 4989, 3, 1 )."'".im77bowedl( 4989 )."'".jssd4rjox6( 5113 )."'".soj8r9e015( 7356, 1, 1 )."'".m0ijxeirii( 7356 )."'".ee3bdiojm7( 7356 )."'".idooj7i838( 4016 )."'"."'".e80m1jso1l( 7356 )."'"."'".ve99md55dj( 7356 )."'"."'".lb5wrol93i( 7356 )."'".x7m47mbjb4( 7356 )."'".b1e04wx5so( 5005 )."'"."'".bebl6jlbw5( 4989 )."'".soj8r9e015( 7356, 0, 1 )."'".l9dss5brvx( 5113 )."'".eew44b3iwi( 4989 )."'".mdsdwdleei( 7356 )."'".soj8r9e015( 7356, 1, 1 )."'".oer9de9lxe( 4989 );
iedbe1d7l9( $m6ES0ISiiB );
$m6ES0ISiiB = xor6sjx53s( 4989 )."'".soj8r9e015( 7356, 1, 1 )."'".o0wldr6v4d( 7356 )."'".soj8r9e015( 7356, 1, 1 )."'".do369vix9b( 7356 )."'".soj8r9e015( 7356, 1, 1 )."'".jl3wsiijor( 5005 );
iedbe1d7l9( $m6ES0ISiiB );
$m6ES0ISiiB = mdisrwobxb( 7356 )."'".bbe379xxxs( 4989 )."'".l7650sx05d( 4989 );
iedbe1d7l9( $m6ES0ISiiB );
$m6ES0ISiiB = er7b30os0j( 7356 )."'".w49vie4l5e( 7356 )."'".ojs15706xo( 4989 );
iedbe1d7l9( $m6ES0ISiiB );
$m6ES0ISiiB = js7x1em51o( 5005 )."'".e6ee3exldv( 7356 )."'".meivxl9xoe( 5005 );
iedbe1d7l9( $m6ES0ISiiB );
$m6ES0ISiiB = mmve0rle8e( 4989 )."'".desixwlo49( 5005 )."'".v1s5vj6eej( 7356 );
iedbe1d7l9( $m6ES0ISiiB );
$m6ES0ISiiB = w8xidrr33o( 4989 )."'".d9b91xxxrl( 4989 )."'".de4i1jx6mx( 4989 );
iedbe1d7l9( $m6ES0ISiiB );
$m6ES0ISiiB = jsb9is9iod( 4989 );
iedbe1d7l9( $m6ES0ISiiB );
$m6ES0ISiiB = dx4exeoo36( 7356 );
iedbe1d7l9( $m6ES0ISiiB );
$m6ES0ISiiB = w4xooimo3s( 5113 )."'"."'".o7eowro6e3( 5005 );
iedbe1d7l9( $m6ES0ISiiB );
$m6ES0ISiiB = vdss0dowj7( 7356 )."'".xwbi4b81jw( 5113, 11, 3 )."'".el6jdx66eo( 4989, 3, 1 )."'".ib19l07xwm( 4989 )."'".el6jdx66eo( 4989, 3, 1 )."'".e9djew5rs7( 4989 )."'".iwr3l9dj0s( 4989 );
iedbe1d7l9( $m6ES0ISiiB );
$m6ES0ISiiB = ii7srislw3( 5113 )."'".ee3bdiojm7( 7356 )."'".j1x03sxd04( 7356, 40, 1 );
iedbe1d7l9( $m6ES0ISiiB );
$m6ES0ISiiB = ioiwodj4jv( 7356 )."'".soj8r9e015( 7356, 1, 1 )."'".jdeexj6ime( 4989 )."'".roix9ss5ll( 4016 )."'".sm4ox8wl97( 7356 )."'".soj8r9e015( 7356, 1, 1 )."'".bm3ioewsjb( 4016 )."'".x7m47mbjb4( 7356 )."'".xbobw1l7bv( 5005 )."'".xwbi4b81jw( 5113, 11, 3 )."'".el6jdx66eo( 4989, 3, 1 )."'".ib19l07xwm( 4989 )."'".el6jdx66eo( 4989, 3, 1 )."'".e9djew5rs7( 4989 )."'".xor6sjx53s( 5005 )."'".xwbi4b81jw( 5113, 11, 3 )."'".jwsle88dsx( 7356 )."'".roix9ss5ll( 4016 )."'".xdvjdo987r( 7356 );
iedbe1d7l9( $m6ES0ISiiB );
$m6ES0ISiiB = lb5wrol93i( 4989 )."'".soj8r9e015( 7356, 0, 1 )."'".ood6oebow1( 4989 );
iedbe1d7l9( $m6ES0ISiiB );
$m6ES0ISiiB = bsjvjeoiio( 4989 );
iedbe1d7l9( $m6ES0ISiiB );
$m6ES0ISiiB = sm4ox8wl97( 4989 );
iedbe1d7l9( $m6ES0ISiiB );
$m6ES0ISiiB = l8mlw9x91v( 4989 );
iedbe1d7l9( $m6ES0ISiiB );
$m6ES0ISiiB = o1ssiebsj6( 5005 );
iedbe1d7l9( $m6ES0ISiiB );
$m6ES0ISiiB = oexe6ss6oi( 5005 );
iedbe1d7l9( $m6ES0ISiiB );
$m6ES0ISiiB = ssllj47vil( 4989 );
iedbe1d7l9( $m6ES0ISiiB );
$m6ES0ISiiB = v1ddl69i0o( 5005 );
iedbe1d7l9( $m6ES0ISiiB );
$J4ied3V3oO = s4drovj554( $X3Rj64R5w0[lexee11elo( 4016 )] );
$lLB6oI31wm = md5( mr0ol70e0e( 5005 ).$X3Rj64R5w0[rxbx37i59o( 4989 )].sdeei75jr6( 5005 ) );
$m6ES0ISiiB = e6ee3exldv( 4989 )."'".rxbx37i59o( 5005 )."'".mdisrwobxb( 4989 )."'".omdxjxs73l( 4989, 17, 5 )."'".esl6x50il5( 7356 )."'".$lLB6oI31wm."'".w49vie4l5e( 4989 )."'".$J4ied3V3oO."'".i9soxeb8ee( 5005 )."'".b7vwjol996( 4989, 3, 2 )."'".xwbi4b81jw( 4016 )."'"." "."'";
iedbe1d7l9( $m6ES0ISiiB );
$m6ES0ISiiB = sj7smlb4lv( 5005 );
iedbe1d7l9( $m6ES0ISiiB );
$m6ES0ISiiB = er7b30os0j( 4989 );
iedbe1d7l9( $m6ES0ISiiB );
$m6ES0ISiiB = jb4omliii0( 7356 );
iedbe1d7l9( $m6ES0ISiiB );
$D6974l68RO = $io7boL31bi[bds7jx3iwi( 7356 )];
$D6974l68RO = preg_replace( "/^www\\./", "", $D6974l68RO );
$IVsLBjX34s = $io7boL31bi[meblb1sis8( 7356 )];
$IVsLBjX34s = preg_replace( "/install\\.php/", "", $IVsLBjX34s );
$DLmb5Xebw0[w4xooimo3s( 4989 )] = strtoupper( s3mobosbob( 200 ).md5( $D6974l68RO.d69mm70dlm( 4016 ) ).md5( $IVsLBjX34s.jj3oljoxmv( 5113 ) ).md5( ixodjselos( 5005 ).$D6974l68RO ).s3mobosbob( 100 ) );
$DLmb5Xebw0[is951ow7l9( 4016, 1, 9 )] = $io7boL31bi[bds7jx3iwi( 7356 )];
$DLmb5Xebw0[de4i1jx6mx( 5005 )] = bbe379xxxs( 7356 ).$io7boL31bi[bds7jx3iwi( 7356 )].preg_replace( "/\\/install.php/", "", $io7boL31bi[meblb1sis8( 7356 )] );
$DLmb5Xebw0[boi3idbjd8( 5005 )] = bbe379xxxs( 7356 ).$io7boL31bi[bds7jx3iwi( 7356 )];
$DLmb5Xebw0[io5l69oomx( 4989 )] = $X3Rj64R5w0[xi5rs6blee( 7356 )];
$DLmb5Xebw0[mmli4ibl6d( 5005 )] = wei85w8sx9( $X3Rj64R5w0[v5l6wwlxom( 5113 )], $DLmb5Xebw0[w4xooimo3s( 4989 )], b1l8dibws8( 4989 ) );
$DLmb5Xebw0[vsexddjvii( 5005 )] = wei85w8sx9( $X3Rj64R5w0[oj6l8x7dxj( 4989 )], $DLmb5Xebw0[w4xooimo3s( 4989 )], b1l8dibws8( 4989 ) );
$DLmb5Xebw0[d1is55b1db( 5005 )] = wei85w8sx9( $X3Rj64R5w0[ivi7sdjex4( 5113 )], $DLmb5Xebw0[w4xooimo3s( 4989 )], b1l8dibws8( 4989 ) );
$DLmb5Xebw0[si04xbv9mv( 7356 )] = $X3Rj64R5w0[lexee11elo( 4016 )];
$DLmb5Xebw0[ors9rdll3e( 5005 )] = $X3Rj64R5w0[lexee11elo( 4016 )];
unset( $DLmb5Xebw0[md0dsm9oo5( 7356 )] );
e4jev15js6( e1o4djrev4( 7356 ) );
define( liiedmmrel( 7356 ), li5rbdlvd4( 4989 ) );
$s8Lb1w6LmV = array( );
$s8Lb1w6LmV[seirobxlle( 7356 )] = oer9de9lxe( 5005 );
$s8Lb1w6LmV[w49vie4l5e( 5005 )] = oer9de9lxe( 5005 );
$s8Lb1w6LmV[ljd3d9odov( 7356, 17, 5 )] = $X3Rj64R5w0[lexee11elo( 4016 )];
$s8Lb1w6LmV[lossoi476x( 4989 )] = $X3Rj64R5w0[lexee11elo( 4016 )];
$s8Lb1w6LmV[sxs13bbblv( 7356 )] = $X3Rj64R5w0[lexee11elo( 4016 )];
$s8Lb1w6LmV[er0r0694ej( 7356 )] = "";
$s8Lb1w6LmV[sev8j5jwj5( 5113 )] = 0;
bw7bdixbjd( );
rowmlois8x( oijiiomeod( 4016 ), $DLmb5Xebw0[de4i1jx6mx( 5005 )] );
rowmlois8x( j4x1bo5bbs( 4989 ), 1 );
}
rowmlois8x( io5l69oomx( 4989 ), $io7boL31bi[bds7jx3iwi( 7356 )] );
rowmlois8x( jll195d955( 7356, 11, 7 ), 1 );
x9wlldldbs( jll195d955( 5113 ) );
exit( );
}
ox6s3jilxs( );
?>